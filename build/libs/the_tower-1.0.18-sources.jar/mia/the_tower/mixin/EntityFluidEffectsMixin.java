package mia.the_tower.mixin;

import mia.the_tower.initialisation.fluid.ModFluidEffects;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_3414;
import net.minecraft.class_3532;
import net.minecraft.class_5712;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Objects;

@Mixin(class_1297.class)
public abstract class EntityFluidEffectsMixin {
    @Shadow
    @Final
    protected class_5819 random;

    @Shadow
    @Nullable
    public abstract class_1309 getControllingPassenger();

    @Inject(method = "onSwimmingStart", at = @At("HEAD"), cancellable = true)
    private void theTower$replaceModFluidSplashEffects(CallbackInfo ci) {
        class_1297 self = (class_1297)(Object)this;
        ModFluidEffects.Type fluidType = ModFluidEffects.getType(self);
        if (fluidType == null) {
            return;
        }

        class_1297 soundSource = Objects.requireNonNullElse(this.getControllingPassenger(), self);
        class_243 velocity = soundSource.method_18798();
        float sourceScale = soundSource == self ? 0.2F : 0.9F;
        float volume = Math.min(1.0F, (float)Math.sqrt(velocity.field_1352 * velocity.field_1352 * 0.2F + velocity.field_1351 * velocity.field_1351 + velocity.field_1350 * velocity.field_1350 * 0.2F) * sourceScale);
        class_3414 sound = volume < 0.25F ? ModFluidEffects.getSplashSound(fluidType) : ModFluidEffects.getHighSpeedSplashSound(fluidType);
        self.method_5783(sound, volume, 1.0F + (this.random.method_43057() - this.random.method_43057()) * 0.4F);

        float splashY = class_3532.method_15357(self.method_23318());
        int particleCount = (int)(1.0F + self.method_17681() * 20.0F);
        for (int i = 0; i < particleCount; i++) {
            double xOffset = (this.random.method_43058() * 2.0 - 1.0) * self.method_17681();
            double zOffset = (this.random.method_43058() * 2.0 - 1.0) * self.method_17681();
            self.method_37908().method_8406(
                    ModFluidEffects.getSuspendedParticle(fluidType),
                    self.method_23317() + xOffset,
                    splashY + 1.0F,
                    self.method_23321() + zOffset,
                    velocity.field_1352,
                    velocity.field_1351,
                    velocity.field_1350
            );
        }

        self.method_32876(class_5712.field_28160);
        ci.cancel();
    }

    @Inject(method = "playSwimSound(F)V", at = @At("HEAD"), cancellable = true)
    private void theTower$replaceModFluidSwimSound(float volume, CallbackInfo ci) {
        class_1297 self = (class_1297)(Object)this;
        ModFluidEffects.Type fluidType = ModFluidEffects.getType(self);
        if (fluidType == null) {
            return;
        }

        self.method_5783(ModFluidEffects.getSwimSound(fluidType), volume, 1.0F + (this.random.method_43057() - this.random.method_43057()) * 0.4F);
        ci.cancel();
    }
}
