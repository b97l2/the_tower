package mia.the_tower.mixin.client;

import mia.the_tower.initialisation.fluid.ModFluidEffects;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2338;
import net.minecraft.class_3610;
import net.minecraft.class_4184;
import net.minecraft.class_5636;
import net.minecraft.class_638;
import net.minecraft.class_758;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin(class_758.class)
public abstract class BackgroundRendererMixin {
    @Inject(method = "getFogColor", at = @At("RETURN"), cancellable = true)
    private static void theTower$replaceCustomFluidFogColor(class_4184 camera, float tickDelta, class_638 world,
                                                            int clampedViewDistance, float skyDarkness,
                                                            CallbackInfoReturnable<Vector4f> cir) {
        if (camera.method_19334() != class_5636.field_27886) {
            return;
        }

        class_3610 fluidState = world.method_8316(class_2338.method_49638(camera.method_19326()));
        ModFluidEffects.Type fluidType = ModFluidEffects.getType(fluidState);
        if (fluidType == null) {
            return;
        }

        float darkness = Math.max(0.0F, 1.0F - skyDarkness * 0.35F);
        Vector4f fogColor = switch (fluidType) {
            case BLOOD -> new Vector4f(0.46F * darkness, 0.024F * darkness, 0.020F * darkness, 1.0F);
            case GUNK -> new Vector4f(0.020F * darkness, 0.018F * darkness, 0.016F * darkness, 1.0F);
        };

        cir.setReturnValue(fogColor);
    }
}
