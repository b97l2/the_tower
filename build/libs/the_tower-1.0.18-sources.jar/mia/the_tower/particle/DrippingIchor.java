package mia.the_tower.particle;

import mia.the_tower.initialisation.particle.CustomParticles;
import net.minecraft.class_2394;
import net.minecraft.class_2400;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import org.jetbrains.annotations.Nullable;

/**
 * Vanilla-style block leak particle used by all three ichor phases.
 */
public class DrippingIchor extends class_4003 {
    private DrippingIchor(class_638 world, double x, double y, double z) {
        super(world, x, y, z);
        this.method_3080(0.01F, 0.01F);
        this.field_3844 = 0.06F;
    }

    @Override
    public class_3999 method_18122() {
        return class_3999.field_17828;
    }

    @Override
    public void method_3070() {
        this.field_3858 = this.field_3874;
        this.field_3838 = this.field_3854;
        this.field_3856 = this.field_3871;
        this.updateAge();

        if (!this.field_3843) {
            this.field_3869 -= this.field_3844;
            this.method_3069(this.field_3852, this.field_3869, this.field_3850);
            this.updateVelocity();

            if (!this.field_3843) {
                this.field_3852 *= 0.98F;
                this.field_3869 *= 0.98F;
                this.field_3850 *= 0.98F;
            }
        }
    }

    protected void updateAge() {
        if (this.field_3847-- <= 0) {
            this.method_3085();
        }
    }

    protected void updateVelocity() {
    }

    private static class Dripping extends DrippingIchor {
        private final class_2394 nextParticle;

        private Dripping(class_638 world, double x, double y, double z, class_2394 nextParticle) {
            super(world, x, y, z);
            this.nextParticle = nextParticle;
            this.field_3844 *= 0.02F;
            this.field_3847 = 40;
        }

        @Override
        protected void updateAge() {
            if (this.field_3847-- <= 0) {
                this.method_3085();
                this.field_3851.method_8406(
                        this.nextParticle,
                        this.field_3874,
                        this.field_3854,
                        this.field_3871,
                        this.field_3852,
                        this.field_3869,
                        this.field_3850
                );
            }
        }

        @Override
        protected void updateVelocity() {
            this.field_3852 *= 0.02;
            this.field_3869 *= 0.02;
            this.field_3850 *= 0.02;
        }
    }

    private static class Falling extends DrippingIchor {
        private final class_2394 nextParticle;

        private Falling(class_638 world, double x, double y, double z, class_2394 nextParticle) {
            super(world, x, y, z);
            this.nextParticle = nextParticle;
            this.field_3847 = (int) (64.0 / (Math.random() * 0.8 + 0.2));
        }

        @Override
        protected void updateVelocity() {
            if (this.field_3845) {
                this.method_3085();
                this.field_3851.method_8406(this.nextParticle, this.field_3874, this.field_3854, this.field_3871, 0.0, 0.0, 0.0);
            }
        }
    }

    private static class Landing extends DrippingIchor {
        private Landing(class_638 world, double x, double y, double z) {
            super(world, x, y, z);
            this.field_3847 = (int) (16.0 / (Math.random() * 0.8 + 0.2));
        }
    }

    public static class Factory implements class_707<class_2400> {
        private final class_4002 spriteProvider;

        public Factory(class_4002 spriteProvider) {
            this.spriteProvider = spriteProvider;
        }

        @Nullable
        @Override
        public class_703 createParticle(class_2400 parameters, class_638 world, double x, double y, double z,
                                       double velocityX, double velocityY, double velocityZ) {
            DrippingIchor particle = new Dripping(world, x, y, z, CustomParticles.FALLING_ICHOR);
            particle.method_18141(this.spriteProvider.method_18139(world.field_9229));
            return particle;
        }
    }

    public static class FallingFactory implements class_707<class_2400> {
        private final class_4002 spriteProvider;

        public FallingFactory(class_4002 spriteProvider) {
            this.spriteProvider = spriteProvider;
        }

        @Nullable
        @Override
        public class_703 createParticle(class_2400 parameters, class_638 world, double x, double y, double z,
                                       double velocityX, double velocityY, double velocityZ) {
            DrippingIchor particle = new Falling(world, x, y, z, CustomParticles.LANDING_ICHOR);
            particle.method_18141(this.spriteProvider.method_18139(world.field_9229));
            return particle;
        }
    }

    public static class LandingFactory implements class_707<class_2400> {
        private final class_4002 spriteProvider;

        public LandingFactory(class_4002 spriteProvider) {
            this.spriteProvider = spriteProvider;
        }

        @Nullable
        @Override
        public class_703 createParticle(class_2400 parameters, class_638 world, double x, double y, double z,
                                       double velocityX, double velocityY, double velocityZ) {
            DrippingIchor particle = new Landing(world, x, y, z);
            particle.method_18141(this.spriteProvider.method_18139(world.field_9229));
            return particle;
        }
    }
}
