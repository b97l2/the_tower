package mia.the_tower.initialisation.particle;

import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.class_2378;
import net.minecraft.class_2400;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class CustomParticles {

    //to make a new particle, create a new class in the client portion of the mod, under mia.the_tower, defining the behaviour
    //then load it here
    //then put it in the client initialiser
    //then give it a json file
    //then add a texture

    public static final class_2400 EMBERS_OF_THE_FRAGE =
            registerParticle("embers_of_the_frage", FabricParticleTypes.simple());

    public static final class_2400 UNDERBLOOD =
            registerParticle("underblood", FabricParticleTypes.simple());

    public static final class_2400 GOLD_INCENSE =
            registerParticle("gold_incense", FabricParticleTypes.simple());

    public static final class_2400 GLUH_PARTICLE =
            registerParticle("gluh_particle", FabricParticleTypes.simple());

    public static final class_2400 STAVE_PARTICLE =
            registerParticle("stave_particle", FabricParticleTypes.simple());

    public static final class_2400 WHITE_INCENSE =
            registerParticle("white_incense", FabricParticleTypes.simple());

    public static final class_2400 GOLD_ORB =
            registerParticle("gold_orb_particle", FabricParticleTypes.simple());

    public static final class_2400 AZURE_SPARK =
            registerParticle("azure_spark_particle", FabricParticleTypes.simple());

    public static final class_2400 DRIPPING_ICHOR =
            registerParticle("dripping_ichor_particle", FabricParticleTypes.simple());

    public static final class_2400 FALLING_ICHOR =
            registerParticle("falling_ichor_particle", FabricParticleTypes.simple());

    public static final class_2400 LANDING_ICHOR =
            registerParticle("landing_ichor_particle", FabricParticleTypes.simple());

    private static class_2400 registerParticle(String name, class_2400 particleType) {
        return class_2378.method_10230(class_7923.field_41180, class_2960.method_60655("the_tower", name), particleType);
    }

    public static void load() {}
}
