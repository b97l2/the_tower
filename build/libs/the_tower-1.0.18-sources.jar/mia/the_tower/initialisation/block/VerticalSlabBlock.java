package mia.the_tower.initialisation.block;

import com.mojang.serialization.MapCodec;
import mia.the_tower.initialisation.fluid.FluidLogging;
import net.minecraft.class_10225;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_2771;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.class_4970;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

public class VerticalSlabBlock extends class_2248 implements ModFluidLoggable {
    public static final MapCodec<VerticalSlabBlock> CODEC = method_54094(VerticalSlabBlock::new);
    public static final class_2754<class_2771> TYPE = class_2741.field_12485;
    public static final class_2754<class_2350> FACING = class_2741.field_12481;

    private static final class_265 BOTTOM_NORTH_SHAPE = class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 8.0);
    private static final class_265 TOP_NORTH_SHAPE = class_2248.method_9541(0.0, 0.0, 8.0, 16.0, 16.0, 16.0);
    private static final class_265 BOTTOM_EAST_SHAPE = class_2248.method_9541(8.0, 0.0, 0.0, 16.0, 16.0, 16.0);
    private static final class_265 TOP_EAST_SHAPE = class_2248.method_9541(0.0, 0.0, 0.0, 8.0, 16.0, 16.0);
    private static final class_265 BOTTOM_SOUTH_SHAPE = TOP_NORTH_SHAPE;
    private static final class_265 TOP_SOUTH_SHAPE = BOTTOM_NORTH_SHAPE;
    private static final class_265 BOTTOM_WEST_SHAPE = TOP_EAST_SHAPE;
    private static final class_265 TOP_WEST_SHAPE = BOTTOM_EAST_SHAPE;

    public VerticalSlabBlock(class_4970.class_2251 settings) {
        super(settings);
        this.method_9590(FluidLogging.withDefaultFluid(
                this.method_9564()
                        .method_11657(TYPE, class_2771.field_12681)
                        .method_11657(FACING, class_2350.field_11043)
        ));
    }

    @Override
    protected MapCodec<? extends class_2248> method_53969() {
        return field_46280;
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        class_2680 currentState = ctx.method_8045().method_8320(ctx.method_8037());
        if (currentState.method_27852(this)) {
            return FluidLogging.withSlot(currentState.method_11657(TYPE, class_2771.field_12682), FluidLogging.Slot.NONE);
        }

        class_2350 facing = getPlacementFacing(ctx);
        class_2771 type = getPlacementType(ctx, facing);
        return FluidLogging.withPlacementFluid(
                this.method_9564()
                        .method_11657(TYPE, type)
                        .method_11657(FACING, facing),
                ctx
        );
    }

    @Override
    protected boolean method_9616(class_2680 state, class_1750 context) {
        if (state.method_11654(TYPE) == class_2771.field_12682 || !context.method_8041().method_31574(this.method_8389())) {
            return false;
        }

        if (context.method_7717()) {
            class_2350 side = context.method_8038();
            class_2771 clickedType = state.method_11654(TYPE);
            return state.method_11654(FACING).method_10166() == side.method_10166()
                    && ((clickedType == class_2771.field_12681 && side == state.method_11654(FACING).method_10153())
                    || (clickedType == class_2771.field_12679 && side == state.method_11654(FACING)));
        }

        return true;
    }

    @Override
    public boolean method_10310(@Nullable class_1657 player, class_1922 world, class_2338 pos, class_2680 state, class_3611 fluid) {
        return state.method_11654(TYPE) != class_2771.field_12682 && ModFluidLoggable.super.method_10310(player, world, pos, state, fluid);
    }

    @Override
    public boolean method_10311(class_1936 world, class_2338 pos, class_2680 state, class_3610 fluidState) {
        return state.method_11654(TYPE) != class_2771.field_12682 && ModFluidLoggable.super.method_10311(world, pos, state, fluidState);
    }

    @Override
    protected class_2680 method_9559(
            class_2680 state,
            class_4538 world,
            class_10225 tickView,
            class_2338 pos,
            class_2350 direction,
            class_2338 neighborPos,
            class_2680 neighborState,
            class_5819 random
    ) {
        FluidLogging.scheduleFluidTick(state, tickView, world, pos);
        return super.method_9559(state, world, tickView, pos, direction, neighborPos, neighborState, random);
    }

    @Override
    protected class_3610 method_9545(class_2680 state) {
        return FluidLogging.getFluidState(state, super.method_9545(state));
    }

    @Override
    protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return getShape(state);
    }

    @Override
    protected class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return getShape(state);
    }

    private static class_265 getShape(class_2680 state) {
        if (state.method_11654(TYPE) == class_2771.field_12682) {
            return class_259.method_1077();
        }

        return switch (state.method_11654(FACING)) {
            case field_11034 -> state.method_11654(TYPE) == class_2771.field_12681 ? BOTTOM_EAST_SHAPE : TOP_EAST_SHAPE;
            case field_11035 -> state.method_11654(TYPE) == class_2771.field_12681 ? BOTTOM_SOUTH_SHAPE : TOP_SOUTH_SHAPE;
            case field_11039 -> state.method_11654(TYPE) == class_2771.field_12681 ? BOTTOM_WEST_SHAPE : TOP_WEST_SHAPE;
            case field_11043, field_11036, field_11033 -> state.method_11654(TYPE) == class_2771.field_12681 ? BOTTOM_NORTH_SHAPE : TOP_NORTH_SHAPE;
        };
    }

    private static class_2350 getPlacementFacing(class_1750 ctx) {
        class_2350 side = ctx.method_8038();
        if (side.method_10166().method_10179()) {
            return side;
        }

        class_243 hitPos = ctx.method_17698();
        class_2338 blockPos = ctx.method_8037();
        double x = hitPos.field_1352 - blockPos.method_10263();
        double z = hitPos.field_1350 - blockPos.method_10260();

        if (Math.abs(x - 0.5) > Math.abs(z - 0.5)) {
            return x < 0.5 ? class_2350.field_11039 : class_2350.field_11034;
        }
        return z < 0.5 ? class_2350.field_11043 : class_2350.field_11035;
    }

    private static class_2771 getPlacementType(class_1750 ctx, class_2350 facing) {
        class_243 hitPos = ctx.method_17698();
        class_2338 blockPos = ctx.method_8037();
        double offset = facing.method_10166() == class_2350.class_2351.field_11048
                ? hitPos.field_1352 - blockPos.method_10263()
                : hitPos.field_1350 - blockPos.method_10260();

        return switch (facing) {
            case field_11034, field_11035 -> offset < 0.5 ? class_2771.field_12679 : class_2771.field_12681;
            case field_11039, field_11043 -> offset < 0.5 ? class_2771.field_12681 : class_2771.field_12679;
            case field_11036, field_11033 -> class_2771.field_12681;
        };
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(TYPE, FACING);
        FluidLogging.appendProperty(builder);
    }
}
