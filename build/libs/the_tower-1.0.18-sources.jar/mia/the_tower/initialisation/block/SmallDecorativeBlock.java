package mia.the_tower.initialisation.block;

import com.mojang.serialization.MapCodec;
import mia.the_tower.initialisation.fluid.FluidLogging;
import net.minecraft.class_10225;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3610;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.class_5431;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

public class SmallDecorativeBlock extends class_2383 implements ModFluidLoggable {
    public static final MapCodec<SmallDecorativeBlock> CODEC = method_54094(
            settings -> new SmallDecorativeBlock(settings, class_259.method_1077())
    );

    private final class_265 northShape;
    private final class_265 southShape;
    private final class_265 eastShape;
    private final class_265 westShape;

    public SmallDecorativeBlock(class_2251 settings, class_265 shape) {
        this(settings, shape, shape, shape, shape);
    }

    public SmallDecorativeBlock(
            class_2251 settings,
            class_265 northShape,
            class_265 southShape,
            class_265 eastShape,
            class_265 westShape
    ) {
        super(settings);
        this.northShape = northShape;
        this.southShape = southShape;
        this.eastShape = eastShape;
        this.westShape = westShape;
        this.method_9590(FluidLogging.withDefaultFluid(this.method_9564().method_11657(field_11177, class_2350.field_11043)));
    }

    @Override
    protected MapCodec<? extends class_2383> method_53969() {
        return field_46280;
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        if (!canPlaceOnSurface(ctx.method_8045(), ctx.method_8037())) {
            return null;
        }

        return FluidLogging.withPlacementFluid(
                this.method_9564().method_11657(field_11177, ctx.method_8042().method_10153()),
                ctx
        );
    }

    private static boolean canPlaceOnSurface(class_4538 world, class_2338 pos) {
        class_2338 surfacePos = pos.method_10074();
        class_2680 surfaceState = world.method_8320(surfacePos);
        return !(surfaceState.method_26204() instanceof SmallDecorativeBlock)
                && surfaceState.method_30368(world, surfacePos, class_2350.field_11036, class_5431.field_25822);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11177);
        FluidLogging.appendProperty(builder);
    }

    @Override
    protected class_2680 method_9559(
            class_2680 state,
            class_4538 world,
            class_10225 tickView,
            class_2338 pos,
            class_2350 direction,
            class_2338 neighborPos,
            class_2680 neighborState,
            class_5819 random
    ) {
        FluidLogging.scheduleFluidTick(state, tickView, world, pos);
        return super.method_9559(state, world, tickView, pos, direction, neighborPos, neighborState, random);
    }

    @Override
    protected class_3610 method_9545(class_2680 state) {
        return FluidLogging.getFluidState(state, super.method_9545(state));
    }

    @Override
    protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        class_243 offset = getShapeOffset(state, pos);
        return getShape(state).method_1096(offset.field_1352, offset.field_1351, offset.field_1350);
    }

    @Override
    protected class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        class_243 offset = getShapeOffset(state, pos);
        return getShape(state).method_1096(offset.field_1352, offset.field_1351, offset.field_1350);
    }

    private class_265 getShape(class_2680 state) {
        return switch (state.method_11654(field_11177)) {
            case field_11035 -> southShape;
            case field_11034 -> eastShape;
            case field_11039 -> westShape;
            case field_11043, field_11036, field_11033 -> northShape;
        };
    }

    private static class_243 getShapeOffset(class_2680 state, class_2338 pos) {
        return state.method_26226(pos);
    }
}
