package mia.the_tower.initialisation.weather;

import net.minecraft.class_3532;

public final class FrageWeatherClientState {
    private static final float TRANSITION_STEP = 0.04F;

    private static FrageWeatherPattern pattern = FrageWeatherPattern.OVERCAST;
    private static float overcastStrength = 1.0F;
    private static float previousOvercastStrength = 1.0F;
    private static float targetOvercastStrength = 1.0F;

    private FrageWeatherClientState() {
    }

    public static void apply(FrageWeatherSyncPayload payload) {
        pattern = payload.pattern();
        targetOvercastStrength = class_3532.method_15363(payload.overcastStrength(), 0.0F, 1.0F);
    }

    public static void tick() {
        previousOvercastStrength = overcastStrength;
        overcastStrength = class_3532.method_15363(
                overcastStrength + class_3532.method_15363(targetOvercastStrength - overcastStrength, -TRANSITION_STEP, TRANSITION_STEP),
                0.0F,
                1.0F
        );
    }

    public static void reset() {
        pattern = FrageWeatherPattern.OVERCAST;
        overcastStrength = 1.0F;
        previousOvercastStrength = 1.0F;
        targetOvercastStrength = 1.0F;
    }

    public static float getOvercastStrength(float tickDelta) {
        if (pattern != FrageWeatherPattern.OVERCAST) {
            return 0.0F;
        }

        return class_3532.method_16439(tickDelta, previousOvercastStrength, overcastStrength);
    }
}
