package mia.the_tower.initialisation.weather;

import mia.the_tower.The_Tower;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record FrageWeatherSyncPayload(FrageWeatherPattern pattern, float overcastStrength) implements class_8710 {
    public static final class_9154<FrageWeatherSyncPayload> ID = new class_9154<>(The_Tower.id("frage_weather"));
    public static final class_9139<class_9129, FrageWeatherSyncPayload> CODEC =
            class_9139.method_56438(FrageWeatherSyncPayload::write, FrageWeatherSyncPayload::new);

    private FrageWeatherSyncPayload(class_9129 buf) {
        this(buf.method_10818(FrageWeatherPattern.class), buf.readFloat());
    }

    private void write(class_9129 buf) {
        buf.method_10817(this.pattern);
        buf.method_52941(this.overcastStrength);
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}
