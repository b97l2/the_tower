package mia.the_tower.initialisation.biomes;


import mia.the_tower.initialisation.carver.ModCarvers;
import mia.the_tower.initialisation.world.ModPlacedFeatures;
import net.minecraft.class_1959;
import net.minecraft.class_2893;
import net.minecraft.class_2960;
import net.minecraft.class_4763;
import net.minecraft.class_4968;
import net.minecraft.class_5321;
import net.minecraft.class_5483;
import net.minecraft.class_5485;
import net.minecraft.class_7891;
import net.minecraft.class_7924;


public class ThePit {

    public static final class_5321<class_1959> THE_PIT = class_5321.method_29179(class_7924.field_41236, class_2960.method_60655("the_tower", "the_pit"));

    public static void bootstrap(class_7891<class_1959> context) {
        context.method_46838(THE_PIT, createThePit(context));
    }

    public static class_1959 createThePit(class_7891<class_1959> context) {
        class_5483.class_5496 spawnBuilder = new class_5483.class_5496();
        //spawnBuilder.spawn(SpawnGroup.CREATURE, new SpawnSettings.SpawnEntry(ModEntities.PORCUPINE, 2, 3, 5)); //spawning mod entities

        //general
        var placedLookup = context.method_46799(class_7924.field_41245); //?
        var carverLookup  = context.method_46799(class_7924.field_41238);

        class_5485.class_5495 biomeBuilder =
                new class_5485.class_5495(placedLookup, carverLookup);

        biomeBuilder.method_30991(ModCarvers.PIT_CARVER_KEY);

        biomeBuilder.method_30992(class_2893.class_2895.field_13178, ModPlacedFeatures.PILE_OF_MEAT_PLACED_KEY);
        //biomeBuilder.feature(GenerationStep.Feature.LAKES, ModPlacedFeatures.DECORATED_PIT_PLACED_KEY);

        return new class_1959.class_1960()
                .method_48164(false)
                .method_8727(0.4f)
                .method_8747(0.7f)
                .method_30973(biomeBuilder.method_46671())
                .method_30974(spawnBuilder.method_31007())
                .method_24379((new class_4763.class_4764())
                        .method_24395(0x470404)
                        .method_24397(0x470404)
                        .method_30820(0x470404)
                        .method_30822(0x470404)
                        .method_30821(0x470404)
                        .method_24392(0x470404)
                        .method_24943(class_4968.field_23146)
                        //.music(MusicType.createIngameMusic(RegistryEntry.of(ModSounds.BAR_BRAWL))) //custom music
                        .method_24391())
                .method_30972();
    }

    public static void load(){}

}
