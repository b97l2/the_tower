package mia.the_tower.initialisation.biomes;

import mia.the_tower.initialisation.entity.ModEntities;
import mia.the_tower.initialisation.world.ModPlacedFeatures;
import net.minecraft.class_1311;
import net.minecraft.class_1959;
import net.minecraft.class_2893;
import net.minecraft.class_2960;
import net.minecraft.class_4763;
import net.minecraft.class_4968;
import net.minecraft.class_5321;
import net.minecraft.class_5483;
import net.minecraft.class_5485;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.registry.*;;

//to create a new biome, it needs one of these, it needs its own line in The_TowerDataGenerator, load() needs to be called, and it needs
//to be mentioned in the frage class

public class Shadowlands {

    public static final class_5321<class_1959> SHADOWLANDS = class_5321.method_29179(class_7924.field_41236, class_2960.method_60655("the_tower", "shadowlands"));

    public static void bootstrap(class_7891<class_1959> context) {
        context.method_46838(SHADOWLANDS, createShadowlands(context));
    }

    public static class_1959 createShadowlands(class_7891<class_1959> context) {
        class_5483.class_5496 spawnBuilder = new class_5483.class_5496();
        spawnBuilder.method_31011(class_1311.field_6294, new class_5483.class_1964(ModEntities.VOID_MOTH, 2, 3, 5)); //spawning mod entities

        class_5485.class_5495 biomeBuilder =
                new class_5485.class_5495(context.method_46799(class_7924.field_41245),
                        context.method_46799(class_7924.field_41238));

        //globalOverworldGeneration(biomeBuilder); //this is for if you want it to spawn in the overworld
        biomeBuilder.method_30992(class_2893.class_2895.field_13176, ModPlacedFeatures.ITORE_PLACED_KEY);

        return new class_1959.class_1960()
                .method_48164(false)
                .method_8727(0.4f)
                .method_8747(0.7f)
                .method_30973(biomeBuilder.method_46671())
                .method_30974(spawnBuilder.method_31007())
                .method_24379((new class_4763.class_4764())
                        .method_24395(0x19191a)
                        .method_24397(0x0a0a0a)
                        .method_30820(0x0a0a0a)
                        .method_30822(0x2b2b2b)
                        .method_30821(0x35384a)
                        .method_24392(0x35384a)
                        .method_24943(class_4968.field_23146)
                        //.music(MusicType.createIngameMusic(RegistryEntry.of(ModSounds.BAR_BRAWL))) //custom music
                        .method_24391())
                .method_30972();
    }

    public static void load(){}

}
