package mia.the_tower.initialisation.fluid;

import mia.the_tower.initialisation.particle.CustomParticles;
import mia.the_tower.initialisation.sounds.CustomSounds;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_3414;
import net.minecraft.class_3532;
import net.minecraft.class_3610;

public class ModFluidEffects {
    public enum Type {
        BLOOD,
        GUNK
    }

    public static Type getType(class_1297 entity) {
        class_1937 world = entity.method_37908();
        class_238 box = entity.method_5829().method_1011(0.001);
        int minX = class_3532.method_15357(box.field_1323);
        int maxX = class_3532.method_15384(box.field_1320);
        int minY = class_3532.method_15357(box.field_1322);
        int maxY = class_3532.method_15384(box.field_1325);
        int minZ = class_3532.method_15357(box.field_1321);
        int maxZ = class_3532.method_15384(box.field_1324);
        class_2338.class_2339 mutable = new class_2338.class_2339();

        for (int x = minX; x < maxX; x++) {
            for (int y = minY; y < maxY; y++) {
                for (int z = minZ; z < maxZ; z++) {
                    mutable.method_10103(x, y, z);
                    class_3610 fluidState = world.method_8316(mutable);
                    Type type = getType(fluidState);
                    if (type != null && y + fluidState.method_15763(world, mutable) >= box.field_1322) {
                        return type;
                    }
                }
            }
        }

        return null;
    }

    public static Type getType(class_3610 state) {
        if (fluid_init.STILL_BLOOD.method_15780(state.method_15772())) {
            return Type.BLOOD;
        }
        if (fluid_init.STILL_GUNK.method_15780(state.method_15772())) {
            return Type.GUNK;
        }
        return null;
    }

    public static class_2394 getSuspendedParticle(Type type) {
        return switch (type) {
            case BLOOD -> CustomParticles.UNDERBLOOD;
            case GUNK -> class_2398.field_22247;
        };
    }

    public static class_3414 getSplashSound(Type type) {
        return switch (type) {
            case BLOOD -> CustomSounds.BLOOD_SPLASH;
            case GUNK -> CustomSounds.GUNK_SPLASH;
        };
    }

    public static class_3414 getHighSpeedSplashSound(Type type) {
        return switch (type) {
            case BLOOD -> CustomSounds.BLOOD_SPLASH_HIGH_SPEED;
            case GUNK -> CustomSounds.GUNK_SPLASH_HIGH_SPEED;
        };
    }

    public static class_3414 getSwimSound(Type type) {
        return switch (type) {
            case BLOOD -> CustomSounds.BLOOD_SWIM;
            case GUNK -> CustomSounds.GUNK_SWIM;
        };
    }
}
