package mia.the_tower.initialisation.world.tree;

import mia.the_tower.initialisation.block_init;
import net.minecraft.class_10376;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2378;
import net.minecraft.class_2465;
import net.minecraft.class_2680;
import net.minecraft.class_2746;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_3031;
import net.minecraft.class_3111;
import net.minecraft.class_3481;
import net.minecraft.class_3532;
import net.minecraft.class_5281;
import net.minecraft.class_5819;
import net.minecraft.class_5821;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.List;

public class DeadGinkgoFeature extends class_3031<class_3111> {
    public static final class_3031<class_3111> DEAD_GINKGO = class_2378.method_10230(
            class_7923.field_41144,
            class_2960.method_60655("the_tower", "dead_ginkgo"),
            new DeadGinkgoFeature()
    );

    private DeadGinkgoFeature() {
        super(class_3111.field_24893);
    }

    public static void init() {}

    @Override
    public boolean method_13151(class_5821<class_3111> context) {
        class_5281 world = context.method_33652();
        class_5819 random = context.method_33654();
        class_2338 origin = context.method_33655();

        if (!canReplace(world.method_8320(origin)) || !world.method_8320(origin.method_10074()).method_26212(world, origin.method_10074())) {
            return false;
        }

        int height = class_3532.method_15395(random, 5, 15);
        int breakHeight = Math.max(3, height - class_3532.method_15395(random, 2, 4));
        int baseRadius = random.method_43057() < 0.2F ? 3 : 2;
        List<class_2338> trunkBlocks = new ArrayList<>();

        class_2338 topCenter = generateTrunk(world, random, origin, breakHeight, baseRadius, trunkBlocks);
        generateSplinters(world, random, topCenter, height - breakHeight, baseRadius, trunkBlocks);

        if (trunkBlocks.isEmpty()) {
            return false;
        }

        placeLichen(world, random, trunkBlocks);
        placeChanterelles(world, random, origin, baseRadius);
        return true;
    }

    private class_2338 generateTrunk(class_5281 world, class_5819 random, class_2338 origin, int breakHeight,
                                   int baseRadius, List<class_2338> trunkBlocks) {
        int centerX = origin.method_10263();
        int centerZ = origin.method_10260();

        for (int y = 0; y <= breakHeight; y++) {
            if (y > 2 && random.method_43057() < 0.18F) {
                centerX = class_3532.method_15340(centerX + random.method_43048(3) - 1, origin.method_10263() - 1, origin.method_10263() + 1);
                centerZ = class_3532.method_15340(centerZ + random.method_43048(3) - 1, origin.method_10260() - 1, origin.method_10260() + 1);
            }

            float progress = y / (float) Math.max(1, breakHeight);
            float radius = class_3532.method_16439(progress, baseRadius + 0.35F, 1.55F);
            int bounds = class_3532.method_15386(radius);

            for (int offsetX = -bounds; offsetX <= bounds; offsetX++) {
                for (int offsetZ = -bounds; offsetZ <= bounds; offsetZ++) {
                    float roughness = 0.82F + random.method_43057() * 0.3F;
                    if (offsetX * offsetX + offsetZ * offsetZ > radius * radius * roughness) {
                        continue;
                    }

                    placeLog(world, new class_2338(centerX + offsetX, origin.method_10264() + y, centerZ + offsetZ),
                            class_2350.class_2351.field_11052, trunkBlocks);
                }
            }
        }

        return new class_2338(centerX, origin.method_10264() + breakHeight, centerZ);
    }

    private void generateSplinters(class_5281 world, class_5819 random, class_2338 topCenter,
                                   int availableHeight, int baseRadius, List<class_2338> trunkBlocks) {
        int splinterCount = class_3532.method_15395(random, 3, 5);
        double angleOffset = random.method_43058() * Math.PI * 2.0;

        for (int splinter = 0; splinter < splinterCount; splinter++) {
            double angle = angleOffset + Math.PI * 2.0 * splinter / splinterCount + (random.method_43058() - 0.5) * 0.7;
            double radialDistance = 0.5 + random.method_43058() * Math.max(0.75, baseRadius - 0.5);
            int startX = topCenter.method_10263() + (int) Math.round(Math.cos(angle) * radialDistance);
            int startZ = topCenter.method_10260() + (int) Math.round(Math.sin(angle) * radialDistance);
            int splinterHeight = splinter == 0 ? availableHeight : class_3532.method_15395(random, 1, availableHeight);

            for (int step = 1; step <= splinterHeight; step++) {
                float lean = step / (float) Math.max(1, splinterHeight);
                int x = startX + (int) Math.round(Math.cos(angle) * lean);
                int z = startZ + (int) Math.round(Math.sin(angle) * lean);
                class_2338 position = new class_2338(x, topCenter.method_10264() + step, z);
                placeLog(world, position, class_2350.class_2351.field_11052, trunkBlocks);

                if (step <= 2 && random.method_43056()) {
                    class_2350 inward = class_2350.method_10142(-Math.cos(angle), 0, -Math.sin(angle));
                    placeLog(world, position.method_10093(inward), class_2350.class_2351.field_11052, trunkBlocks);
                }
            }
        }
    }

    private void placeLichen(class_5281 world, class_5819 random, List<class_2338> trunkBlocks) {
        class_2350[] sides = class_2350.class_2353.field_11062.method_29716().toArray(class_2350[]::new);
        int attempts = class_3532.method_15395(random, 8, 14);

        for (int attempt = 0; attempt < attempts; attempt++) {
            class_2350 side = sides[random.method_43048(sides.length)];
            class_2338 logPos = trunkBlocks.get(random.method_43048(trunkBlocks.size()));
            class_2338 lichenPos = logPos.method_10093(side);

            if (!canReplace(world.method_8320(lichenPos))) {
                continue;
            }

            class_2350 attachedFace = side.method_10153();
            if (!world.method_8320(logPos).method_27852(block_init.GINKGO_LOG)) {
                continue;
            }

            class_2680 lichen = block_init.STARLIGHT_LICHEN.method_9564();
            if (lichen.method_26204() instanceof class_10376) {
                class_2746 faceProperty = class_10376.method_33374(attachedFace);
                if (faceProperty != null && lichen.method_28498(faceProperty)) {
                    class_2680 placedState = lichen.method_11657(faceProperty, true);
                    if (placedState.method_26184(world, lichenPos)) {
                        world.method_8652(lichenPos, placedState, class_2248.field_31028);
                    }
                }
            }
        }
    }

    private void placeChanterelles(class_5281 world, class_5819 random, class_2338 origin, int baseRadius) {
        int targetCount = class_3532.method_15395(random, 5, 9);
        int placed = 0;

        for (int attempt = 0; attempt < targetCount * 5 && placed < targetCount; attempt++) {
            double angle = random.method_43058() * Math.PI * 2.0;
            double distance = baseRadius + 1.0 + random.method_43058() * 3.5;
            int x = origin.method_10263() + (int) Math.round(Math.cos(angle) * distance);
            int z = origin.method_10260() + (int) Math.round(Math.sin(angle) * distance);
            int y = world.method_8624(class_2902.class_2903.field_13203, x, z);
            class_2338 position = new class_2338(x, y, z);
            class_2680 chanterelle = block_init.CHANTERELLE.method_9564();

            if (canReplace(world.method_8320(position)) && chanterelle.method_26184(world, position)) {
                world.method_8652(position, chanterelle, class_2248.field_31028);
                placed++;
            }
        }
    }

    private void placeLog(class_5281 world, class_2338 position, class_2350.class_2351 axis, List<class_2338> trunkBlocks) {
        if (!canReplace(world.method_8320(position))) {
            return;
        }

        world.method_8652(position, block_init.GINKGO_LOG.method_9564().method_11657(class_2465.field_11459, axis),
                class_2248.field_31028);
        trunkBlocks.add(position.method_10062());
    }

    private static boolean canReplace(class_2680 state) {
        return state.method_26215() || state.method_26164(class_3481.field_44470);
    }
}
