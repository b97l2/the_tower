package mia.the_tower.initialisation.world.tree;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2378;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3481;
import net.minecraft.class_3746;
import net.minecraft.class_4643;
import net.minecraft.class_4647;
import net.minecraft.class_4648;
import net.minecraft.class_5819;
import net.minecraft.class_6017;
import net.minecraft.class_7923;

/**
 * Organic, drooping foliage for very large trees.
 * Shape:
 *  - Rounded canopy whose radius shrinks with depth (vertical taper) + per-layer fuzz.
 *  - From lower layers' perimeter, spawn hanging strands that can drift sideways.
 * Config fields (see CODEC below):
 *  - radius, offset                (standard fields inherited from FoliagePlacer)
 *  - max_droop                     maximum length of a drooping strand
 *  - strand_chance                 chance to start a strand at a perimeter leaf (0..1)
 *  - strand_continue_chance        chance to extend a strand by another block (0..1)
 *  - drift_chance                  chance that a strand step drifts one block horizontally (0..1)
 *  - vertical_taper                how fast the canopy radius shrinks per layer downward (blocks/layer)
 *  - layer_fuzz                    +/- random radius wobble per layer (integer)
 *  - y_ellipticity                 weights vertical distance in the roundness test (higher = flatter dome)
 */
public class GiantFoliagePlacer extends class_4647 {

    // --- Custom knobs ---
    private final class_6017 maxDroop;
    private final float topRoundness;
    private final float strandContinueChance;
    private final float driftChance;
    private final float verticalTaper;
    private final int layerFuzz;
    private static final float DEFAULT_Y_ELLIPTICITY = 0.6f;

    public static final MapCodec<GiantFoliagePlacer> CODEC =
            RecordCodecBuilder.mapCodec(instance ->
                    method_30411(instance)
                            .and(class_6017.method_35004(0, 128)
                                    .fieldOf("max_droop")
                                    .forGetter(p -> p.maxDroop))
                            .and(Codec.floatRange(0.0F, 1.0F)
                                    .fieldOf("strand_chance").orElse(0.35F)
                                    .forGetter(p -> p.topRoundness))
                            .and(Codec.floatRange(0.0F, 1.0F)
                                    .fieldOf("strand_continue_chance").orElse(0.85F)
                                    .forGetter(p -> p.strandContinueChance))
                            .and(Codec.floatRange(0.0F, 1.0F)
                                    .fieldOf("drift_chance").orElse(0.25F)
                                    .forGetter(p -> p.driftChance))
                            .and(Codec.floatRange(0.0F, 3.0F)
                                    .fieldOf("vertical_taper").orElse(0.6F)
                                    .forGetter(p -> p.verticalTaper))
                            .and(Codec.intRange(0, 8)
                                    .fieldOf("layer_fuzz").orElse(1)
                                    .forGetter(p -> p.layerFuzz))
                            .apply(instance, GiantFoliagePlacer::new)
            );


    public GiantFoliagePlacer(
            class_6017 radius,                // vanilla: base radius seed
            class_6017 offset,                // vanilla: vertical offset seed
            class_6017 maxDroop,
            float topRoundness,
            float strandContinueChance,
            float driftChance,
            float verticalTaper,
            int layerFuzz
    ) {
        super(radius, offset);
        this.maxDroop = maxDroop;
        this.topRoundness = topRoundness;
        this.strandContinueChance = strandContinueChance;
        this.driftChance = driftChance;
        this.verticalTaper = verticalTaper;
        this.layerFuzz = layerFuzz;
    }

    public static final ThreadLocal<class_1923> CURRENT_TREE_ORIGIN = new ThreadLocal<>(); //for chunk window
    public static final ThreadLocal<Boolean> DISABLE_FEATURE_REGION_LIMIT = ThreadLocal.withInitial(() -> false);

    @Override
    protected class_4648<?> method_28843() {
        return ORGANIC_DROOP; // defined below
    }

    public static final class_4648<GiantFoliagePlacer> ORGANIC_DROOP =
            class_2378.method_10230(
                    class_7923.field_41150,
                    class_2960.method_60655("the_tower", "organic_droop"),
                    new class_4648<>(GiantFoliagePlacer.CODEC)
            );

    public static void init(){}

    /**
     * Choose a foliage height given trunk height. For giant trees you usually want a deep canopy.
     * Adjust if you prefer; this just ensures we get enough vertical space to show the droop.
     */
    @Override
    public int method_26989(class_5819 random, int trunkHeight, class_4643 config) {
        // ~ upper third of trunk, clamped:
        int h = Math.max(8, trunkHeight / 3);
        return Math.min(h, 48); // safety clamp for huge specimens
    }

    @Override
    protected void method_23448(
            class_3746 world,
            class_8179 placer,
            class_5819 random,
            class_4643 config,
            int trunkHeight,
            class_4647.class_5208 node,
            int foliageHeight,
            int baseRadius,
            int offset
    ) {
        final class_2338 center = node.method_27388();
        final boolean giantTrunk = node.method_27390();

        // How many layers ABOVE the top to include inside the main blob
        // Scales with topRoundness and baseRadius, but clamped for perf.
        final int capMax = Math.min(16, Math.max(1, (int)Math.floor(baseRadius * 0.5)));
        final int capLayers = (topRoundness <= 0f) ? 0 : Math.max(1, (int)Math.round(topRoundness * capMax));

        // Cache a droop length for this tree (or keep per-layer if you like)
        final int maxDroopLen = this.maxDroop.method_35008(random);

        //this is to place only in feature chunk
        final class_1923 originChunk =
                java.util.Optional.ofNullable(CURRENT_TREE_ORIGIN.get())
                        .orElseGet(() -> new class_1923(center));
        final class_4647.class_8179 gatedPlacer = Boolean.TRUE.equals(DISABLE_FEATURE_REGION_LIMIT.get()) ? placer : new class_4647.class_8179() {
            @Override
            public void method_49240(class_2338 pos, class_2680 state) {
                if (withinFeatureRegion(originChunk, pos)) {
                    placer.method_49240(pos, state);
                }
            }
            @Override
            public boolean method_49239(class_2338 pos) {
                return placer.method_49239(pos); // preserve leaf-layer checks
            }
        };


        // IMPORTANT: one vertical shift path (yOff), no pre-shifted BlockPos
        for (int dy = -capLayers; dy < foliageHeight; dy++) {
            final int yOff = offset - dy;

            int layerRadius;
            if (dy < 0) {
                // --- Rounded top (spherical cap) ---
                // normalized height above top: 1..capLayers
                final int h = -dy;
                final double t = (double) h / (double) (capLayers + 1); // 0..~1
                // r = R * sqrt(1 - t^2)
                layerRadius = (int)Math.round(baseRadius * Math.sqrt(Math.max(0.0, 1.0 - t * t)));

                // smaller fuzz on the cap to keep it smooth
                if (layerFuzz > 0) {
                    int fuzz = Math.max(1, layerFuzz / 2);
                    layerRadius += random.method_39332(-fuzz, fuzz);
                }
            } else {
                // --- Main blob below the top ---
                layerRadius = Math.max(1, (int)Math.round(baseRadius - verticalTaper * dy));
                if (layerFuzz > 0) {
                    layerRadius += random.method_39332(-layerFuzz, layerFuzz);
                }
            }

            if (layerRadius < 1) continue;  // nothing to place on this layer

            // Place the layer (single application of vertical offset).
            method_23449(world, gatedPlacer, random, config, center, layerRadius, yOff, giantTrunk);

            // Start a strand from EVERY leaf cell in this layer, threading through leaves
            // (as you already implemented in spawnDroopingStrandsFromAllLeafCellsInLayer).
            class_2338 layerCenter = center.method_10086(yOff);
            spawnDroopingStrandsFromAllLeafCellsInLayer(world, gatedPlacer, random, config, layerCenter, layerRadius, maxDroopLen);

        }
    }

    /**
     * Organic acceptance test for layer cells. We treat y (depth) as part of a squashed ellipsoid to avoid boxy crowns.
     * y passed in here is negative going downward (vanilla convention in calls).
     */
    @Override
    protected boolean method_23451(class_5819 random, int dx, int y, int dz, int radius, boolean giantTrunk) {
        // Ellipsoidal contour with slight random softening near the rim:
        // Treat vertical as a weighted component to keep top broader, bottom narrower.
        int ay = Math.abs(y);
        // "distance squared" in an ellipsoid sense:
        double d2 = dx * dx + dz * dz + (ay * ay) * DEFAULT_Y_ELLIPTICITY;
        double r2 = radius * radius;

        if (d2 > r2) return true;

        // Introduce tiny holes near the rim to break up perfect edges:
        double rim = Math.max(0.0, r2 - d2);
        if (rim < Math.max(1.0, 0.15 * r2)) {
            // Near the edge: randomly skip a few spots for organic look
            if (random.method_43057() < 0.03f) return true;
        }
        return false;
    }


    private static boolean isLeafAt(class_3746 world, class_2338 pos) {
        return world.method_16358(pos, s -> s.method_26164(class_3481.field_15503));
    }

    /**
     * Iterate the whole layer's bounding box and fire a strand from every cell
     * where we placed a leaf this pass.
     */
    private void spawnDroopingStrandsFromAllLeafCellsInLayer(
            class_3746 world,
            class_8179 placer,
            class_5819 random,
            class_4643 config,
            class_2338 layerCenter,
            int r,
            int maxDroopLen
    ) {
        if (r <= 0) return;
        final class_2338.class_2339 p = new class_2338.class_2339();

        for (int x = -r; x <= r; x++) {
            for (int z = -r; z <= r; z++) {
                p.method_25504(layerCenter, x, 0, z);
                if (placer.method_49239(p)) {
                    // Start a strand at this exact leaf cell
                    startStrandThroughLeaves(world, placer, random, config, p, maxDroopLen);
                }
            }
        }
    }

    /**
     * Strand walker that *threads through* leaves (doesn't stop on them)
     * and only places when in replaceable space. Stops on non-replaceable.
     */
    private void startStrandThroughLeaves(
            class_3746 world,
            class_8179 placer,
            class_5819 random,
            class_4643 config,
            class_2338 sourceLeafPos,
            int maxDroopLen
    ) {
        final class_2338.class_2339 cur = new class_2338.class_2339().method_10101(sourceLeafPos).method_10098(class_2350.field_11033);
        int steps = 0;
        class_2350 preferred = class_2350.class_2353.field_11062.method_10183(random);

        while (steps < maxDroopLen) {
            if (!isLeafAt(world, cur)) {
                // Not inside leaves → try to place; fails on solid → stop
                if (!class_4647.method_34359(world, placer, random, config, cur)) {
                    break;
                }
            }
            steps++;

            // Continue?
            if (random.method_43057() > strandContinueChance) break;

            // Drift sideways sometimes
            if (random.method_43057() < driftChance) {
                class_2350 d = (random.method_43057() < 0.6f) ? preferred : class_2350.class_2353.field_11062.method_10183(random);
                cur.method_10098(d);
            }

            // Move down for next segment
            cur.method_10098(class_2350.field_11033);
        }
    }


    private static boolean withinFeatureRegion(class_1923 origin, class_2338 p) { //this is to make leaves only generate in the feature chunk
        int pcx = p.method_10263() >> 4;   // chunk X of placement
        int pcz = p.method_10260() >> 4;   // chunk Z of placement
        return Math.abs(pcx - origin.field_9181) <= 1 && Math.abs(pcz - origin.field_9180) <= 1;
    }


//    // Reuse the base helper for placing leaves (handles persistence/waterlogging via TreeFeature.canReplace)
//    private static boolean placeFoliageBlock(TestableWorld world, BlockPlacer placer, Random random, TreeFeatureConfig config, BlockPos pos) {
//        // Same semantics as the protected helper in FoliagePlacer:
//        return FoliagePlacer.placeFoliageBlock(world, placer, random, config, pos);
//    }
}
