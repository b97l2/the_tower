package mia.the_tower.initialisation.world.structure;

import com.mojang.serialization.MapCodec;
import mia.the_tower.The_Tower;
import net.minecraft.class_2378;
import net.minecraft.class_3195;
import net.minecraft.class_3773;
import net.minecraft.class_7151;
import net.minecraft.class_7923;

public class ModStructures {
    public static final class_7151<LargeGinkgoTreeStructure> LARGE_GINKGO_TREE =
            registerStructureType("large_ginkgo_tree", LargeGinkgoTreeStructure.CODEC);

    public static final class_3773 LARGE_GINKGO_TREE_PIECE =
            class_2378.method_10230(
                    class_7923.field_41146,
                    The_Tower.id("large_ginkgo_tree_piece"),
                    (class_3773.class_6615) LargeGinkgoTreePiece::new
            );

    public static void init() {}

    private static <S extends class_3195> class_7151<S> registerStructureType(String name, MapCodec<S> codec) {
        return class_2378.method_10230(class_7923.field_41147, The_Tower.id(name), () -> codec);
    }
}
