package mia.the_tower.initialisation.world.structure;

import mia.the_tower.The_Tower;
import net.minecraft.class_1959;
import net.minecraft.class_2893;
import net.minecraft.class_3195;
import net.minecraft.class_5321;
import net.minecraft.class_5847;
import net.minecraft.class_6862;
import net.minecraft.class_6872;
import net.minecraft.class_6873;
import net.minecraft.class_7059;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import java.util.Map;

public class ModStructureData {
    public static final class_5321<class_3195> LARGE_GINKGO_TREE =
            class_5321.method_29179(class_7924.field_41246, The_Tower.id("large_ginkgo_tree"));
    public static final class_5321<class_7059> LARGE_GINKGO_TREES =
            class_5321.method_29179(class_7924.field_41248, The_Tower.id("large_ginkgo_trees"));
    public static final class_6862<class_1959> HAS_LARGE_GINKGO_TREE =
            class_6862.method_40092(class_7924.field_41236, The_Tower.id("has_structure/large_ginkgo_tree"));

    public static void bootstrapStructures(class_7891<class_3195> context) {
        var biomes = context.method_46799(class_7924.field_41236);
        context.method_46838(
                LARGE_GINKGO_TREE,
                new LargeGinkgoTreeStructure(new class_3195.class_7302(
                        biomes.method_46735(HAS_LARGE_GINKGO_TREE),
                        Map.of(),
                        class_2893.class_2895.field_13173,
                        class_5847.field_28922
                ))
        );
    }

    public static void bootstrapStructureSets(class_7891<class_7059> context) {
        var structures = context.method_46799(class_7924.field_41246);
        context.method_46838(
                LARGE_GINKGO_TREES,
                new class_7059(
                        structures.method_46747(LARGE_GINKGO_TREE),
                        new class_6872(11, 9, class_6873.field_36421, 19402154)
                )
        );
    }
}
