package mia.the_tower.initialisation.world.structure;

import com.mojang.serialization.MapCodec;
import java.util.Optional;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2902;
import net.minecraft.class_3195;
import net.minecraft.class_7151;

public class LargeGinkgoTreeStructure extends class_3195 {
    public static final MapCodec<LargeGinkgoTreeStructure> CODEC = method_42699(LargeGinkgoTreeStructure::new);

    public LargeGinkgoTreeStructure(class_7302 config) {
        super(config);
    }

    @Override
    protected Optional<class_7150> method_38676(class_7149 context) {
        class_1923 chunkPos = context.comp_568();
        int x = chunkPos.method_33940();
        int z = chunkPos.method_33942();
        int y = context.comp_562().method_20402(
                x,
                z,
                class_2902.class_2903.field_13203,
                context.comp_569(),
                context.comp_564()
        );

        if (y < context.comp_569().method_31607() + LargeGinkgoTreePiece.VERTICAL_RADIUS_DOWN
                || y + LargeGinkgoTreePiece.VERTICAL_RADIUS_UP > context.comp_569().method_31600()) {
            return Optional.empty();
        }

        class_2338 origin = new class_2338(x, y, z);
        long treeSeed = context.comp_566().method_43055();
        return Optional.of(new class_7150(origin, collector ->
                collector.method_35462(new LargeGinkgoTreePiece(origin, treeSeed))
        ));
    }

    @Override
    public class_7151<?> method_41618() {
        return ModStructures.LARGE_GINKGO_TREE;
    }
}
