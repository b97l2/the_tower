package mia.the_tower.initialisation.world.structure;

import mia.the_tower.initialisation.block_init;
import mia.the_tower.initialisation.world.tree.GiantFoliagePlacer;
import mia.the_tower.initialisation.world.tree.GiantTrunkPlacer;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2794;
import net.minecraft.class_2902;
import net.minecraft.class_3341;
import net.minecraft.class_3443;
import net.minecraft.class_3610;
import net.minecraft.class_3746;
import net.minecraft.class_4643;
import net.minecraft.class_4647;
import net.minecraft.class_4651;
import net.minecraft.class_5138;
import net.minecraft.class_5204;
import net.minecraft.class_5281;
import net.minecraft.class_5819;
import net.minecraft.class_6016;
import net.minecraft.class_6019;
import net.minecraft.class_6625;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.Predicate;

public class LargeGinkgoTreePiece extends class_3443 {
    public static final int HORIZONTAL_RADIUS = 96;
    public static final int VERTICAL_RADIUS_DOWN = 16;
    public static final int VERTICAL_RADIUS_UP = 250;
    private static final int TRUNK_EMBED_DEPTH = 10;

    private final class_2338 origin;
    private final long treeSeed;

    public LargeGinkgoTreePiece(class_2338 origin, long treeSeed) {
        super(ModStructures.LARGE_GINKGO_TREE_PIECE, 0, createBoundingBox(origin));
        this.origin = origin;
        this.treeSeed = treeSeed;
    }

    public LargeGinkgoTreePiece(class_2487 nbt) {
        super(ModStructures.LARGE_GINKGO_TREE_PIECE, nbt);
        this.origin = new class_2338(nbt.method_10550("OriginX"), nbt.method_10550("OriginY"), nbt.method_10550("OriginZ"));
        this.treeSeed = nbt.method_10537("TreeSeed");
    }

    private static class_3341 createBoundingBox(class_2338 origin) {
        return new class_3341(
                origin.method_10263() - HORIZONTAL_RADIUS,
                origin.method_10264() - VERTICAL_RADIUS_DOWN,
                origin.method_10260() - HORIZONTAL_RADIUS,
                origin.method_10263() + HORIZONTAL_RADIUS,
                origin.method_10264() + VERTICAL_RADIUS_UP,
                origin.method_10260() + HORIZONTAL_RADIUS
        );
    }

    @Override
    protected void method_14943(class_6625 context, class_2487 nbt) {
        nbt.method_10569("OriginX", this.origin.method_10263());
        nbt.method_10569("OriginY", this.origin.method_10264());
        nbt.method_10569("OriginZ", this.origin.method_10260());
        nbt.method_10544("TreeSeed", this.treeSeed);
    }

    @Override
    public void method_14931(
            class_5281 world,
            class_5138 structureAccessor,
            class_2794 chunkGenerator,
            class_5819 random,
            class_3341 chunkBox,
            class_1923 chunkPos,
            class_2338 pivot
    ) {
        Map<Long, class_2680> states = this.generateTreeStates();
        for (Map.Entry<Long, class_2680> entry : states.entrySet()) {
            class_2338 pos = class_2338.method_10092(entry.getKey());
            if (chunkBox.method_14662(pos)
                    && this.field_15315.method_14662(pos)
                    && !world.method_31606(pos)
                    && world.method_37368(pos)) {
                world.method_8652(pos, entry.getValue(), class_2248.field_31028);
                class_3610 fluidState = world.method_8316(pos);
                if (!fluidState.method_15769()) {
                    world.method_64312(pos, fluidState.method_15772(), 0);
                }
            }
        }
    }

    private Map<Long, class_2680> generateTreeStates() {
        Map<Long, class_2680> states = new LinkedHashMap<>();
        Set<Long> foliagePositions = new HashSet<>();
        class_4643 config = createTreeConfig();
        class_2338 treeStart = this.origin.method_10087(TRUNK_EMBED_DEPTH);
        GeneratedTreeWorld treeWorld = new GeneratedTreeWorld(treeStart, states);
        class_5819 random = class_5819.method_43049(this.treeSeed);

        int trunkHeight = config.field_24136.method_26993(random);
        int foliageHeight = config.field_24135.method_26989(random, trunkHeight, config);
        int foliageBaseHeight = trunkHeight - foliageHeight;
        int foliageRadius = config.field_24135.method_23452(random, foliageBaseHeight);

        BiConsumer<class_2338, class_2680> trunkPlacer = (pos, state) ->
                states.put(pos.method_10063(), state);
        class_4647.class_8179 foliagePlacer = new class_4647.class_8179() {
            @Override
            public void method_49240(class_2338 pos, class_2680 state) {
                long packedPos = pos.method_10063();
                foliagePositions.add(packedPos);
                states.put(packedPos, state);
            }

            @Override
            public boolean method_49239(class_2338 pos) {
                return foliagePositions.contains(pos.method_10063());
            }
        };

        GiantFoliagePlacer.DISABLE_FEATURE_REGION_LIMIT.set(true);
        try {
            List<class_4647.class_5208> treeNodes =
                    config.field_24136.method_26991(treeWorld, trunkPlacer, random, trunkHeight, treeStart, config);
            for (class_4647.class_5208 treeNode : treeNodes) {
                config.field_24135.method_27385(
                        treeWorld,
                        foliagePlacer,
                        random,
                        config,
                        trunkHeight,
                        treeNode,
                        foliageHeight,
                        foliageRadius
                );
            }
        } finally {
            GiantFoliagePlacer.DISABLE_FEATURE_REGION_LIMIT.remove();
        }

        return states;
    }

    private static class_4643 createTreeConfig() {
        return new class_4643.class_4644(
                class_4651.method_38432(block_init.GINKGO_LOG),
                new GiantTrunkPlacer(50, 88, 95, 15, 3, 0.5f, 0.3f, 3, 0.4f, 0.8f, 3.5f),
                class_4651.method_38432(block_init.GINKGO_LEAVES),
                new GiantFoliagePlacer(
                        class_6016.method_34998(14),
                        class_6016.method_34998(0),
                        class_6019.method_35017(18, 42),
                        1f,
                        0.90f,
                        0.30f,
                        0.70f,
                        2
                ),
                new class_5204(3, 0, 4)
        ).method_23445();
    }

    private static class GeneratedTreeWorld implements class_3746 {
        private static final class_2680 AIR = class_2246.field_10124.method_9564();
        private static final class_2680 SOLID_GROUND = class_2246.field_10340.method_9564();

        private final class_2338 origin;
        private final Map<Long, class_2680> generatedStates;

        private GeneratedTreeWorld(class_2338 origin, Map<Long, class_2680> generatedStates) {
            this.origin = origin;
            this.generatedStates = generatedStates;
        }

        @Override
        public boolean method_16358(class_2338 pos, Predicate<class_2680> predicate) {
            return predicate.test(this.getState(pos));
        }

        @Override
        public boolean method_35237(class_2338 pos, Predicate<class_3610> predicate) {
            return predicate.test(this.getState(pos).method_26227());
        }

        @Override
        public <T extends class_2586> Optional<T> method_35230(class_2338 pos, class_2591<T> type) {
            return Optional.empty();
        }

        @Override
        public class_2338 method_8598(class_2902.class_2903 heightmap, class_2338 pos) {
            return new class_2338(pos.method_10263(), this.origin.method_10264(), pos.method_10260());
        }

        private class_2680 getState(class_2338 pos) {
            class_2680 generatedState = this.generatedStates.get(pos.method_10063());
            if (generatedState != null) {
                return generatedState;
            }
            return pos.method_10264() >= this.origin.method_10264() ? AIR : SOLID_GROUND;
        }
    }
}
