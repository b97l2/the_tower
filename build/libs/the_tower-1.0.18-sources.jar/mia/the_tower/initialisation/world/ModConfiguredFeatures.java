package mia.the_tower.initialisation.world;

import mia.the_tower.initialisation.block_init;
import mia.the_tower.initialisation.util.CustomTags;
import mia.the_tower.initialisation.world.misc.DecoratedPitPlacer;
import mia.the_tower.initialisation.world.ore.SheetOreFeature;
import mia.the_tower.initialisation.world.tree.GiantFoliagePlacer;
import mia.the_tower.initialisation.world.tree.DeadGinkgoFeature;
import mia.the_tower.initialisation.world.tree.MediumTrunkPlacer;
import mia.the_tower.initialisation.world.vegetation.SurfaceDecorativeBlockFeature;
import mia.the_tower.initialisation.world.vegetation.TripleAwareSimpleBlockFeature;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_3111;
import net.minecraft.class_3124;
import net.minecraft.class_3175;
import net.minecraft.class_3798;
import net.minecraft.class_3825;
import net.minecraft.class_4638;
import net.minecraft.class_4643;
import net.minecraft.class_4651;
import net.minecraft.class_4657;
import net.minecraft.class_5204;
import net.minecraft.class_5216;
import net.minecraft.class_5321;
import net.minecraft.class_6005;
import net.minecraft.class_6016;
import net.minecraft.class_6019;
import net.minecraft.class_6580;
import net.minecraft.class_6646;
import net.minecraft.class_6803;
import net.minecraft.class_6817;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.world.gen.feature.*;
import java.util.List;
//relevant mc files to look at: VegetationConfiguredFeatures
public class ModConfiguredFeatures {

    //for features, start here
    //to load a feature, it needs a line here

    //ore
    public static final class_5321<class_2975<?, ?>> AFHD_KEY = registerKey("afhd");
    public static final class_5321<class_2975<?, ?>> DRAGONS_EYE_ORE_KEY = registerKey("dragons_eye_ore");
    public static final class_5321<class_2975<?, ?>> ITORE_KEY = registerKey("itore");
    public static final class_5321<class_2975<?, ?>> JADE_ORE_KEY = registerKey("jade_ore");
    public static final class_5321<class_2975<?, ?>> KAOLIN_SHEET_ORE_KEY = registerKey("kaolin_sheet_ore");
    public static final class_5321<class_2975<?, ?>> SILVER_ORE_KEY = registerKey("silver_ore");
    public static final class_5321<class_2975<?, ?>> SLATE_SHEET_ORE_KEY = registerKey("slate_sheet_ore");
    public static final class_5321<class_2975<?, ?>> SILVER_VEIN_KEY = registerKey("silver_vein");

    //tree
    public static final class_5321<class_2975<?, ?>> GINKGO_KEY = registerKey("ginkgo");
    public static final class_5321<class_2975<?, ?>> DEAD_GINKGO_KEY = registerKey("dead_ginkgo");
    public static final class_5321<class_2975<?, ?>> VAULTS_STANCHION_KEY = registerKey("vaults_stanchion");

    //vegetation
    public static final class_5321<class_2975<?, ?>> CERULEAN_GRASS_PATCH_KEY = registerKey("cerulean_grass_patch");
    public static final class_5321<class_2975<?, ?>> SUNKISSED_SHORTGRASS_PATCH_KEY = registerKey("sunkissed_shortgrass_patch");
    public static final class_5321<class_2975<?, ?>> CERULEAN_COAST_FLOWERS_PATCH_KEY = registerKey("cerulean_coast_flowers_patch_key");
    public static final class_5321<class_2975<?, ?>> PILE_OF_MEAT_KEY = registerKey("pile_of_meat");

    //other
    public static final class_5321<class_2975<?, ?>> DECORATED_PIT_KEY = registerKey("decorated_pit_key");



    public static void bootstrap(class_7891<class_2975<?, ?>> context) {

        //ore
        //this dictates which blocks the ore can replace
        class_3825 ceruleanCoastReplaceables = new class_3798(CustomTags.Blocks.CERULEAN_COAST_REPLACEABLE);
        class_3825 goldenWealdReplaceables = new class_3798(CustomTags.Blocks.GOLDEN_WEALD_REPLACEABLE);
        class_3825 shadowlandsReplaceables = new class_3798(CustomTags.Blocks.SHADOWLANDS_REPLACEABLE);
        //This is where each type of ore is defined
        List<class_3124.class_5876> frageAfhdOres =
                List.of(class_3124.method_33994(ceruleanCoastReplaceables, block_init.AFHD.method_9564())
                        //can include other variations of the same ore, eg iron in deepslate and not rock
                        //OreFeatureConfig.createTarget(shadowlandsReplaceables, block_init.RANDOM_ORE.getDefaultState())
                        );
        List<class_3124.class_5876> frageDragonsEyeOres =
                List.of(class_3124.method_33994(ceruleanCoastReplaceables, block_init.DRAGONS_EYE_ORE.method_9564()));
        List<class_3124.class_5876> frageSilverOres =
                List.of(class_3124.method_33994(ceruleanCoastReplaceables, block_init.SILVER_ORE.method_9564()));
        List<class_3124.class_5876> frageSlateSheetOres =
                List.of(class_3124.method_33994(ceruleanCoastReplaceables, block_init.SLATE.method_9564()));
        List<class_3124.class_5876> frageSilverVeinOres =
                List.of(class_3124.method_33994(ceruleanCoastReplaceables, block_init.SILVER_VEIN.method_9564()));
        List<class_3124.class_5876> frageItoreOres =
                List.of(class_3124.method_33994(shadowlandsReplaceables, block_init.ITORE.method_9564()));
        List<class_3124.class_5876> frageJadeOres =
                List.of(class_3124.method_33994(goldenWealdReplaceables, block_init.UNCUT_JADEITE_STONE.method_9564()));
        List<class_3124.class_5876> frageKaolinSheetOres =
                List.of(class_3124.method_33994(goldenWealdReplaceables, block_init.KAOLIN.method_9564()));
        //this defines how big the vein is with the size parameter
        register(context, AFHD_KEY, class_3031.field_13517, new class_3124(frageAfhdOres, 40));
        register(context, DRAGONS_EYE_ORE_KEY, class_3031.field_13517, new class_3124(frageDragonsEyeOres, 9));
        register(context, ITORE_KEY, class_3031.field_13517, new class_3124(frageItoreOres, 3));
        register(context, JADE_ORE_KEY, SheetOreFeature.SHEET_ORE,
                new SheetOreFeature.Config(frageJadeOres, class_6019.method_35017(17, 24),
                        class_6016.method_34998(4), 1.0F, 0.0F));
        register(context, KAOLIN_SHEET_ORE_KEY, SheetOreFeature.SHEET_ORE,
                new SheetOreFeature.Config(frageKaolinSheetOres, class_6019.method_35017(25, 32),
                        class_6019.method_35017(2, 5), 1.0F, 0.0F));
        register(context, SILVER_ORE_KEY, class_3031.field_13517, new class_3124(frageSilverOres, 25));
        register(context, SLATE_SHEET_ORE_KEY, SheetOreFeature.SHEET_ORE,
                new SheetOreFeature.Config(frageSlateSheetOres, class_6019.method_35017(10, 25),
                        class_6019.method_35017(1, 3), 0.9F, 0.0F));
        register(context, SILVER_VEIN_KEY, class_3031.field_13517, new class_3124(frageSilverVeinOres, 9));

        //for tree
        //this one for ginkgo tree looks good but is way to resource intensive for a feature, it will be used as a structure instead
//        register(context, GINKGO_KEY, Feature.TREE, new TreeFeatureConfig.Builder(
//                BlockStateProvider.of(block_init.GINKGO_LOG),
//                new GiantTrunkPlacer(5, 88, 95, 15, 3,0.5f,  0.3f, 3, 0.4f, 0.8f, 3.5f),
//
//                BlockStateProvider.of(block_init.GINKGO_LEAVES),
//                new GiantFoliagePlacer(        ConstantIntProvider.create(14),   // radius seed (big crowns)
//                        ConstantIntProvider.create(0),    // offset seed
//                        UniformIntProvider.create(18, 42),// max_droop: long hanging curtains
//                        1f,                            //how round the top is, 0 is flat, 1 is very round (capped at 16 layers)
//                        0.90f,                            // strand_continue_chance
//                        0.30f,                            // drift_chance
//                        0.70f,                            // vertical_taper (radius loss per layer)
//                        2                                 // layer_fuzz (+/-)
//                        ),
//                new TwoLayersFeatureSize(3, 0, 4)).build());
        register(context, GINKGO_KEY, class_3031.field_24134, new class_4643.class_4644(
                class_4651.method_38432(block_init.GINKGO_LOG),
                new MediumTrunkPlacer(16, 48, 35, 3, 1,0.5f,  0.3f, 2, 0.4f, 0.8f, 3.5f),

                class_4651.method_38432(block_init.GINKGO_LEAVES),
                new GiantFoliagePlacer(        class_6016.method_34998(4),   // radius seed (big crowns)
                        class_6016.method_34998(0),    // offset seed
                        class_6019.method_35017(10, 20),// max_droop: long hanging curtains
                        1f,                            //how round the top is, 0 is flat, 1 is very round (capped at 16 layers)
                        0.90f,                            // strand_continue_chance
                        0.30f,                            // drift_chance
                        0.70f,                            // vertical_taper (radius loss per layer)
                        2                                 // layer_fuzz (+/-)
                ),
                new class_5204(3, 0, 4)).method_23445());

        register(context, DEAD_GINKGO_KEY, DeadGinkgoFeature.DEAD_GINKGO, class_3111.field_24894);

        register(context, VAULTS_STANCHION_KEY, class_3031.field_24134, new class_4643.class_4644(
                class_4651.method_38432(block_init.GINKGO_LOG),
                new MediumTrunkPlacer(35, 55, 25, 2, 1,0.5f,  0.3f, 1, 0.7f, 0.8f, 5.5f),

                class_4651.method_38432(block_init.GINKGO_LEAVES),
                new GiantFoliagePlacer(        class_6016.method_34998(3),   // radius seed (big crowns)
                        class_6016.method_34998(0),    // offset seed
                        class_6019.method_35017(10, 20),// max_droop: long hanging curtains
                        1f,                            //how round the top is, 0 is flat, 1 is very round (capped at 16 layers)
                        0.90f,                            // strand_continue_chance
                        0.05f,                            // drift_chance
                        0.4f,                            // vertical_taper (radius loss per layer)
                        1                                 // layer_fuzz (+/-)
                ),
                new class_5204(3, 0, 4)).method_23445());

        //for vegetation
        class_6803.method_39708(
                context,
                CERULEAN_GRASS_PATCH_KEY,
                class_3031.field_21220,
                class_6803.method_39704(class_3031.field_13518,
                        new class_3175(new class_6580( //this is for multiple types of blocks
                                2345L,
                                new class_5216.class_5487(0, 1.0),
                                0.020833334F,
                                List.of(
                                        block_init.CERULEAN_SHORTGRASS.method_9564(),
                                        block_init.CERULEAN_WILDGRASS.method_9564()
                                )
                        ))));
        class_6803.method_39708(
                context,
                CERULEAN_COAST_FLOWERS_PATCH_KEY,
                class_3031.field_21220,
                new class_4638(
                        64, // tries per patch
                        6,  // xz spread
                        2,  // y spread
                        class_6817.method_40367(
                                TripleAwareSimpleBlockFeature.TRIPLE_AWARE_SIMPLE_BLOCK,
                                new class_3175(
                                        new class_4657(
                                                class_6005.<class_2680>method_34971() //this gives weighted distribution within a single patch
                                                        .method_34975(block_init.SAPPHIRE_ROSE.method_9564(), 2)
                                                        .method_34975(block_init.BLUE_BELL.method_9564(), 3)
                                                        .method_34975(block_init.BLUE_FOXGLOVE.method_9564(), 1)
                                                        .method_34975(block_init.BLUE_HOSTAS.method_9564(), 4)
                                                        .method_34975(block_init.CERULEAN_PETALS.method_9564(), 7)
                                                // add more plants + weights as you like
                                        )
                                ),
                                // Optional: add survival/ground predicates so every variant checks it can live
                                class_6646.method_38882(
                                        class_6646.field_35696,
                                        class_6646.method_39009(block_init.CERULEAN_WILDGRASS.method_9564(), class_2338.field_10980)
                                )
                        )
                )
        );
        class_6803.method_39708(
                context,
                SUNKISSED_SHORTGRASS_PATCH_KEY,
                class_3031.field_21220,
                new class_4638(
                        512,
                        16,
                        4,
                        class_6817.method_40367(
                                class_3031.field_13518,
                                new class_3175(class_4651.method_38432(block_init.SUNKISSED_SHORTGRASS)),
                                class_6646.method_38882(
                                        class_6646.field_35696,
                                        class_6646.method_39009(block_init.SUNKISSED_SHORTGRASS.method_9564(), class_2338.field_10980)
                                )
                        )
                )
        );
        //add one here for cerulean petals, also with randomised direction and amount (not sure how to do. look at vanilla)

        class_2680 pileOfMeat = block_init.PILE_OF_MEAT.method_9564();
        register(
                context,
                PILE_OF_MEAT_KEY,
                SurfaceDecorativeBlockFeature.SURFACE_DECORATIVE_BLOCK,
                new SurfaceDecorativeBlockFeature.Config(
                        new class_4657(
                                class_6005.<class_2680>method_34971()
                                        .method_34975(pileOfMeat.method_11657(class_2741.field_12481, class_2350.field_11043), 1)
                                        .method_34975(pileOfMeat.method_11657(class_2741.field_12481, class_2350.field_11034), 1)
                                        .method_34975(pileOfMeat.method_11657(class_2741.field_12481, class_2350.field_11035), 1)
                                        .method_34975(pileOfMeat.method_11657(class_2741.field_12481, class_2350.field_11039), 1)
                        ),
                        0
                )
        );

        //other
        class_4651 pitSurfaceProvider = new class_4657(
                class_6005.<class_2680>method_34971()
                        .method_34975(block_init.VEINS.method_9564(), 5)   // weight 5
                        .method_34975(class_2246.field_10124.method_9564(), 3)
                        .method_34974()
        );
        register(
                context,
                DECORATED_PIT_KEY,
                DecoratedPitPlacer.DECORATED_PIT,   // Feature<DecoratedPitPlacer.Config>
                new DecoratedPitPlacer.Config(
                        class_6019.method_35017(4, 12),   // radius range
                        class_6019.method_35017(50, 170),   // depth range
                        pitSurfaceProvider                 // weighted inner-surface blocks
                )
        );



        //for features you want naturally generated in the world (incl ore), then we go into ModPlacedFeatures

    }



//this is the method to load a configured feature
    public static class_5321<class_2975<?, ?>> registerKey(String name) {
        return class_5321.method_29179(class_7924.field_41239, class_2960.method_60655("the_tower", name));
    }

    private static <FC extends class_3037, F extends class_3031<FC>> void register(class_7891<class_2975<?, ?>> context,
                                                                                   class_5321<class_2975<?, ?>> key, F feature, FC configuration) {
        context.method_46838(key, new class_2975<>(feature, configuration));
    }
}
