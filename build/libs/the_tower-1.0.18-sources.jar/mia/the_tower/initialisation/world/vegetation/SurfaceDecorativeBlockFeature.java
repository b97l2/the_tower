package mia.the_tower.initialisation.world.vegetation;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2378;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_4651;
import net.minecraft.class_5281;
import net.minecraft.class_5431;
import net.minecraft.class_5821;
import net.minecraft.class_7923;

public class SurfaceDecorativeBlockFeature extends class_3031<SurfaceDecorativeBlockFeature.Config> {
    public static record Config(
            class_4651 toPlace,
            int minY
    ) implements class_3037 {
        public static final Codec<Config> CODEC = RecordCodecBuilder.create(instance ->
                instance.group(
                        class_4651.field_24937
                                .fieldOf("to_place")
                                .forGetter(Config::toPlace),
                        Codec.INT
                                .fieldOf("min_y")
                                .forGetter(Config::minY)
                ).apply(instance, Config::new)
        );
    }

    public SurfaceDecorativeBlockFeature() {
        super(Config.CODEC);
    }

    public static final class_3031<Config> SURFACE_DECORATIVE_BLOCK =
            class_2378.method_10230(
                    class_7923.field_41144,
                    class_2960.method_60655("the_tower", "surface_decorative_block"),
                    new SurfaceDecorativeBlockFeature()
            );

    public static void init() {}

    @Override
    public boolean method_13151(class_5821<Config> context) {
        Config config = context.method_33656();
        class_5281 world = context.method_33652();
        class_2338 pos = context.method_33655();

        if (pos.method_10264() < config.minY()) {
            return false;
        }

        if (!world.method_8320(pos).method_26215()) {
            return false;
        }

        class_2338 surfacePos = pos.method_10074();
        class_2680 surfaceState = world.method_8320(surfacePos);
        if (!surfaceState.method_30368(world, surfacePos, class_2350.field_11036, class_5431.field_25822)) {
            return false;
        }

        class_2680 state = config.toPlace().method_23455(context.method_33654(), pos);
        if (!state.method_26184(world, pos)) {
            return false;
        }

        return world.method_8652(pos, state, class_2248.field_31036);
    }
}
