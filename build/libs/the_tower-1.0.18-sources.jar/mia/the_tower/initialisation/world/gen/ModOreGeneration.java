package mia.the_tower.initialisation.world.gen;

import mia.the_tower.initialisation.biomes.CeruleanCoast;
import mia.the_tower.initialisation.biomes.GoldenWeald;
import mia.the_tower.initialisation.biomes.Shadowlands;
import mia.the_tower.initialisation.world.ModPlacedFeatures;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.class_2893;

public class ModOreGeneration {
    public static void generateOres() {
        //tell where your ore generates in here
        //for multiple biomes, you just include a , after the first one and write another
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(CeruleanCoast.CERULEAN_COAST), class_2893.class_2895.field_13176,
                ModPlacedFeatures.DRAGONS_EYE_ORE_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(CeruleanCoast.CERULEAN_COAST), class_2893.class_2895.field_13176,
                ModPlacedFeatures.AFHD_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(Shadowlands.SHADOWLANDS), class_2893.class_2895.field_13176,
                ModPlacedFeatures.ITORE_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(CeruleanCoast.CERULEAN_COAST), class_2893.class_2895.field_13176,
                ModPlacedFeatures.SILVER_ORE_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(CeruleanCoast.CERULEAN_COAST), class_2893.class_2895.field_13176,
                ModPlacedFeatures.SLATE_SHEET_ORE_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(CeruleanCoast.CERULEAN_COAST), class_2893.class_2895.field_13176,
                ModPlacedFeatures.SLATE_SHEET_ORE_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(GoldenWeald.GOLDEN_WEALD), class_2893.class_2895.field_13176,
                ModPlacedFeatures.KAOLIN_SHEET_ORE_PLACED_KEY);
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(GoldenWeald.GOLDEN_WEALD), class_2893.class_2895.field_13176,
                ModPlacedFeatures.JADE_ORE_PLACED_KEY);

        //then last of all, go to the biome class and include the ore there
    }
}
