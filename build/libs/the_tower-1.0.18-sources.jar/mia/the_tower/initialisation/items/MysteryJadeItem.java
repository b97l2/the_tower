package mia.the_tower.initialisation.items;

import mia.the_tower.initialisation.block_init;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_5819;

public class MysteryJadeItem extends class_1792 {
    public MysteryJadeItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public void method_54465(class_1799 stack, class_1937 world, class_1657 player) {
        super.method_54465(stack, world, player);
        if (world instanceof class_3218 serverWorld) {
            serverWorld.method_8503().method_63588(
                    serverWorld.method_8503().method_16209(() -> resolvePlayerStacks(player)));
        }
    }

    @Override
    public void method_7888(class_1799 stack, class_1937 world, class_1297 entity, int slot, boolean selected) {
        if (!world.field_9236 && entity instanceof class_1657 player && stack.method_31574(this)) {
            player.method_31548().method_5447(slot, createResult(player.method_59922()));
        }
    }

    private void resolvePlayerStacks(class_1657 player) {
        class_1799 cursorStack = player.field_7512.method_34255();
        if (cursorStack.method_31574(this)) {
            player.field_7512.method_34254(createResult(player.method_59922()));
        }

        for (int slot = 0; slot < player.method_31548().method_5439(); slot++) {
            if (player.method_31548().method_5438(slot).method_31574(this)) {
                player.method_31548().method_5447(slot, createResult(player.method_59922()));
            }
        }
    }

    private static class_1799 createResult(class_5819 random) {
        int roll = random.method_43048(1000);

        if (roll == 0) {
            return new class_1799(block_init.PHOENIX_BLOOD_JADE_BLOCK);
        }
        if (roll == 1) {
            return new class_1799(block_init.HEAVENLY_DEW_JADE_BLOCK);
        }
        if (roll < 7) {
            return new class_1799(block_init.IMPERIAL_JADE_BLOCK);
        }
        if (roll < 12) {
            return new class_1799(block_init.LOTUS_JADE_BLOCK);
        }
        if (roll < 32) {
            return new class_1799(block_init.BLOOD_JADE_BLOCK);
        }
        if (roll < 52) {
            return new class_1799(block_init.LAVENDER_JADE_BLOCK);
        }
        if (roll < 72) {
            return new class_1799(block_init.GOLDEN_THREAD_JADE_BLOCK);
        }
        if (roll < 122) {
            return new class_1799(block_init.MUTTON_FAT_JADE_BLOCK);
        }
        return new class_1799(block_init.JADEITE_BLOCK);
    }
}
