package mia.the_tower.initialisation.items;


import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1675;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_2394;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_5819;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

public class AzureWandItem extends class_1792 {

    private final class_2394 customParticle;

    private static final double MAX_DISTANCE = 64.0;
    private static final float DAMAGE = 5.0F;
    private static final double KNOCKBACK_STRENGTH = 1.6;
    private static final double KNOCKBACK_LIFT = 0.25;
    private static final double BOLT_STEP = 0.45;
    private static final int BOLT_SEGMENTS = 12;
    private static final double BOLT_JITTER = 0.65;
    private static final int BOLT_TRAVEL_TICKS = 4;
    private static final Map<class_3218, List<ScheduledParticle>> SCHEDULED_PARTICLES = new WeakHashMap<>();

    public static void init() {
        ServerTickEvents.END_WORLD_TICK.register(AzureWandItem::spawnScheduledParticles);
    }

    public AzureWandItem(class_2394 customParticle,
                         class_1793 settings) {
        super(settings);
        this.customParticle = customParticle;
    }

    @Override
    public void method_59978(class_1799 stack, class_1309 target, class_1309 attacker) {
        stack.method_7970(1, attacker, class_1304.field_6173);
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);

        if (!(world instanceof class_3218 serverWorld)) {
            return class_1269.field_5812;
        }

        class_243 start = user.method_33571();
        class_243 direction = user.method_5828(1.0F);
        class_243 end = start.method_1019(direction.method_1021(MAX_DISTANCE));

        class_3965 blockHit = serverWorld.method_17742(new class_3959(
                start,
                end,
                class_3959.class_3960.field_17558,
                class_3959.class_242.field_1348,
                user
        ));

        class_243 blockTarget = blockHit.method_17783() == class_239.class_240.field_1332 ? blockHit.method_17784() : end;
        class_3966 entityHit = findEntityHit(user, start, blockTarget);
        class_243 target = entityHit != null ? entityHit.method_17784() : blockTarget;

        spawnBolt(serverWorld, start, target);

        if (entityHit != null) {
            class_1297 targetEntity = entityHit.method_17782();
            targetEntity.method_64397(serverWorld, user.method_48923().method_48802(user), DAMAGE);
            targetEntity.method_60491(direction.method_1021(KNOCKBACK_STRENGTH).method_1031(0.0, KNOCKBACK_LIFT, 0.0));
            targetEntity.field_6037 = true;
        }

        class_1304 equipmentSlot = stack.equals(user.method_6118(class_1304.field_6171)) ? class_1304.field_6171 : class_1304.field_6173;
        stack.method_7970(1, user, equipmentSlot);

        return class_1269.field_5812;
    }

    private static class_3966 findEntityHit(class_1657 user, class_243 start, class_243 end) {
        class_243 ray = end.method_1020(start);
        class_238 searchBox = user.method_5829().method_18804(ray).method_1014(1.0);
        double maxDistanceSquared = start.method_1025(end);

        return class_1675.method_18075(
                user,
                start,
                end,
                searchBox,
                entity -> entity != user && !entity.method_7325() && entity.method_5805() && entity.method_5863(),
                maxDistanceSquared
        );
    }

    private void spawnBolt(class_3218 world, class_243 start, class_243 end) {
        class_243 ray = end.method_1020(start);
        double length = ray.method_1033();
        if (length < 1.0e-6) {
            return;
        }

        class_243 direction = ray.method_1029();
        class_243 reference = Math.abs(direction.field_1351) > 0.9 ? new class_243(1.0, 0.0, 0.0) : new class_243(0.0, 1.0, 0.0);
        class_243 right = direction.method_1036(reference).method_1029();
        class_243 up = right.method_1036(direction).method_1029();

        class_5819 random = world.method_8409();
        class_243 previous = start;
        for (int i = 1; i <= BOLT_SEGMENTS; i++) {
            double progress = (double) i / BOLT_SEGMENTS;
            class_243 point = start.method_1019(ray.method_1021(progress));

            if (i < BOLT_SEGMENTS) {
                double taper = Math.sin(Math.PI * progress);
                double rightOffset = random.method_43385(0.0, BOLT_JITTER) * taper;
                double upOffset = random.method_43385(0.0, BOLT_JITTER) * taper;
                point = point.method_1019(right.method_1021(rightOffset)).method_1019(up.method_1021(upOffset));
            }

            spawnBoltSegment(world, previous, point, i - 1);
            previous = point;
        }
    }

    private void spawnBoltSegment(class_3218 world, class_243 start, class_243 end, int segmentIndex) {
        class_243 segment = end.method_1020(start);
        double length = segment.method_1033();
        int particleCount = Math.max(1, (int) Math.ceil(length / BOLT_STEP));

        for (int i = 0; i <= particleCount; i++) {
            class_243 pos = start.method_1019(segment.method_1021((double) i / particleCount));
            double pathProgress = (segmentIndex + (double) i / particleCount) / BOLT_SEGMENTS;
            int delay = (int) Math.round(pathProgress * BOLT_TRAVEL_TICKS);

            if (delay == 0) {
                spawnParticle(world, this.customParticle, pos);
            } else {
                SCHEDULED_PARTICLES.computeIfAbsent(world, ignored -> new ArrayList<>())
                        .add(new ScheduledParticle(world.method_8510() + delay, this.customParticle, pos));
            }
        }
    }

    private static void spawnScheduledParticles(class_3218 world) {
        List<ScheduledParticle> particles = SCHEDULED_PARTICLES.get(world);
        if (particles == null) {
            return;
        }

        Iterator<ScheduledParticle> iterator = particles.iterator();
        while (iterator.hasNext()) {
            ScheduledParticle particle = iterator.next();
            if (particle.spawnTick() <= world.method_8510()) {
                spawnParticle(world, particle.effect(), particle.position());
                iterator.remove();
            }
        }

        if (particles.isEmpty()) {
            SCHEDULED_PARTICLES.remove(world);
        }
    }

    private static void spawnParticle(class_3218 world, class_2394 effect, class_243 pos) {
        world.method_65096(
                effect,
                pos.field_1352, pos.field_1351, pos.field_1350,
                1,
                0.0, 0.0, 0.0,
                0.0
        );
    }

    private record ScheduledParticle(long spawnTick, class_2394 effect, class_243 position) {
    }
}
