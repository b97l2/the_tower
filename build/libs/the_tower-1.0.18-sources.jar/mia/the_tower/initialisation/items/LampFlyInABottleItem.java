package mia.the_tower.initialisation.items;

import mia.the_tower.initialisation.entity.ModEntities;
import mia.the_tower.initialisation.entity.custom.LampFlyEntity;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3730;
import net.minecraft.class_5328;
import net.minecraft.class_5712;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

public class LampFlyInABottleItem extends class_1792 {
    public static final int LIGHT_LEVEL = 12;

    public LampFlyInABottleItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1937 world = context.method_8045();
        class_2338 pos = context.method_8037().method_10093(context.method_8038());
        class_1657 player = context.method_8036();

        if (world.method_31606(pos) || !world.method_22347(pos)) {
            return class_1269.field_5814;
        }

        if (world instanceof class_3218 serverWorld) {
            LampFlyEntity lampFly = ModEntities.LAMP_FLY.method_5883(serverWorld, class_3730.field_16473);
            if (lampFly == null) {
                return class_1269.field_5814;
            }

            class_1799 stack = context.method_8041();
            class_9279 nbtComponent = stack.method_57825(class_9334.field_49610, class_9279.field_49302);
            if (!nbtComponent.method_57458()) {
                lampFly.method_35170(nbtComponent.method_57461());
            }
            var customName = stack.method_57824(class_9334.field_49631);
            if (customName != null) {
                lampFly.method_5665(customName);
            }
            lampFly.method_6454(true);
            lampFly.method_5725(pos, context.method_8044(), 0.0F);
            lampFly.method_18800(0.0, 0.0, 0.0);

            serverWorld.method_8649(lampFly);
            serverWorld.method_8396(null, pos, class_3417.field_14826, class_3419.field_15254, 1.0F, 1.0F);
            serverWorld.method_33596(player, class_5712.field_28738, pos);

            if (player != null && !player.method_56992()) {
                player.method_6122(context.method_20287(), class_5328.method_30270(stack, player, new class_1799(class_1802.field_8469), false));
            }
        }

        return class_1269.field_5812;
    }
}
