package mia.the_tower.initialisation.entity.custom;

import mia.the_tower.initialisation.entity.goal.DreamyArcFlightGoal;
import mia.the_tower.initialisation.item_init;
import mia.the_tower.initialisation.items.LampFlyInABottleItem;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1331;
import net.minecraft.class_1407;
import net.minecraft.class_1408;
import net.minecraft.class_1421;
import net.minecraft.class_1432;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3730;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_5328;
import net.minecraft.class_5425;
import net.minecraft.class_5712;
import net.minecraft.class_5761;
import net.minecraft.class_6089;
import net.minecraft.class_7094;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import net.minecraft.entity.*;

public class LampFlyEntity extends class_1421 implements class_1432, class_5761{
    private static final String FROM_BOTTLE_KEY = "FromBottle";
    public final class_7094 idleAnimationState = new class_7094();
    private int idleAnimationTimeout = 0;
    public final class_7094 flyAnimationState = new class_7094();
    private boolean fromBottle = false;
    private class_2338 lightPos = null;

    public LampFlyEntity(class_1299<? extends class_1421> entityType, class_1937 world) {
        super(entityType, world);
        this.field_6207 = new class_1331(this, 12, true);
        this.method_5875(true);
    }


    @Override
    protected class_1408 method_5965(class_1937 world) {
        class_1407 nav = new class_1407(this, world);
        nav.method_6354(false);
        nav.method_6332(false);
        return nav;
    }

    @Override
    public boolean method_5810() {
        return false;
    }

    @Override
    public boolean method_6581() {
        return !this.method_24828();
    }

    @Override
    public boolean method_5747(float fallDistance, float damageMultiplier, class_1282 source) {
        return false;
    }

    @Override
    protected class_1269 method_5992(class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        if (stack.method_31574(class_1802.field_8469) && this.method_5805()) {
            class_1799 bottleStack = this.method_6452();
            this.method_6455(bottleStack);
            player.method_6122(hand, class_5328.method_30270(stack, player, bottleStack, false));
            this.method_5783(this.method_35171(), 1.0F, 1.0F);
            this.method_37908().method_33596(player, class_5712.field_28725, this.method_24515());

            if (!this.method_37908().method_8608()) {
                this.clearBottleLight();
                this.method_31472();
            }

            return class_1269.field_5812;
        }

        return super.method_5992(player, hand);
    }

    @Override
    protected void method_5959() {
        //this.goalSelector.add(0, new PerchGoal(this, 20));
        this.field_6201.method_6277(0, new DreamyArcFlightGoal(this,
                /*baseSpeed*/ 0.65,  // movement speed passed to moveControl
                /*minRadius*/ 5.0,    // horizontal orbit radius range
                /*maxRadius*/ 10.0,
                /*vertAmp*/   1.8,    // vertical sine amplitude
                /*omega*/     0.035,  // angular speed (radians/tick) — smaller = slower arcs
                /*anchorDriftSec*/ 12 // seconds between slow anchor drifts
        ));
    }



    public static boolean canSpawn(class_1299<LampFlyEntity> type,
                                   class_5425 world,
                                   class_3730 reason,
                                   class_2338 pos,
                                   net.minecraft.class_5819 random) {
        if (!world.method_22347(pos) || !world.method_22347(pos.method_10084())) return false;
        //if (world.getLightLevel(pos) > 3) return false;
        return true;
    }

    @Override
    public boolean method_5974(double distanceSquared) {
        return !this.fromBottle; // typical ambient behavior unless released from a bottle
    }

    @Override
    public boolean method_17326() {
        return this.fromBottle || super.method_17326();
    }

    public static class_5132.class_5133 createAttributes() {
        return class_1308.method_26828()
                .method_26868(class_5134.field_23716, 1)
                .method_26868(class_5134.field_23719, 0.4)
                .method_26868(class_5134.field_23720, 0.5)
                .method_26868(class_5134.field_23717, 40)
                .method_26868(class_5134.field_52450, 30)
                ;
    }

    private void setupAnimationStates() {
        if (this.idleAnimationTimeout <= 0) {
            this.idleAnimationTimeout = 20*2;
            this.idleAnimationState.method_41322(this.field_6012);
        } else {
            --this.idleAnimationTimeout;
        }

        if (method_6581()) {
            if (!this.flyAnimationState.method_41327()) {
                this.flyAnimationState.method_41322(this.field_6012);
            }
        } else {
            this.flyAnimationState.method_41325();
        }

    }

    @Override
    public void method_5773() {
        super.method_5773();

        if (this.method_37908().method_8608()) {
            this.setupAnimationStates();
        } else {
            this.updateBottleLight();
        }
        if (!this.method_24828()) {
            var v = this.method_18798();
            this.method_18800(v.field_1352 * 0.96, v.field_1351 * 0.90, v.field_1350 * 0.96);
        }
    }

    @Override
    public void method_64615(class_5529 reason) {
        this.clearBottleLight();
        super.method_64615(reason);
    }

    @Override
    public void method_5652(class_2487 nbt) {
        super.method_5652(nbt);
        nbt.method_10556(FROM_BOTTLE_KEY, this.fromBottle);
    }

    @Override
    public void method_5749(class_2487 nbt) {
        super.method_5749(nbt);
        this.fromBottle = nbt.method_10577(FROM_BOTTLE_KEY);
    }

    @Override
    public boolean method_6453() {
        return this.fromBottle;
    }

    @Override
    public void method_6454(boolean fromBucket) {
        this.fromBottle = fromBucket;
    }

    @Override
    public void method_6455(class_1799 stack) {
        class_5761.method_35167(this, stack);
        class_9279.method_57452(class_9334.field_49610, stack, nbt -> nbt.method_10556(FROM_BOTTLE_KEY, true));
    }

    @Override
    public void method_35170(class_2487 nbt) {
        class_5761.method_35168(this, nbt);
        this.fromBottle = nbt.method_10577(FROM_BOTTLE_KEY);
    }

    @Override
    public class_1799 method_6452() {
        return new class_1799(item_init.LAMP_FLY_IN_A_BOTTLE);
    }

    @Override
    public class_3414 method_35171() {
        return class_3417.field_14779;
    }

    private void updateBottleLight() {
        if (!this.fromBottle) {
            this.clearBottleLight();
            return;
        }

        class_2338 currentPos = this.method_24515();
        if (currentPos.equals(this.lightPos)) {
            return;
        }

        this.clearBottleLight();
        if (this.method_37908().method_22347(currentPos)) {
            this.method_37908().method_8652(
                    currentPos,
                    class_2246.field_31037.method_9564().method_11657(class_6089.field_31187, LampFlyInABottleItem.LIGHT_LEVEL),
                    class_2248.field_31036
            );
            this.lightPos = currentPos.method_10062();
        }
    }

    private void clearBottleLight() {
        if (this.lightPos == null || this.method_37908().method_8608()) {
            return;
        }

        var state = this.method_37908().method_8320(this.lightPos);
        if (state.method_27852(class_2246.field_31037) && state.method_11654(class_6089.field_31187) == LampFlyInABottleItem.LIGHT_LEVEL) {
            this.method_37908().method_8650(this.lightPos, false);
        }
        this.lightPos = null;
    }

}
