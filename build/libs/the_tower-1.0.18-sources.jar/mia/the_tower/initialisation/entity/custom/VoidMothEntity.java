package mia.the_tower.initialisation.entity.custom;

import mia.the_tower.initialisation.entity.ModEntities;
import mia.the_tower.initialisation.entity.goal.PerchGoal;
import mia.the_tower.initialisation.item_init;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1331;
import net.minecraft.class_1341;
import net.minecraft.class_1361;
import net.minecraft.class_1384;
import net.minecraft.class_1391;
import net.minecraft.class_1394;
import net.minecraft.class_1395;
import net.minecraft.class_1407;
import net.minecraft.class_1408;
import net.minecraft.class_1429;
import net.minecraft.class_1432;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3730;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_7094;
import net.minecraft.entity.*;
import net.minecraft.entity.ai.goal.*;
import org.jetbrains.annotations.Nullable;

public class VoidMothEntity extends class_1429 implements class_1432 {
    private static final double PERCH_SURFACE_GAP = 0.01D;

    public final class_7094 idleAnimationState = new class_7094();
    private int idleAnimationTimeout = 0;
    public final class_7094 flyAnimationState = new class_7094();

    private static final class_2940<Boolean> PERCHED =
            class_2945.method_12791(VoidMothEntity.class, class_2943.field_13323);
    private static final class_2940<class_2350> PERCH_FACE =
            class_2945.method_12791(VoidMothEntity.class, class_2943.field_13321);

    public VoidMothEntity(class_1299<? extends class_1429> entityType, class_1937 world) {
        super(entityType, world);
        this.field_6207 = new class_1331(this, 12, true);
        this.method_5875(true);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(PERCHED, false);
        builder.method_56912(PERCH_FACE, class_2350.field_11033);
    }

    public boolean isPerched() {
        return this.field_6011.method_12789(PERCHED);
    }

    public class_2350 getPerchFace() {
        return this.field_6011.method_12789(PERCH_FACE);
    }

    public void perchAt(class_2338 anchor, class_2350 face) {
        this.field_6011.method_12778(PERCHED, true);
        this.field_6011.method_12778(PERCH_FACE, face);
        this.field_6189.method_6340();
        this.method_18799(class_243.field_1353);
        this.method_5875(true);

        class_243 perchPos = this.getPerchPosition(anchor, face);
        float yaw = this.getPerchYaw(face);
        this.method_5808(perchPos.field_1352, perchPos.field_1351, perchPos.field_1350, yaw, 0.0F);
        this.method_36456(yaw);
        this.method_5847(yaw);
        this.method_5636(yaw);
    }

    public class_243 getPerchPosition(class_2338 anchor, class_2350 face) {
        double halfWidth = this.method_17681() / 2.0D;
        double height = this.method_17682();
        double x = anchor.method_10263() + 0.5D;
        double y = anchor.method_10264() + 0.5D - height / 2.0D;
        double z = anchor.method_10260() + 0.5D;

        if (face == class_2350.field_11036) {
            y = anchor.method_10264() - height - PERCH_SURFACE_GAP;
        } else if (face == class_2350.field_11033) {
            y = anchor.method_10264() + 1.0D + PERCH_SURFACE_GAP;
        } else {
            double offset = 0.5D + halfWidth + PERCH_SURFACE_GAP;
            x -= face.method_10148() * offset;
            z -= face.method_10165() * offset;
        }

        return new class_243(x, y, z);
    }

    public class_238 getPerchBox(class_2338 anchor, class_2350 face) {
        class_243 pos = this.getPerchPosition(anchor, face);
        double halfWidth = this.method_17681() / 2.0D;
        return new class_238(
                pos.field_1352 - halfWidth,
                pos.field_1351,
                pos.field_1350 - halfWidth,
                pos.field_1352 + halfWidth,
                pos.field_1351 + this.method_17682(),
                pos.field_1350 + halfWidth
        ).method_1011(1.0E-6D);
    }

    public void unperch() {
        if (!this.isPerched()) return;
        this.field_6011.method_12778(PERCHED, false);
        this.method_5875(true);
    }

    @Override
    public boolean method_64397(class_3218 world, class_1282 source, float amount) {
        boolean res = super.method_64397(world, source, amount);
        this.unperch();
        return res;
    }

    @Override
    public void method_6087(class_1297 entity) {
        super.method_6087(entity);
        this.unperch();
    }

    @Override
    protected class_1408 method_5965(class_1937 world) {
        class_1407 nav = new class_1407(this, world);
        nav.method_6354(false);
        nav.method_6332(true);
        return nav;
    }

    @Override
    public boolean method_6581() {
        return !this.isPerched() && !this.method_24828();
    }

    @Override
    public boolean method_5747(float fallDistance, float damageMultiplier, class_1282 source) {
        return false;
    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(0, new PerchGoal(this, 20));
        this.field_6201.method_6277(1, new class_1384(this));
        this.field_6201.method_6277(1, new class_1341(this, 1.15D));
        this.field_6201.method_6277(2, new class_1391(this, 1.25D, class_1856.method_8091(item_init.SHEPHERDS_STAFF), false));
        this.field_6201.method_6277(5, new class_1395(this, 1.15D));
        this.field_6201.method_6277(6, new class_1394(this, 1.0D));
        this.field_6201.method_6277(7, new class_1361(this, class_1657.class, 4.0F));
    }

    public static class_5132.class_5133 createAttributes() {
        return class_1308.method_26828()
                .method_26868(class_5134.field_23716, 2)
                .method_26868(class_5134.field_23719, 0.7)
                .method_26868(class_5134.field_23720, 0.8)
                .method_26868(class_5134.field_23717, 40)
                .method_26868(class_5134.field_52450, 10);
    }

    @Override
    protected int method_6110(class_3218 world) {
        return 1;
    }

    private void setupAnimationStates() {
        if (this.idleAnimationTimeout <= 0) {
            this.idleAnimationTimeout = 40;
            this.idleAnimationState.method_41322(this.field_6012);
        } else {
            --this.idleAnimationTimeout;
        }

        if (method_6581()) {
            if (!this.flyAnimationState.method_41327()) {
                this.flyAnimationState.method_41322(this.field_6012);
            }
        } else {
            this.flyAnimationState.method_41325();
        }
    }

    @Override
    public void method_5773() {
        super.method_5773();

        if (this.method_37908().method_8608()) {
            this.setupAnimationStates();
        }
    }

    @Override
    public void method_6007() {
        if (this.isPerched()) {
            this.method_18799(class_243.field_1353);
            this.field_6017 = 0.0f;
            super.method_6007();
            return;
        }
        super.method_6007();
    }

    @Override
    public boolean method_6481(class_1799 stack) {
        return stack.method_31574(item_init.GLOOP);
    }

    @Nullable
    @Override
    public class_1296 method_5613(class_3218 world, class_1296 entity) {
        return ModEntities.VOID_MOTH.method_5883(world, class_3730.field_16466);
    }

    private float getPerchYaw(class_2350 face) {
        return switch (face) {
            case field_11043, field_11035, field_11034, field_11039 -> face.method_10153().method_10144();
            default -> this.method_36454();
        };
    }
}
