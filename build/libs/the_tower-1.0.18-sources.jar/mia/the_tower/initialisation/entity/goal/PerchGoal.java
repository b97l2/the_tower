package mia.the_tower.initialisation.entity.goal;

import mia.the_tower.initialisation.entity.custom.VoidMothEntity;
import net.minecraft.class_1352;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_5431;
import java.util.EnumSet;

public class PerchGoal extends class_1352 {
    private static final class_2350[] SUPPORT_SEARCH_ORDER = {
            class_2350.field_11036,
            class_2350.field_11043,
            class_2350.field_11035,
            class_2350.field_11034,
            class_2350.field_11039,
            class_2350.field_11033
    };
    private static final int MAX_APPROACH_TICKS = 100;

    private final VoidMothEntity mob;
    private final int minPerchTicks;
    private class_2338 targetPos;
    private class_2350 targetFace;
    private int approachTicks;
    private int perchTicks;

    public PerchGoal(VoidMothEntity mob, int minPerchSeconds) {
        this.mob = mob;
        this.method_6265(EnumSet.of(class_4134.field_18405, class_4134.field_18406));
        this.minPerchTicks = minPerchSeconds * 20;
    }

    @Override
    public boolean method_6264() {
        if (mob.isPerched()) return false;
        if (mob.method_59922().method_43057() > 0.02f) return false;

        class_2338 base = mob.method_24515();
        for (int tries = 0; tries < 16; tries++) {
            class_2338 pos = base.method_10069(
                    mob.method_59922().method_39332(-6, 6),
                    mob.method_59922().method_39332(-2, 4),
                    mob.method_59922().method_39332(-6, 6)
            );

            for (class_2350 supportDirection : SUPPORT_SEARCH_ORDER) {
                if (canPerchOn(pos, supportDirection)) {
                    this.targetPos = pos;
                    this.targetFace = supportDirection;
                    return true;
                }
            }
        }

        return false;
    }

    @Override
    public boolean method_6266() {
        if (mob.isPerched()) {
            if (!hasCurrentPerch()) return false;
            if (perchTicks < minPerchTicks) return true;
            if (mob.method_5968() != null) return false;
            if (mob.method_37908().method_8530()) return false;

            return mob.method_59922().method_43057() < 0.95f;
        }

        return targetPos != null
                && targetFace != null
                && approachTicks < MAX_APPROACH_TICKS
                && canPerchOn(targetPos, targetFace);
    }

    @Override
    public void method_6269() {
        approachTicks = 0;
        perchTicks = 0;

        if (targetPos != null && targetFace != null && !mob.isPerched()) {
            class_243 perchPos = mob.getPerchPosition(targetPos, targetFace);
            mob.method_5942().method_6337(perchPos.field_1352, perchPos.field_1351, perchPos.field_1350, 1.0);
        }
    }

    @Override
    public void method_6268() {
        if (!mob.isPerched()) {
            approachTicks++;
            if (targetPos == null || targetFace == null || !canPerchOn(targetPos, targetFace)) {
                approachTicks = MAX_APPROACH_TICKS;
                return;
            }

            class_243 perchPos = mob.getPerchPosition(targetPos, targetFace);
            if (mob.method_5707(perchPos) < 1.0) {
                mob.perchAt(targetPos, targetFace);
            } else if (mob.method_5942().method_6357()) {
                mob.method_5942().method_6337(perchPos.field_1352, perchPos.field_1351, perchPos.field_1350, 1.0);
            }
        } else {
            perchTicks++;
        }
    }

    @Override
    public void method_6270() {
        targetPos = null;
        targetFace = null;
        if (mob.isPerched()) {
            mob.unperch();
        }
    }

    private boolean canPerchOn(class_2338 pos, class_2350 supportDirection) {
        return isFaceSolid(pos, supportDirection.method_10153())
                && mob.method_37908().method_8587(mob, mob.getPerchBox(pos, supportDirection));
    }

    private boolean isFaceSolid(class_2338 pos, class_2350 face) {
        class_2680 state = mob.method_37908().method_8320(pos);
        return state.method_30368(mob.method_37908(), pos, face, class_5431.field_25822);
    }

    private boolean hasCurrentPerch() {
        class_2350 supportDirection = mob.getPerchFace();
        class_2338 anchor = switch (supportDirection) {
            case field_11036 -> mob.method_24515().method_10084();
            case field_11033 -> mob.method_24515().method_10074();
            default -> mob.method_24515().method_10093(supportDirection);
        };

        return canPerchOn(anchor, supportDirection);
    }
}
