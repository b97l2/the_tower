package mia.the_tower.entity.void_moth;

import mia.the_tower.initialisation.entity.custom.VoidMothEntity;
import net.minecraft.class_2350;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_927;

public class VoidMothRenderer extends class_927<VoidMothEntity, VoidMothRenderState, VoidMothModel>{
    //displays the mob
    private static final double WALL_PERCH_RENDER_INSET = 0.64D;

    //for variants
    /*
    private static final Map<VoidMothVariant, Identifier> LOCATION_BY_VARIANT =
            Util.make(Maps.newEnumMap(VoidMothVariant.class), map -> {
                map.put(VoidMothVariant.DEFAULT,
                        Identifier.of("the_tower", "textures/entity/void_moth/mantis.png"));
                map.put(VoidMothVariant.ORCHID,
                        Identifier.of("the_tower", "textures/entity/mantis/mantis_orchid.png"));
            });

     */

    public VoidMothRenderer(class_5617.class_5618 context) {
        super(context, new VoidMothModel(context.method_32167(VoidMothModel.VOID_MOTH)), 0.3f); //the last one is the shadow radius I believe
    }

    @Override
    public class_2960 getTexture(VoidMothRenderState state) {
        return class_2960.method_60655("the_tower", "textures/entity/void_moth/void_moth.png");
        //return LOCATION_BY_VARIANT.get(state.variant); //this is for variants
    }

    @Override
    public void render(VoidMothRenderState state, class_4587 matrixStack,
                       class_4597 vertexConsumerProvider, int i) {
        if (state.perched && state.perchFace.method_10166().method_10179()) {
            class_2350 face = state.perchFace;
            matrixStack.method_22904(
                    face.method_10148() * WALL_PERCH_RENDER_INSET,
                    0.0D,
                    face.method_10165() * WALL_PERCH_RENDER_INSET
            );
        }

        if(state.field_53457) {
            matrixStack.method_22905(0.3f, 0.3f, 0.3f);
        } else {
            matrixStack.method_22905(1f, 1f, 1f);
        }

        super.method_4054(state, matrixStack, vertexConsumerProvider, i);
    }

    @Override
    public VoidMothRenderState method_55269() {
        return new VoidMothRenderState();
    }

    @Override
    public void updateRenderState(VoidMothEntity livingEntity, VoidMothRenderState livingEntityRenderState, float f) {
        super.method_62355(livingEntity, livingEntityRenderState, f);
        livingEntityRenderState.idleAnimationState.method_61401(livingEntity.idleAnimationState);
        livingEntityRenderState.flyAnimationState.method_61401(livingEntity.flyAnimationState);
        livingEntityRenderState.airborne = livingEntity.method_6581();

        //livingEntityRenderState.variant = livingEntity.getVariant();

        livingEntityRenderState.perched = livingEntity.isPerched();
        livingEntityRenderState.perchFace = livingEntity.getPerchFace();
        if (livingEntityRenderState.perched && !livingEntityRenderState.idleAnimationState.method_41327()) {
            livingEntityRenderState.idleAnimationState.method_41322(livingEntity.field_6012);
        } else if (!livingEntityRenderState.perched) {
            livingEntityRenderState.idleAnimationState.method_41325();
        }
    }

}
