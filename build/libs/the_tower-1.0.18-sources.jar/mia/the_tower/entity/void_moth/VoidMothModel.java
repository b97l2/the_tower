package mia.the_tower.entity.void_moth;

import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_583;
import net.minecraft.class_630;
import net.minecraft.client.model.*;


public class VoidMothModel extends class_583<VoidMothRenderState>{
    //deals with how the mob looks like

        public static final class_5601 VOID_MOTH = new class_5601(class_2960.method_60655("the_tower", "void_moth"), "main");

        private final class_630 full_head;
        private final class_630 void_moth;

    public VoidMothModel(class_630 void_moth) {
        super(void_moth);
        this.void_moth = field_54014.method_32086("void_moth");
        this.full_head = this.void_moth.method_32086("full_head");


    }

    public static class_5607 getTexturedModelData() {
        class_5609 modelData = new class_5609();
        class_5610 modelPartData = modelData.method_32111();
        class_5610 void_moth = modelPartData.method_32117("void_moth", class_5606.method_32108(), class_5603.method_32090(0.0F, 21.0F, -5.0F));

        class_5610 right_wing = void_moth.method_32117("right_wing", class_5606.method_32108(), class_5603.method_32090(-1.0F, 1.0F, 4.0F));

        class_5610 cube_r1 = right_wing.method_32117("cube_r1", class_5606.method_32108().method_32101(0, 28).method_32098(-21.0F, 0.0F, 0.0F, 21.0F, 0.0F, 20.0F, new class_5605(0.0F)), class_5603.method_32091(-0.5F, -3.0F, -3.0F, 0.0F, -0.0873F, -0.1745F));

        class_5610 left_wing = void_moth.method_32117("left_wing", class_5606.method_32108(), class_5603.method_32090(1.0F, 1.0F, 4.0F));

        class_5610 cube_r2 = left_wing.method_32117("cube_r2", class_5606.method_32108().method_32101(0, 48).method_32098(0.0F, 0.0F, 0.0F, 21.0F, 0.0F, 20.0F, new class_5605(0.0F)), class_5603.method_32091(0.5F, -3.0F, -3.0F, 0.0F, 0.0873F, 0.1745F));

        class_5610 body = void_moth.method_32117("body", class_5606.method_32108().method_32101(0, 68).method_32098(-2.0F, -4.0F, -3.0F, 4.0F, 4.0F, 6.0F, new class_5605(0.0F))
                .method_32101(34, 68).method_32098(-1.5F, -3.5F, 2.5F, 3.0F, 3.0F, 4.0F, new class_5605(0.0F)), class_5603.method_32090(0.0F, 2.0F, 4.0F));

        class_5610 lower_wings = void_moth.method_32117("lower_wings", class_5606.method_32108().method_32101(0, 0).method_32098(-9.0F, -2.0F, -3.0F, 19.0F, 0.0F, 28.0F, new class_5605(0.0F)), class_5603.method_32090(0.0F, 2.0F, 4.0F));

        class_5610 full_head = void_moth.method_32117("full_head", class_5606.method_32108(), class_5603.method_32090(0.0F, 3.0F, 5.0F));

        class_5610 head = full_head.method_32117("head", class_5606.method_32108().method_32101(20, 68).method_32098(-1.5F, -4.0F, -6.0F, 3.0F, 3.0F, 4.0F, new class_5605(0.0F)), class_5603.method_32090(0.0F, -0.5F, 1.0F));

        class_5610 right_antena = full_head.method_32117("right_antena", class_5606.method_32108(), class_5603.method_32090(0.15F, -1.5F, -1.4F));

        class_5610 cube_r3 = right_antena.method_32117("cube_r3", class_5606.method_32108().method_32101(64, 68).method_32098(-1.0F, -6.0F, 0.0F, 2.0F, 6.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(0.6F, -2.5F, -3.5F, 0.0F, 0.0436F, 0.4363F));

        class_5610 left_antena = full_head.method_32117("left_antena", class_5606.method_32108(), class_5603.method_32090(-0.15F, -1.5F, -1.4F));

        class_5610 cube_r4 = left_antena.method_32117("cube_r4", class_5606.method_32108().method_32101(68, 68).method_32098(-1.0F, -6.0F, 0.0F, 2.0F, 6.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(-0.6F, -2.5F, -3.5F, 0.0F, -0.0436F, -0.4363F));

        class_5610 front_legs = void_moth.method_32117("front_legs", class_5606.method_32108(), class_5603.method_32090(0.0F, 3.0F, 5.0F));

        class_5610 cube_r5 = front_legs.method_32117("cube_r5", class_5606.method_32108().method_32101(56, 68).method_32098(0.0F, 0.0F, -1.0F, 1.0F, 0.0F, 3.0F, new class_5605(0.0F))
                .method_32101(48, 68).method_32098(3.0F, 0.0F, -1.0F, 1.0F, 0.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32091(-2.0F, -0.7F, -3.0F, 0.6981F, 0.0F, 0.0F));

        class_5610 back_legs = void_moth.method_32117("back_legs", class_5606.method_32108(), class_5603.method_32090(0.0F, 3.0F, 5.0F));

        class_5610 cube_r6 = back_legs.method_32117("cube_r6", class_5606.method_32108().method_32101(72, 70).method_32098(0.0F, 0.0F, -1.0F, 1.0F, 0.0F, 2.0F, new class_5605(0.0F))
                .method_32101(48, 71).method_32098(-3.0F, 0.0F, -1.0F, 1.0F, 0.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32091(1.0F, -0.7F, -1.0F, -0.6981F, 0.0F, 0.0F));

        class_5610 cube_r7 = back_legs.method_32117("cube_r7", class_5606.method_32108().method_32101(72, 68).method_32098(0.0F, 0.0F, -1.0F, 1.0F, 0.0F, 2.0F, new class_5605(0.0F))
                .method_32101(54, 71).method_32098(-3.0F, 0.0F, -1.0F, 1.0F, 0.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32091(1.0F, -0.7F, 1.0F, -0.6981F, 0.0F, 0.0F));
        return class_5607.method_32110(modelData, 128, 128);
    }


    @Override
    public void setAngles(VoidMothRenderState state) {
        super.method_2819(state);
        this.method_63514();
        this.setHeadAngles(state.field_53447, state.field_53448);

        if (state.perched) {
            this.setPerchRotation(state.perchFace);
            this.method_62099(state.idleAnimationState, VoidMothAnimations.IDLE, state.field_53328, 1.0f);
            return;
        }

        if (state.airborne) {
            // Airborne: flap
            this.method_62099(state.flyAnimationState, VoidMothAnimations.FLY, state.field_53328, 1.0f);
        } else {
            // On ground: walk cycle driven by limb fields (1.21.4 names)
            this.method_62102(
                    VoidMothAnimations.WALK,
                    state.field_53450,
                    state.field_53451,
                    2.0f,  // speed multiplier – increase if you want faster flaps while “walking”
                    1.0f   // degree – how strong the motion is
            );
        }
        this.method_62099(state.idleAnimationState, VoidMothAnimations.IDLE, state.field_53328, 1f);
    }

    private void setPerchRotation(net.minecraft.class_2350 perchFace) {
        switch (perchFace) {
            case field_11036 -> this.void_moth.field_3654 = (float)Math.PI;
            case field_11043, field_11035, field_11034, field_11039 -> {
                this.void_moth.field_3654 = -(float)Math.PI / 2.0F;
                this.void_moth.field_3675 = (float)Math.PI;
            }
            default -> {}
        }
    }

    private void setHeadAngles(float headYaw, float headPitch) {
        headYaw = class_3532.method_15363(headYaw, -7.0F, 7.0F);
        headPitch = class_3532.method_15363(headPitch, -7.0F, 7.0F);

        this.full_head.field_3675 = headYaw * 0.017453292F;
        this.full_head.field_3654 = headPitch * 0.017453292F;
    }


}


