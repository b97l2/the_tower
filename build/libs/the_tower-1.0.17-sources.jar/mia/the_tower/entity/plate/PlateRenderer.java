package mia.the_tower.entity.plate;

import mia.the_tower.initialisation.entity.custom.PlateEntity;
import net.fabricmc.fabric.api.client.model.loading.v1.FabricBakedModelManager;
import net.minecraft.class_10442;
import net.minecraft.class_1059;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_22;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_330;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5617;
import net.minecraft.class_776;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_897;
import net.minecraft.class_9209;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public class PlateRenderer<T extends PlateEntity> extends class_897<T, PlateRenderState> {
    public static final int field_32933 = 30;
    private final class_10442 itemModelManager;
    private final class_330 mapRenderer;
    private final class_776 blockRenderManager;

    private static final class_2960 PLATE_MODEL = class_2960.method_60655("the_tower", "block/plate");

    public PlateRenderer(class_5617.class_5618 context) {
        super(context);
        this.itemModelManager = context.method_65566();
        this.mapRenderer = context.method_62427();
        this.blockRenderManager = context.method_43337();
    }



    public void render(PlateRenderState plateRenderState, class_4587 matrixStack, class_4597 vertexConsumerProvider, int i) {
        super.method_3936(plateRenderState, matrixStack, vertexConsumerProvider, i);
        matrixStack.method_22903();
        if (!plateRenderState.field_53333) {
            matrixStack.method_22903();
            matrixStack.method_46416(-0.5F, -0.03125F, -0.5F);
            var baked = ((FabricBakedModelManager)blockRenderManager.method_3351().method_3333()).getModel(PLATE_MODEL);
            this.blockRenderManager.method_3350().method_3367(matrixStack.method_23760(), vertexConsumerProvider.getBuffer(class_1921.method_23576(class_1059.field_5275)), (class_2680)null, baked, 1.0F, 1.0F, 1.0F, i, class_4608.field_21444);
            matrixStack.method_22909();
        }

        matrixStack.method_46416(0.0F, 0.0F, 0.0F);
        matrixStack.method_22907(class_7833.field_40714.rotationDegrees(90.0F));

        if (plateRenderState.mapId != null) {
            int j = plateRenderState.rotation % 4 * 2;
            matrixStack.method_22907(class_7833.field_40718.rotationDegrees((float)j * 360.0F / 8.0F));
            matrixStack.method_22905(0.0078125F, 0.0078125F, 0.0078125F);
            matrixStack.method_46416(-64.0F, -64.0F, 0.0F);
            int k = this.getLight(plateRenderState.glow, 15728850, i);
            this.mapRenderer.method_1773(plateRenderState.mapRenderState, matrixStack, vertexConsumerProvider, true, k);
        } else if (!plateRenderState.itemRenderState.method_65606()) {
            matrixStack.method_22907(class_7833.field_40718.rotationDegrees((float)plateRenderState.rotation * 360.0F / 8.0F));
            int j = this.getLight(plateRenderState.glow, 15728880, i);
            matrixStack.method_22905(0.5F, 0.5F, 0.5F);
            plateRenderState.itemRenderState.method_65604(matrixStack, vertexConsumerProvider, j, class_4608.field_21444);
        }

        matrixStack.method_22909();
    }

    private int getLight(boolean glow, int glowLight, int regularLight) {
        return glow ? glowLight : regularLight;
    }

    public class_243 getPositionOffset(PlateRenderState plateRenderState) {
        return class_243.field_1353;
    }

    protected boolean hasLabel(T itemFrameEntity, double d) {
        return class_310.method_1498() && this.field_4676.field_4678 == itemFrameEntity && itemFrameEntity.method_6940().method_65130() != null;
    }

    protected class_2561 getDisplayName(T itemFrameEntity) {
        return itemFrameEntity.method_6940().method_7964();
    }

    public PlateRenderState method_55269() {
        return new PlateRenderState();
    }

    public void updateRenderState(T itemFrameEntity, PlateRenderState plateRenderState, float f) {
        super.method_62354(itemFrameEntity, plateRenderState, f);
        plateRenderState.facing = itemFrameEntity.method_5735();
        class_1799 itemStack = itemFrameEntity.method_6940();
        this.itemModelManager.method_65595(plateRenderState.itemRenderState, itemStack, class_811.field_4319, itemFrameEntity);
        plateRenderState.rotation = itemFrameEntity.method_6934();
        plateRenderState.glow = false;
        plateRenderState.mapId = null;
        if (!itemStack.method_7960()) {
            class_9209 mapIdComponent = itemFrameEntity.method_43272(itemStack);
            if (mapIdComponent != null) {
                class_22 mapState = itemFrameEntity.method_37908().method_17891(mapIdComponent);
                if (mapState != null) {
                    this.mapRenderer.method_62230(mapIdComponent, mapState, plateRenderState.mapRenderState);
                    plateRenderState.mapId = mapIdComponent;
                }
            }
        }

    }
}
