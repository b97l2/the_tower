package mia.the_tower;

import mia.the_tower.initialisation.*;
import mia.the_tower.initialisation.biomes.CeruleanCoast;
import mia.the_tower.initialisation.biomes.GoldenWeald;
import mia.the_tower.initialisation.biomes.Shadowlands;
import mia.the_tower.initialisation.biomes.ThePit;
import mia.the_tower.initialisation.block.column_init;
import mia.the_tower.initialisation.block.stake_init;
import mia.the_tower.initialisation.blockentity.blockentity_init;
import mia.the_tower.initialisation.carver.ModCarvers;
import mia.the_tower.initialisation.dimentions.TheFrage;
import mia.the_tower.initialisation.entity.LampFlySpawner;
import mia.the_tower.initialisation.entity.ModEntities;
import mia.the_tower.initialisation.entity.custom.LampFlyEntity;
import mia.the_tower.initialisation.entity.custom.VoidMothEntity;
import mia.the_tower.initialisation.fluid.GunkFluidBlock;
import mia.the_tower.initialisation.fluid.fluid_init;
import mia.the_tower.initialisation.items.util.CofferToKey;
import mia.the_tower.initialisation.misc.ModDeaths;
import mia.the_tower.initialisation.particle.CustomParticles;
import mia.the_tower.initialisation.screen.screen_init;
import mia.the_tower.initialisation.sounds.CustomSounds;
import mia.the_tower.initialisation.status_effects.*;
import mia.the_tower.initialisation.util.CustomTags;
import mia.the_tower.initialisation.world.features_init;
import mia.the_tower.initialisation.world.gen.ModWorldGeneration;

import mia.the_tower.initialisation.world.misc.DecoratedPitPlacer;
import mia.the_tower.initialisation.world.ore.SheetOreFeature;
import mia.the_tower.initialisation.world.tree.GiantFoliagePlacer;
import mia.the_tower.initialisation.world.tree.GiantTrunkPlacer;
import mia.the_tower.initialisation.world.tree.MediumTrunkPlacer;
import mia.the_tower.initialisation.world.vegetation.TripleAwareSimpleBlockFeature;
import net.fabricmc.api.ModInitializer;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.registry.FlammableBlockRegistry;
import net.fabricmc.fabric.api.registry.StrippableBlockRegistry;
import net.minecraft.class_1657;
import net.minecraft.class_1934;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Iterator;
import java.util.Map;
import java.util.WeakHashMap;

import static mia.the_tower.initialisation.status_effects.pale_death_init.PALE_DEATH;

public class The_Tower implements ModInitializer {
	public static final String MOD_ID = "the_tower"; //this is to make calling the name easier i think?

	// This logger is used to write text to the console and the log file.
	// It is considered best practice to use your mod id as the logger's name.
	// That way, it's clear which mod wrote info, warnings, and errors.
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	private static final WeakHashMap<class_3222, class_1934> spectatingPlayers = new WeakHashMap<>();

	@Override
	public void onInitialize() {
		// This code runs as soon as Minecraft is in a mod-load-ready state.
		// However, some things (like resources) may still be uninitialized.
		// Proceed with mild caution.

	 //this loads all items inside the file item_init into minecraft
		fluid_init.load();
		item_init.load();
		block_init.load();
		blockentity_init.load();
		crop_init.load();
		ModCarvers.load();
		column_init.load();
		levitate_init.load();
		pale_death_init.load();
		stake_init.load();
		InstantMineEffect.load();
		DecayStatusEffect.load();
		ThePit.load();
		Shadowlands.load();
		CeruleanCoast.load();
		TheFrage.load();
		CustomItemGroups.load();
		SanguineStatusEffect.load();
		CustomSounds.load();
		CustomParticles.load();
		ModWorldGeneration.generateModWorldGen();
		CustomTags.load();
		ModEntities.load();
		LampFlySpawner.init();
		screen_init.load();
		CofferToKey.load();
		ModDeaths.init();
		GiantTrunkPlacer.init();
		MediumTrunkPlacer.init();
		GiantFoliagePlacer.init();
		GoldenWeald.load();
		TripleAwareSimpleBlockFeature.init();
		features_init.load();
		DecoratedPitPlacer.init();
		SheetOreFeature.init();

		//for flammable blocks
		FlammableBlockRegistry.getDefaultInstance().add(block_init.GINKGO_LOG, 5, 5);
		FlammableBlockRegistry.getDefaultInstance().add(block_init.STRIPPED_GINKGO_LOG, 5, 5);
		FlammableBlockRegistry.getDefaultInstance().add(block_init.GINKGO_LEAVES, 40, 60);

		//for strippable blocks
		StrippableBlockRegistry.register(block_init.GINKGO_LOG, block_init.STRIPPED_GINKGO_LOG);

		//for entities
		FabricDefaultAttributeRegistry.register(ModEntities.VOID_MOTH, VoidMothEntity.createAttributes());

		FabricDefaultAttributeRegistry.register(ModEntities.LAMP_FLY, LampFlyEntity.createAttributes());

		ServerTickEvents.END_WORLD_TICK.register(world -> {
			Iterator<Map.Entry<class_3222, class_1934>> iterator = spectatingPlayers.entrySet().iterator();

			while (iterator.hasNext()) {
				Map.Entry<class_3222, class_1934> entry = iterator.next();
				class_3222 player = entry.getKey();

				if (!player.method_6059(PALE_DEATH)) {
					class_1934 original = entry.getValue();
					player.method_7336(original);
					iterator.remove();
				}
			}
		});

		ServerTickEvents.END_WORLD_TICK.register(world -> {
			if (world.method_8608()) return;

			for (class_1657 player : world.method_18456()) {
				if (!GunkFluidBlock.playerTimeInside.containsKey(player)) continue;

				// Increase outside timer
				int outsideTime = GunkFluidBlock.playerTimeOutside.getOrDefault(player, 0) + 1;
				GunkFluidBlock.playerTimeOutside.put(player, outsideTime);

				// If outside for 10 seconds (200 ticks), reset
				if (outsideTime >= 200) {
					GunkFluidBlock.playerTimeInside.remove(player);
					GunkFluidBlock.playerTimeOutside.remove(player);
				}
			}
		});

		LOGGER.info("Hello Fabric world!");
	}

	public static class_2960 id(String path) { //this is to name things easily i think
		return class_2960.method_60655(MOD_ID, path);
	}

	public static void setSpectator(class_3222 player, class_1934 originalMode) {
		if (!spectatingPlayers.containsKey(player)) {
			spectatingPlayers.put(player, originalMode);
		}
	}

	public static boolean isSpectating(class_3222 player) {
		return spectatingPlayers.containsKey(player);
	}

}
