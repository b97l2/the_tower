package mia.the_tower;

import mia.the_tower.entity.lamp_fly.LampFlyModel;
import mia.the_tower.entity.lamp_fly.LampFlyRenderer;
import mia.the_tower.entity.plate.PlateRenderer;
import mia.the_tower.entity.void_moth.VoidMothModel;
import mia.the_tower.entity.void_moth.VoidMothRenderer;
import mia.the_tower.initialisation.*;
import mia.the_tower.initialisation.block.stake_init;
import mia.the_tower.initialisation.entity.ModEntities;
import mia.the_tower.initialisation.particle.CustomParticles;
import mia.the_tower.initialisation.screen.screen_init;
import mia.the_tower.initialisation.weather.FrageWeatherClient;
import mia.the_tower.particle.*;
import mia.the_tower.screen.ColouredCofferScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.fabricmc.fabric.api.client.render.fluid.v1.SimpleFluidRenderHandler;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3929;


public class The_TowerClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// This entrypoint is suitable for setting up client-specific logic, such as rendering.

		// this is for transparent or translucent blocks
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.HEAVENS_LIGHT, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.POTENT_HEAVENS_LIGHT, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.HEAVENS_EARTH, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlocks(class_1921.method_23581(), crop_init.GLUH_VINE);
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.GLUH_VINE_STAGE0, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.GLUH_VINE_STAGE1, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.GLUH_VINE_STAGE2, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.GLUH_VINE_STAGE3, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.GLUH_VINE_STAGE4, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.GLUH_VINE_STAGE5, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.GLUH_VINE_STAGE6, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.GLUH_VINE_STAGE7, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.BARRIER, class_1921.method_23583());
		BlockRenderLayerMap.INSTANCE.putBlock(stake_init.STAKE_BUD, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(stake_init.STAKE, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.CERULEAN_PETALS, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.SAPPHIRE_ROSE, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.DRAGONS_LEAP, class_1921.method_23583());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.JESTERS_HAT, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.BLUE_FOXGLOVE, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.CERULEAN_SHORTGRASS, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.CERULEAN_WILDGRASS, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.BLUE_BELL, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.ROD_OF_LUMINESCENCE, class_1921.method_23583());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.BLOOD, class_1921.method_23583());
		BlockRenderLayerMap.INSTANCE.putFluids(
				class_1921.method_23583(),
				block_init.STILL_BLOOD,
				block_init.FLOWING_BLOOD
		);
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.GUNK, class_1921.method_23583());
		BlockRenderLayerMap.INSTANCE.putFluids(
				class_1921.method_23583(),
				block_init.STILL_GUNK,
				block_init.FLOWING_GUNK
		);
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.GABRIELS_TRUMPETS_BUSH, class_1921.method_23583());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.SHADOW, class_1921.method_23583());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.FRAGE_MARKER, class_1921.method_23583());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.BLUE_HOSTAS, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.GOLDEN_THURIBLE, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.SPIRITS, class_1921.method_23583());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.SAUERKRAUT, class_1921.method_23583());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.GINKGO_LEAVES, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.GRAVESTONE, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.GROTESQUE, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.STARLIGHT_LICHEN, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.GINKGO_SAPLING, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.GOLD_LADDER, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.GOLD_BARS, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.SIMPLE_COFFER, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.WHITE_COFFER, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.ORANGE_COFFER, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.MAGENTA_COFFER, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.LIGHT_BLUE_COFFER, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.YELLOW_COFFER, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.LIME_COFFER, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.BLUE_BELL, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.PINK_COFFER, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.GREY_COFFER, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.LIGHT_GREY_COFFER, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.CYAN_COFFER, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.PURPLE_COFFER, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.BLUE_COFFER, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.BROWN_COFFER, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.GREEN_COFFER, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.RED_COFFER, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.BLACK_COFFER, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.VEINS, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.REDSTONE_CHAIN, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.REDSTONE_LANTERN, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.IMPERIAL_JADE_LANTERN, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.SILVER_LANTERN, class_1921.method_23581());
		BlockRenderLayerMap.INSTANCE.putBlock(block_init.PILE_OF_MEAT, class_1921.method_23581());

		//this is for rendering fluids
		FluidRenderHandlerRegistry.INSTANCE.register(
				block_init.STILL_BLOOD,
				block_init.FLOWING_BLOOD,
				new SimpleFluidRenderHandler(
						The_Tower.id("block/blood"),
						The_Tower.id("block/blood"),
						0xFFFFFF
				)
		);

		FluidRenderHandlerRegistry.INSTANCE.register(
				block_init.STILL_GUNK,
				block_init.FLOWING_GUNK,
				new SimpleFluidRenderHandler(
						The_Tower.id("block/gunk_still"),
						The_Tower.id("block/gunk_still"),
						0xFFFFFF
				)
		);


		//this is for rendering particles
		ParticleFactoryRegistry.getInstance().register(CustomParticles.EMBERS_OF_THE_FRAGE, EmbersOfTheFrage.Factory::new);
		ParticleFactoryRegistry.getInstance().register(CustomParticles.UNDERBLOOD, Underblood.Factory::new);
		ParticleFactoryRegistry.getInstance().register(CustomParticles.GOLD_INCENSE, GoldIncense.Factory::new);
		ParticleFactoryRegistry.getInstance().register(CustomParticles.GLUH_PARTICLE, GluhParticle.Factory::new);
		ParticleFactoryRegistry.getInstance().register(CustomParticles.STAVE_PARTICLE, StaveParticle.Factory::new);
		ParticleFactoryRegistry.getInstance().register(CustomParticles.WHITE_INCENSE, WhiteIncense.Factory::new);
		ParticleFactoryRegistry.getInstance().register(CustomParticles.GOLD_ORB, GoldOrbParticle.Factory::new);


		//this is for entities
		EntityModelLayerRegistry.registerModelLayer(VoidMothModel.VOID_MOTH, VoidMothModel::getTexturedModelData);
		EntityRendererRegistry.register(ModEntities.VOID_MOTH, VoidMothRenderer::new);

		EntityModelLayerRegistry.registerModelLayer(LampFlyModel.LAMP_FLY, LampFlyModel::getTexturedModelData);
		EntityRendererRegistry.register(ModEntities.LAMP_FLY, LampFlyRenderer::new);

		EntityRendererRegistry.register(ModEntities.PLATE, PlateRenderer::new);
		ModelLoadingPlugin.register(ctx -> {
			ctx.addModels(class_2960.method_60655("the_tower", "block/plate"));
			// add more if needed:
			// ctx.addModels(Identifier.of("the_tower", "block/plate_map"));
		});

		//this is for screens
		class_3929.method_17542(screen_init.COFFER, ColouredCofferScreen::new);
		FrageWeatherClient.init();


	}
}
