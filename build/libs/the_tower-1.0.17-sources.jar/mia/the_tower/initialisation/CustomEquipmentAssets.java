package mia.the_tower.initialisation;

import net.minecraft.class_10191;
import net.minecraft.class_10394;
import net.minecraft.class_2960;
import net.minecraft.class_5321;

public class CustomEquipmentAssets {
        //this is for the custom armour/wearable equipment model
        //to make a custom piece of armour/equipment, you need a properly registered item in item_init
        //for some effects you need a custom item class
        //you need a line here
        //you need a json in equipment directory (next to blockstates)
        //lastly you need the texture in the correct entity texture directory

        public static final class_5321<class_10394> CIRCLET_OF_GLUT =
                class_5321.method_29179(class_10191.field_55214, class_2960.method_60655("the_tower", "circlet_of_glut"));

    public static final class_5321<class_10394> LAVALIERE_OF_THE_GOLDEN_SUN =
            class_5321.method_29179(class_10191.field_55214, class_2960.method_60655("the_tower", "lavaliere_of_the_golden_sun"));


}
