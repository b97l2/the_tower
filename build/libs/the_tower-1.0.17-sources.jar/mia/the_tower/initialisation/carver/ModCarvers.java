package mia.the_tower.initialisation.carver;

import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2922;
import net.minecraft.class_2939;
import net.minecraft.class_2960;
import net.minecraft.class_3481;
import net.minecraft.class_5321;
import net.minecraft.class_5843;
import net.minecraft.class_5862;
import net.minecraft.class_5866;
import net.minecraft.class_5872;
import net.minecraft.class_6016;
import net.minecraft.class_6019;
import net.minecraft.class_6124;
import net.minecraft.class_7871;
import net.minecraft.class_7891;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.registry.*;

public final class ModCarvers {

    // Single source of truth for the id
    public static final class_2960 PIT_ID = class_2960.method_60655("the_tower", "pit_carver");

    // Register the CARVER TYPE with its CODEC
    public static final class_2939<PitCarverConfig> PIT_CARVER =
            class_2378.method_10230(class_7923.field_41143, PIT_ID, new PitCarver());

    // Key that points to the JSON-configured carver.
    public static final class_5321<class_2922<?>> PIT_CARVER_KEY =
            class_5321.method_29179(class_7924.field_41238, class_2960.method_60655("the_tower", "pit"));

    public static void bootstrap(class_7891<class_2922<?>> context) {
        class_7871<class_2248> blockLookup = context.method_46799(class_7924.field_41254);

        context.method_46838(PIT_CARVER_KEY, PIT_CARVER.method_28614(new PitCarverConfig(
                0.035f,
                class_6124.method_35396(class_5843.method_33849(0), class_5843.method_33849(0)),
                class_5862.method_33908(1.0f),
                class_5843.method_33841(-56),
                class_5872.method_33972(false, class_2246.field_22100.method_9564()),
                blockLookup.method_46735(class_3481.field_38832),
                class_6019.method_35017(20, 40),
                class_6019.method_35017(300, 500),
                class_6019.method_35017(12, 28),
                class_6016.method_34998(0),
                class_5866.method_33934(0.0f, 0.25f)
        )));
    }

    public static void load(){}
}
