package mia.the_tower.initialisation.carver;

import java.util.function.Function;
import net.minecraft.class_1923;
import net.minecraft.class_1959;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2404;
import net.minecraft.class_2680;
import net.minecraft.class_2791;
import net.minecraft.class_2902;
import net.minecraft.class_2939;
import net.minecraft.class_3532;
import net.minecraft.class_5819;
import net.minecraft.class_5873;
import net.minecraft.class_6350;
import net.minecraft.class_6643;
import net.minecraft.class_6880;

public class PitCarver extends class_2939<PitCarverConfig> {

    public PitCarver() {
        super(PitCarverConfig.DIRECT_CODEC); // Carver wants a Codec<C>
    }

    @Override
    public boolean shouldCarve(PitCarverConfig cfg, class_5819 random) {
        return random.method_43057() < cfg.field_13738; // from ProbabilityConfig
    }

    @Override
    public boolean carve(
            class_5873 context,
            PitCarverConfig cfg,
            class_2791 chunk,
            Function<class_2338, class_6880<class_1959>> posToBiome,
            class_5819 random,
            class_6350 aquiferSampler,
            class_1923 chunkPos,
            class_6643 mask
    ) {
        // Choose a center somewhere inside the source chunk.
        int xCenter = chunkPos.method_8326() + random.method_43048(16);
        int zCenter = chunkPos.method_8328() + random.method_43048(16);
        class_1923 carvingChunkPos = chunk.method_12004();

        int requestedDepth = Math.max(1, cfg.depth.method_35008(random));
        int pitRadius = Math.max(1, cfg.radius.method_35008(random));
        int minimumBottomY = context.method_30462() + 5;
        int depth = Math.max(20, requestedDepth);
        int flareHeight = class_3532.method_15340(cfg.taperHeight.method_35008(random), 1, Math.max(1, depth - 1));
        float flareRadius = pitRadius * 2.5f;
        float bottomRadius = Math.max(2.0f, pitRadius * 0.12f);

        boolean carvedAny = false;

        class_2338.class_2339 pos = new class_2338.class_2339();

        int rInt = class_3532.method_15386(flareRadius);
        float flareRadiusSquared = flareRadius * flareRadius;

        int minX = Math.max(xCenter - rInt, carvingChunkPos.method_8326());
        int maxX = Math.min(xCenter + rInt, carvingChunkPos.method_8327());
        int minZ = Math.max(zCenter - rInt, carvingChunkPos.method_8328());
        int maxZ = Math.min(zCenter + rInt, carvingChunkPos.method_8329());

        for (int xx = minX; xx <= maxX; xx++) {
            int dx = xx - xCenter;
            int localX = xx - carvingChunkPos.method_8326();

            for (int zz = minZ; zz <= maxZ; zz++) {
                int dz = zz - zCenter;
                float distanceSquared = dx * dx + dz * dz;
                if (distanceSquared > flareRadiusSquared) continue;

                int localZ = zz - carvingChunkPos.method_8328();
                int surfaceY = chunk.method_12032(class_2902.class_2903.field_13194).method_12603(localX, localZ);
                int availableDepth = surfaceY - minimumBottomY;
                if (availableDepth < 1) continue;

                float distance = class_3532.method_15355(distanceSquared);
                int columnDepth = Math.min(getColumnDepth(distance, pitRadius, flareRadius, bottomRadius, flareHeight, depth), availableDepth);
                if (columnDepth <= 0) continue;

                int bottomY = surfaceY - columnDepth;
                for (int y = surfaceY; y >= bottomY; y--) {
                    carvedAny |= carveGroundBlock(cfg, chunk, mask, pos, xx, y, zz, localX, localZ);
                }
            }
        }

        return carvedAny;
    }

    private boolean carveGroundBlock(
            PitCarverConfig cfg,
            class_2791 chunk,
            class_6643 mask,
            class_2338.class_2339 pos,
            int x,
            int y,
            int z,
            int localX,
            int localZ
    ) {
        pos.method_10103(x, y, z);
        class_2680 state = chunk.method_8320(pos);
        if (state.method_26215() || !this.method_12709(cfg, state) && !(state.method_26204() instanceof class_2404)) return false;

        mask.method_38865(localX, y, localZ);
        chunk.method_12010(pos, class_2246.field_10543.method_9564(), false);
        return true;
    }

    private static int getColumnDepth(float distance, int pitRadius, float flareRadius, float bottomRadius, int flareHeight, int depth) {
        if (distance <= bottomRadius) {
            return depth;
        }

        if (distance <= pitRadius) {
            float progress = (pitRadius - distance) / Math.max(1.0f, pitRadius - bottomRadius);
            return flareHeight + class_3532.method_15375(smoothStep(progress) * (depth - flareHeight));
        }

        float progress = (flareRadius - distance) / Math.max(1.0f, flareRadius - pitRadius);
        return 1 + class_3532.method_15375(smoothStep(progress) * (flareHeight - 1));
    }

    private static float smoothStep(float value) {
        float clamped = class_3532.method_15363(value, 0.0f, 1.0f);
        return clamped * clamped * (3f - 2f * clamped);
    }

}
