package mia.the_tower.initialisation.entity.custom;

import mia.the_tower.initialisation.item_init;
import net.minecraft.class_1299;
import net.minecraft.class_1533;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import mia.the_tower.initialisation.entity.ModEntities;

public class PlateEntity extends class_1533 {
    public PlateEntity(class_1299<? extends class_1533> type, class_1937 world) {
        super(type, world);
    }
    public PlateEntity(class_1937 world, class_2338 pos, class_2350 side) {
        super(ModEntities.PLATE, world, pos, side); // your registry constant
    }

    @Override
    protected void method_6892(class_2350 facing) {
        super.method_6892(class_2350.field_11036);
    }

    @Override
    public boolean method_6888() {
        return this.method_5735() == class_2350.field_11036 && super.method_6888();
    }

    @Override
    protected class_1799 method_33340() {
        return new class_1799(item_init.PLATE);
    }
}
