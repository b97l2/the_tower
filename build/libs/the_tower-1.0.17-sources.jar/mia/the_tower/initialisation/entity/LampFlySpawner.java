package mia.the_tower.initialisation.entity;

import mia.the_tower.initialisation.biomes.CeruleanCoast;
import mia.the_tower.initialisation.dimentions.TheFrage;
import mia.the_tower.initialisation.entity.custom.LampFlyEntity;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3730;
import net.minecraft.class_5819;

public class LampFlySpawner {
    private static final int CHECK_INTERVAL_TICKS = 20;
    private static final int TARGET_NEAR_PLAYER = 32;
    private static final int MAX_SPAWNS_PER_CHECK = 5;
    private static final double COUNT_RADIUS = 48.0;
    private static final int MIN_SPAWN_RADIUS = 8;
    private static final int MAX_SPAWN_RADIUS = 34;
    private static final int SPAWN_ATTEMPTS_PER_FLY = 24;

    public static void init() {
        ServerTickEvents.END_WORLD_TICK.register(LampFlySpawner::tickWorld);
    }

    private static void tickWorld(class_3218 world) {
        if (!world.method_27983().equals(TheFrage.THE_FRAGE_LEVEL_KEY)) return;
        if (world.method_8510() % CHECK_INTERVAL_TICKS != 0L) return;

        for (class_3222 player : world.method_18456()) {
            if (player.method_7325() || !isCeruleanCoast(world, player.method_24515())) continue;

            class_238 localArea = new class_238(player.method_24515()).method_1014(COUNT_RADIUS);
            int nearby = world.method_18023(ModEntities.LAMP_FLY, localArea, LampFlyEntity::method_5805).size();
            int toSpawn = Math.min(MAX_SPAWNS_PER_CHECK, TARGET_NEAR_PLAYER - nearby);

            for (int i = 0; i < toSpawn; i++) {
                trySpawnNearPlayer(world, player);
            }
        }
    }

    private static boolean trySpawnNearPlayer(class_3218 world, class_3222 player) {
        class_5819 random = world.method_8409();
        class_2338 playerPos = player.method_24515();

        for (int attempt = 0; attempt < SPAWN_ATTEMPTS_PER_FLY; attempt++) {
            class_2338 pos = pickCandidatePos(world, playerPos, random);
            if (!canPlaceLampFly(world, pos)) continue;

            LampFlyEntity fly = ModEntities.LAMP_FLY.method_5883(world, class_3730.field_16459);
            if (fly == null) return false;

            fly.method_5808(
                    pos.method_10263() + 0.5,
                    pos.method_10264() + 0.5,
                    pos.method_10260() + 0.5,
                    random.method_43057() * 360.0f,
                    0.0f
            );
            fly.method_18800(0.0, 0.08, 0.0);

            if (!world.method_17892(fly)) continue;

            world.method_8649(fly);
            return true;
        }

        return false;
    }

    private static class_2338 pickCandidatePos(class_3218 world, class_2338 playerPos, class_5819 random) {
        int radius = random.method_39332(MIN_SPAWN_RADIUS, MAX_SPAWN_RADIUS);
        double angle = random.method_43058() * Math.PI * 2.0;
        int dx = Math.round((float) (Math.cos(angle) * radius));
        int dz = Math.round((float) (Math.sin(angle) * radius));
        int x = playerPos.method_10263() + dx;
        int z = playerPos.method_10260() + dz;
        int y = playerPos.method_10264() + random.method_39332(-3, 9);

        class_2338 nearPlayer = new class_2338(x, y, z);
        if (canPlaceLampFly(world, nearPlayer)) return nearPlayer;

        int surfaceY = world.method_8624(class_2902.class_2903.field_13203, x, z);
        return new class_2338(x, surfaceY + 2 + random.method_43048(6), z);
    }

    private static boolean canPlaceLampFly(class_3218 world, class_2338 pos) {
        return pos.method_10264() > world.method_31607()
                && pos.method_10264() < world.method_31600()
                && isCeruleanCoast(world, pos)
                && LampFlyEntity.canSpawn(ModEntities.LAMP_FLY, world, class_3730.field_16459, pos, world.method_8409());
    }

    private static boolean isCeruleanCoast(class_3218 world, class_2338 pos) {
        return world.method_23753(pos).method_40225(CeruleanCoast.CERULEAN_COAST);
    }

    public static void load() {}
}
