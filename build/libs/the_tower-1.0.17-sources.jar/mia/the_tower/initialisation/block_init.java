package mia.the_tower.initialisation;

import mia.the_tower.The_Tower;
import mia.the_tower.initialisation.block.*;
import mia.the_tower.initialisation.blockentity.ColouredCofferBlock;
import mia.the_tower.initialisation.blockentity.StorageTemplateBlock;
import mia.the_tower.initialisation.fluid.BloodFluid;
import mia.the_tower.initialisation.fluid.BloodFluidBlock;
import mia.the_tower.initialisation.fluid.GunkFluid;
import mia.the_tower.initialisation.fluid.GunkFluidBlock;
import mia.the_tower.initialisation.fluid.fluid_init;
import mia.the_tower.initialisation.particle.CustomParticles;
import mia.the_tower.initialisation.sounds.CustomSounds;
import mia.the_tower.initialisation.world.ModConfiguredFeatures;
import mia.the_tower.initialisation.world.tree.ModSaplingGenerators;
import net.minecraft.block.*;
import net.minecraft.class_1294;
import net.minecraft.class_1747;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2269;
import net.minecraft.class_2320;
import net.minecraft.class_2356;
import net.minecraft.class_2378;
import net.minecraft.class_2389;
import net.minecraft.class_2420;
import net.minecraft.class_2465;
import net.minecraft.class_2473;
import net.minecraft.class_2498;
import net.minecraft.class_2526;
import net.minecraft.class_2960;
import net.minecraft.class_3609;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_5172;
import net.minecraft.class_5321;
import net.minecraft.class_5689;
import net.minecraft.class_5777;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8169;
import net.minecraft.class_8177;

public class block_init {


    public static final class_2248 DARKNESS = registerBlock("darkness", //this creates a block of specified name
            new class_2248(class_4970.class_2251.method_9637() //this begins the part where we put the block settings
                    //here you list the settings of the block.
                    //you can also copy the settings of a vanilla block
                    .method_9629(1.0F, 1000.0F)
                    .method_29292()
                    .method_9628(0.99999F)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "darkness")))));

    public static final class_2248 BLAJ_ORE = registerBlock("blaj_ore",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_9629(2.0F, 1000.0F)
                    .method_29292()
                    .method_26249(class_2246::method_26113)
                    .method_9626(CustomSounds.BLAJ_BLOCK)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "blaj_ore")))));

    public static final class_2248 BLAJ_LESSER_ORE = registerBlock("blaj_lesser_ore",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_9629(2.0F, 1000.0F)
                    .method_29292()
                    .method_26249(class_2246::method_26113)
                    .method_9626(CustomSounds.BLAJ_BLOCK)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "blaj_lesser_ore")))));


    public static final class_2248 OXIDISED_DARKNESS = registerBlock("oxidised_darkness",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_9629(1.0F, 800.0F)
                    .method_29292()
                    .method_9628(0.9F)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "oxidised_darkness")))));

    public static final class_2248 CUBE_OF_FLESH = registerBlock("cube_of_flesh",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_9629(0.8F, 6.0F)
                    .method_31710(class_3620.field_16020)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "cube_of_flesh")))));

    public static final class_2248 VEINS = registerBlock("veins",
            new FluidloggableGlowLichenBlock(class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16020)
                    .method_9634()
                    .method_9632(0.2F)
                    .method_9626(class_2498.field_11545)
                    .method_50012(class_3619.field_15971)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "veins")))));

    public static final class_2248 PILE_OF_MEAT = registerBlock("pile_of_meat",
            new SmallDecorativeBlock(class_4970.class_2251.method_9637()
                    .method_9629(1F, 6.0F)
                    .method_31710(class_3620.field_16020)
                    .method_9626(class_2498.field_11545)
                    .method_50012(class_3619.field_15971)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "pile_of_meat"))),
                    class_2248.method_9541(1.0, 0.0, 1.0, 15.0, 4.0, 15.0)));

    public static final class_2248 STITCHED_FLESH = registerBlock("stitched_flesh",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_9629(0.8F, 6.0F)
                    .method_31710(class_3620.field_16020)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "stitched_flesh")))));

    public static final class_2248 CUBE_OF_PERCEIVING = registerBlock("cube_of_perceiving",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_9629(0.6F, 4.0F)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "cube_of_perceiving")))));

    public static final class_2248 PULLED_TEETH = registerBlock("pulled_teeth",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_9629(1.0F, 8.0F)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "pulled_teeth")))));

    public static final class_2248 SKIN = registerBlock("skin",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_9629(0.8F, 6.0F)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "skin")))));

    public static final class_2248 FILTH = registerBlock("filth",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_9629(0.8F, 6.0F)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "filth")))));

    public static final class_2248 HEAVENS_LIGHT = registerBlock("heavens_light",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_9629(1.0F, 800.0F)
                    .method_29292()
                    .method_45477()
                    .method_9634()
                    .method_22488()
                    .method_9631(value -> 10)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "heavens_light")))));

    public static final class_2248 POTENT_HEAVENS_LIGHT = registerBlock("potent_heavens_light",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_9629(1.0F, 800.0F)
                    .method_29292()
                    .method_45477()
                    .method_9634()
                    .method_22488()
                    .method_9631(value -> 15)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "potent_heavens_light")))));

    public static final class_2248 HEAVENS_EARTH = registerBlock("heavens_earth",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_9629(1.0F, 800.0F)
                    .method_29292()
                    .method_45477()
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "heavens_earth")))));

    public static final class_2248 CUBE_OF_GLUH = registerBlock("cube_of_gluh",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_9629(0.6F, 8.0F)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "cube_of_gluh")))));

    public static final class_2248 GLUH_VINE_STAGE0 = registerBlock("gluh_vine_stage0",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_9629(1.0F, 800.0F)
                    .method_22488()
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_50012(class_3619.field_15971)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "gluh_vine_stage0")))));

    public static final class_2248 GLUH_VINE_STAGE1 = registerBlock("gluh_vine_stage1",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_9629(1.0F, 800.0F)
                    .method_22488()
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_50012(class_3619.field_15971)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "gluh_vine_stage1")))));

    public static final class_2248 GLUH_VINE_STAGE2 = registerBlock("gluh_vine_stage2",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_9629(1.0F, 800.0F)
                    .method_22488()
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_50012(class_3619.field_15971)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "gluh_vine_stage2")))));

    public static final class_2248 GLUH_VINE_STAGE3 = registerBlock("gluh_vine_stage3",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_9629(1.0F, 800.0F)
                    .method_22488()
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_50012(class_3619.field_15971)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "gluh_vine_stage3")))));

    public static final class_2248 GLUH_VINE_STAGE4 = registerBlock("gluh_vine_stage4",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_9629(1.0F, 800.0F)
                    .method_22488()
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_50012(class_3619.field_15971)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "gluh_vine_stage4")))));

    public static final class_2248 GLUH_VINE_STAGE5 = registerBlock("gluh_vine_stage5",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_9629(1.0F, 800.0F)
                    .method_22488()
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_50012(class_3619.field_15971)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "gluh_vine_stage5")))));

    public static final class_2248 GLUH_VINE_STAGE6 = registerBlock("gluh_vine_stage6",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_9629(1.0F, 800.0F)
                    .method_22488()
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_50012(class_3619.field_15971)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "gluh_vine_stage6")))));

    public static final class_2248 GLUH_VINE_STAGE7 = registerBlock("gluh_vine_stage7",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_9629(1.0F, 800.0F)
                    .method_22488()
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_50012(class_3619.field_15971)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "gluh_vine_stage7")))));

    public static final class_2248 BARRIER = registerBlock("barrier",
            new BarrierBlock(class_4970.class_2251.method_9637()
                    .method_9629(0.5F, 1.0F)
                    .method_9618()
                    .method_22488()
                    .method_9631(value -> 3)
                    .method_9626(class_2498.field_44608)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "barrier")))));

    public static final class_2248 CERULEAN_PETALS = registerBlock("cerulean_petals", //!*texture
            new class_8169(class_4970.class_2251.method_9637()
                    .method_9634()
                    .method_9626(class_2498.field_42772)
                    .method_51517(class_1767.field_7955)
                    .method_50012(class_3619.field_15971)
                    .method_51371()
                    .method_22488()
                    .method_26249(class_2246::method_26113)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "cerulean_petals")))));

    public static final class_2248 BLUE_BELL = registerBlock("blue_bell",
            new class_2356(
                    class_1294.field_5922, // or any other StatusEffect
                    7.0F, // duration in seconds
                    class_4970.class_2251.method_9637()
    			    .method_31710(class_3620.field_16026)
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_49229(class_4970.class_2250.field_10657)
                    .method_50012(class_3619.field_15971)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "blue_bell")))));

    public static final class_2248 BLUE_FOXGLOVE = registerBlock("blue_foxglove", //!*texture
            new ExtraTallFlower(class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16026)
                    .method_9634()
                    .method_9618()
                    .method_22488()
                    .method_9640()
                    .method_9626(class_2498.field_11535)
                    .method_49229(class_4970.class_2250.field_10657)
                    .method_50012(class_3619.field_15971)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "blue_foxglove")))));

    public static final class_2248 CERULEAN_WILDGRASS = registerBlock("cerulean_wildgrass", //!*texture
            new class_2320(class_4970.class_2251.method_9637()
        			.method_31710(class_3620.field_16026)
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_49229(class_4970.class_2250.field_10657)
                    .method_50012(class_3619.field_15971)
                    .method_51371()
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "cerulean_wildgrass")))));

    public static final class_2248 CERULEAN_SHORTGRASS = registerBlock("cerulean_shortgrass", //!*texture
            new class_2526(class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16026)
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_49229(class_4970.class_2250.field_10657)
                    .method_50012(class_3619.field_15971)
                    .method_51371()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "cerulean_shortgrass")))));

    public static final class_2248 STARLIGHT_LICHEN = registerBlock("starlight_lichen", //!*texture
            new FluidloggableGlowLichenBlock(class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16026)
                    .method_9634()
                    .method_9632(0.2F)
                    .method_9626(class_2498.field_28427)
                    .method_9631(class_5777.method_37364(7))
                    .method_50012(class_3619.field_15971)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "starlight_lichen")))));

    public static final class_2248 GABRIELS_TRUMPETS_BUSH = registerBlock("gabriels_trumpets_bush", //!*texture
            new TwintailBerryBushBlock(class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16026)
                    .method_9640()
                    .method_9634()
                    .method_9626(class_2498.field_17579)
                    .method_50012(class_3619.field_15971)
                    .method_9632(0.2F)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "gabriels_trumpets_bush")))));

    public static final class_2248 SAPPHIRE_ROSE = registerBlock("sapphire_rose",
            new class_2356(
                    class_1294.field_5922, // or any other StatusEffect
                    7.0F, // duration in seconds
                    class_4970.class_2251.method_9637()
                            .method_31710(class_3620.field_16026)
                            .method_9634()
                            .method_9626(class_2498.field_11535)
                            .method_50012(class_3619.field_15971)
                            .method_9618()
                            .method_49229(class_4970.class_2250.field_10657)
                            .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "sapphire_rose")))));

    public static class_2248 DRAGONS_LEAP = registerBlock("dragons_leap",
            new LaunchBlock(class_4970.class_2251.method_9637()
                    //.sounds(BlockSoundGroup.STONE)
                    .method_9629(0.7F, 8.0F)
                    .method_9634()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "dragons_leap")))));

    public static class_2248 JESTERS_HAT = registerBlock("jesters_hat",
            new LaunchBlock(class_4970.class_2251.method_9637()
                    //.sounds(BlockSoundGroup.STONE)
                    .method_9629(0.7F, 8.0F)
                    .method_9634()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "jesters_hat")))));

    public static class_2248 LOAF = registerBlock("loaf",
            new SmallDecorativeBlock(class_4970.class_2251.method_9637()
                    .method_9626(class_2498.field_11535)
                    .method_9629(0.5F, 1.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "loaf"))),
                    class_2248.method_9541(5.0, 0.0, 2.0, 11.0, 7.0, 14.0),
                    class_2248.method_9541(5.0, 0.0, 2.0, 11.0, 7.0, 14.0),
                    class_2248.method_9541(2.0, 0.0, 5.0, 14.0, 7.0, 11.0),
                    class_2248.method_9541(2.0, 0.0, 5.0, 14.0, 7.0, 11.0)));

    public static final class_2248 INFESTED_ROCK = registerBlock("infested_rock",
            new CustomDirt(class_4970.class_2251.method_9637()
                    .method_9629(2.5F, 2.0F)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "infested_rock")))));

    public static final class_2248 OLD_SOIL = registerBlock("old_soil",
            new CustomDirt(class_4970.class_2251.method_9637()
                    .method_9629(1.5F, 1.5F)
                    .method_9626(class_2498.field_28700)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "old_soil")))));

    public static final class_2248 OLD_MEADOW = registerBlock("old_meadow",
            new CustomGrass(class_4970.class_2251.method_9637()
                    .method_9629(1.5F, 1.5F)
                    .method_9626(class_2498.field_11535)
                    .method_9640()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "old_meadow")))));

    public static final class_2248 DRAGONS_EYE_ORE = registerBlock("dragons_eye_ore",
            new CustomDirt(class_4970.class_2251.method_9637()
                    .method_9629(1.5F, 3.0F)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "dragons_eye_ore")))));

    public static final class_2248 PETRIFIED_STONE = registerBlock("petrified_stone",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_9629(3.3F, 20.0F)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "petrified_stone")))));

    public static final class_2248 CRACKED_PETRIFIED_STONE = registerBlock("cracked_petrified_stone",
            new class_2465(class_4970.class_2251.method_9637()
                    .method_9629(3.3F, 20.0F)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "cracked_petrified_stone")))));

    public static final class_2248 EMBOSSED_PETRIFIED_STONE = registerBlock("embossed_petrified_stone",
            new class_2465(class_4970.class_2251.method_9637()
                    .method_9629(3.3F, 20.0F)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "embossed_petrified_stone")))));

    public static final class_2248 CRACKED_EMBOSSED_PETRIFIED_STONE = registerBlock("cracked_embossed_petrified_stone",
            new class_2465(class_4970.class_2251.method_9637()
                    .method_9629(3.3F, 20.0F)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "cracked_embossed_petrified_stone")))));

    public static final class_2248 TILED_PETRIFIED_STONE = registerBlock("tiled_petrified_stone",
            new class_2465(class_4970.class_2251.method_9637()
                    .method_9629(3.3F, 20.0F)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "tiled_petrified_stone")))));

    public static final class_2248 CRACKED_TILED_PETRIFIED_STONE = registerBlock("cracked_tiled_petrified_stone",
            new class_2465(class_4970.class_2251.method_9637()
                    .method_9629(3.3F, 20.0F)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "cracked_tiled_petrified_stone")))));

    public static final class_2248 ADORNED_PETRIFIED_STONE = registerBlock("adorned_petrified_stone",
            new class_2465(class_4970.class_2251.method_9637()
                    .method_9629(3.3F, 20.0F)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "adorned_petrified_stone")))));

    public static final class_2248 PETRIFIED_STONE_STAIRS = registerBlock("petrified_stone_stairs",
            new FluidloggableStairsBlock(PETRIFIED_STONE.method_9564(), class_4970.class_2251.method_9637()
                    .method_9629(3.3F, 20.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "petrified_stone_stairs")))));

    public static final class_2248 PETRIFIED_STONE_WALL = registerBlock("petrified_stone_wall",
            new FluidloggableWallBlock(class_4970.class_2251.method_9637()
                    .method_9629(3.3F, 20.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "petrified_stone_wall")))));

    public static final class_2248 PETRIFIED_STONE_COLUMN = registerBlock("petrified_stone_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_9629(3.3F, 20.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "petrified_stone_column")))));

    public static final class_2248 PETRIFIED_STONE_SLAB = registerBlock("petrified_stone_slab",
            new FluidloggableSlabBlock(class_4970.class_2251.method_9637()
                    .method_9629(3.3F, 20.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "petrified_stone_slab")))));

    public static final class_2248 EMBOSSED_PETRIFIED_STONE_STAIRS = registerBlock("embossed_petrified_stone_stairs",
            new FluidloggableStairsBlock(EMBOSSED_PETRIFIED_STONE.method_9564(), class_4970.class_2251.method_9637()
                    .method_9629(3.3F, 20.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "embossed_petrified_stone_stairs")))));

    public static final class_2248 EMBOSSED_PETRIFIED_STONE_WALL = registerBlock("embossed_petrified_stone_wall",
            new FluidloggableWallBlock(class_4970.class_2251.method_9637()
                    .method_9629(3.3F, 20.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "embossed_petrified_stone_wall")))));

    public static final class_2248 EMBOSSED_PETRIFIED_STONE_COLUMN = registerBlock("embossed_petrified_stone_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_9629(3.3F, 20.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "embossed_petrified_stone_column")))));

    public static final class_2248 EMBOSSED_PETRIFIED_STONE_SLAB = registerBlock("embossed_petrified_stone_slab",
            new FluidloggableSlabBlock(class_4970.class_2251.method_9637()
                    .method_9629(3.3F, 20.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "embossed_petrified_stone_slab")))));

    public static final class_2248 TILED_PETRIFIED_STONE_STAIRS = registerBlock("tiled_petrified_stone_stairs",
            new FluidloggableStairsBlock(TILED_PETRIFIED_STONE.method_9564(), class_4970.class_2251.method_9637()
                    .method_9629(3.3F, 20.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "tiled_petrified_stone_stairs")))));

    public static final class_2248 TILED_PETRIFIED_STONE_WALL = registerBlock("tiled_petrified_stone_wall",
            new FluidloggableWallBlock(class_4970.class_2251.method_9637()
                    .method_9629(3.3F, 20.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "tiled_petrified_stone_wall")))));

    public static final class_2248 TILED_PETRIFIED_STONE_COLUMN = registerBlock("tiled_petrified_stone_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_9629(3.3F, 20.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "tiled_petrified_stone_column")))));

    public static final class_2248 TILED_PETRIFIED_STONE_SLAB = registerBlock("tiled_petrified_stone_slab",
            new FluidloggableSlabBlock(class_4970.class_2251.method_9637()
                    .method_9629(3.3F, 20.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "tiled_petrified_stone_slab")))));

    public static final class_2248 ADORNED_PETRIFIED_STONE_STAIRS = registerBlock("adorned_petrified_stone_stairs",
            new FluidloggableStairsBlock(ADORNED_PETRIFIED_STONE.method_9564(), class_4970.class_2251.method_9637()
                    .method_9629(3.3F, 20.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "adorned_petrified_stone_stairs")))));

    public static final class_2248 ADORNED_PETRIFIED_STONE_WALL = registerBlock("adorned_petrified_stone_wall",
            new FluidloggableWallBlock(class_4970.class_2251.method_9637()
                    .method_9629(3.3F, 20.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "adorned_petrified_stone_wall")))));

    public static final class_2248 ADORNED_PETRIFIED_STONE_COLUMN = registerBlock("adorned_petrified_stone_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_9629(3.3F, 20.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "adorned_petrified_stone_column")))));

    public static final class_2248 ADORNED_PETRIFIED_STONE_SLAB = registerBlock("adorned_petrified_stone_slab",
            new FluidloggableSlabBlock(class_4970.class_2251.method_9637()
                    .method_9629(3.3F, 20.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "adorned_petrified_stone_slab")))));

    public static final class_2248 GROTESQUE = registerBlock("grotesque",
            new CustomHorisontalFacingBlock(class_4970.class_2251.method_9637()
                    .method_9629(3.3F, 20.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "grotesque")))));

    public static final class_2248 ROD_OF_LUMINESCENCE = registerBlock("rod_of_luminescence",
            new TwoBlockTallRod(class_4970.class_2251.method_9637()
                    .method_9629(1.0F, 0.3F)
                    .method_9631(value -> 15)
                    .method_9626(class_2498.field_11537)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "rod_of_luminescence")))));

    public static final class_2248 CAN_OF_RETARDATION = registerBlock("can_of_retardation",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_9629(1.0F, 0.3F)
                    .method_29292()
                    .method_9631(value -> 15)
                    .method_9628(0.1F)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "can_of_retardation")))));

    public static final class_3609 STILL_BLOOD = fluid_init.STILL_BLOOD;
    public static final class_3609 FLOWING_BLOOD = fluid_init.FLOWING_BLOOD;
    public static final class_2248 BLOOD = fluid_init.BLOOD;
    public static final class_3609 STILL_GUNK = fluid_init.STILL_GUNK;
    public static final class_3609 FLOWING_GUNK = fluid_init.FLOWING_GUNK;
    public static final class_2248 GUNK = fluid_init.GUNK;

    public static final class_2248 SALT = registerBlock("salt",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_9629(0.9F, 0.3F)
                    .method_31710(class_3620.field_16022)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "salt")))));

    public static final class_2248 SALT_CRYSTAL = registerBlock("salt_crystal", //!add custom class
            new class_5689(class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16022)
                    .method_51369()
                    .method_22488()
                    .method_9626(class_2498.field_28061)
                    .method_9640()
                    .method_9629(1.5F, 3.0F)
                    .method_9624()
                    .method_49229(class_4970.class_2250.field_10657)
                    .method_50012(class_3619.field_15971)
                    .method_26236(class_2246::method_26122)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "salt_crystal")))));

    public static final class_2248 SHADOW = registerBlock("shadow",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_9618()
                    .method_9634()
                    .method_22488()
                    .method_45477()
                    .method_29292()
                    .method_31710(class_3620.field_16009)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "shadow")))));

    public static final class_2248 FRAGE_MARKER = registerBlock("frage_marker",
            new MarkerBlock(class_4970.class_2251.method_9637()
                    .method_9618()
                    .method_9634()
                    .method_22488()
                    .method_45477()
                    .method_42327()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "frage_marker")))));

    public static final class_2248 BLUE_HOSTAS = registerBlock("blue_hostas",
            new class_2526(class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16026)
                    .method_9634()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_49229(class_4970.class_2250.field_10657)
                    .method_50012(class_3619.field_15971)
                    .method_51371()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "blue_hostas")))));

    public static final class_2248 GOLDEN_THURIBLE = registerBlock("golden_thurible",
            new ThuribleBlock(CustomParticles.GOLD_INCENSE, class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15994)
                    .method_51369()
                    .method_9632(3.5F)
                    .method_9626(class_2498.field_17734)
                    .method_22488()
                    .method_50012(class_3619.field_15971)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "golden_thurible")))));

    public static final class_2248 GOLD_WALL = registerBlock("gold_wall",
            new FluidloggableWallBlock(class_4970.class_2251.method_9637()
                    .method_22488()
                    .method_29292()
                    .method_31710(class_3620.field_15994)
                    .method_9629(3.0F, 6.0F)
                    .method_9626(class_2498.field_11533)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "gold_wall")))));

    public static final class_2248 GOLD_STAIRS = registerBlock("gold_stairs",
            new FluidloggableStairsBlock(class_2246.field_10489.method_9564(), class_4970.class_2251.method_9637()
                    .method_22488()
                    .method_29292()
                    .method_31710(class_3620.field_15994)
                    .method_9629(3.0F, 6.0F)
                    .method_9626(class_2498.field_11533)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "gold_stairs")))));

    public static final class_2248 GOLD_SLAB = registerBlock("gold_slab",
            new FluidloggableSlabBlock(class_4970.class_2251.method_9637()
                    .method_22488()
                    .method_29292()
                    .method_31710(class_3620.field_15994)
                    .method_9629(3.0F, 6.0F)
                    .method_9626(class_2498.field_11533)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "gold_slab")))));

    public static final class_2248 GOLD_COLUMN = registerBlock("gold_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_22488()
                    .method_29292()
                    .method_31710(class_3620.field_15994)
                    .method_9629(3.0F, 6.0F)
                    .method_9626(class_2498.field_11533)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "gold_column")))));

    public static final class_2248 GOLD_TRAPDOOR = registerBlock("gold_trapdoor",
            new FluidloggableTrapdoorBlock(class_8177.field_47100, class_4970.class_2251.method_9637() //set to copper because this is mainly just a decorative block and not supposed to have any unique redstone functionality
                    .method_22488()
                    .method_29292()
                    .method_31710(class_3620.field_15994)
                    .method_9629(3.0F, 6.0F)
                    .method_9626(class_2498.field_11533)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "gold_trapdoor")))));

    public static final class_2248 GOLD_BUTTON = registerBlock("gold_button",
            new class_2269(class_8177.field_47100, 10, class_4970.class_2251.method_9637() //set to copper because this is mainly just a decorative block and not supposed to have any unique redstone functionality
                    .method_22488()
                    .method_29292()
                    .method_31710(class_3620.field_15994)
                    .method_9629(3.0F, 6.0F)
                    .method_9626(class_2498.field_11533)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "gold_button")))));

    public static final class_2248 GOLD_BARS = registerBlock("gold_bars",
            new class_2389(class_4970.class_2251.method_9637()
                    .method_29292()
                    .method_22488()
                    .method_9626(class_2498.field_11533)
                    .method_31710(class_3620.field_15994)
                    .method_9629(5F, 6.0F)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "gold_bars")))));

    public static final class_2248 GOLD_LADDER = registerBlock("gold_ladder",
            new FluidloggableLadderBlock(class_4970.class_2251.method_9637()
                    .method_29292()
                    .method_22488()
                    .method_9634()
                    .method_9626(class_2498.field_11533)
                    .method_31710(class_3620.field_15994)
                    .method_9629(3F, 6.0F)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "gold_ladder")))));


    public static final class_2248 GINKGO_LOG = registerBlock("ginkgo_log",
            new class_2465(class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15994)
                    .method_50013()
                    .method_9632(2f)
                    .method_9626(class_2498.field_11547)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "ginkgo_log")))));

    public static final class_2248 STRIPPED_GINKGO_LOG = registerBlock("stripped_ginkgo_log",
            new class_2465(class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15994)
                    .method_50013()
                    .method_9632(2f)
                    .method_9626(class_2498.field_11547)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "stripped_ginkgo_log")))));

    public static final class_2248 GINKGO_PLANKS = registerBlock("ginkgo_planks",
            new class_2465(class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15994)
                    .method_50013()
                    .method_9632(2f)
                    .method_9626(class_2498.field_11547)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "ginkgo_planks")))));

    public static final class_2248 GINKGO_STAIRS = registerBlock("ginkgo_stairs",
            new FluidloggableStairsBlock(class_2246.field_10489.method_9564(), class_4970.class_2251.method_9637()
                    .method_22488()
                    .method_29292()
                    .method_31710(class_3620.field_15994)
                    .method_9629(3.0F, 6.0F)
                    .method_9626(class_2498.field_11533)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "ginkgo_stairs")))));

    public static final class_2248 GINKGO_SLAB = registerBlock("ginkgo_slab",
            new FluidloggableSlabBlock(class_4970.class_2251.method_9637()
                    .method_22488()
                    .method_29292()
                    .method_31710(class_3620.field_15994)
                    .method_9629(3.0F, 6.0F)
                    .method_9626(class_2498.field_11533)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "ginkgo_slab")))));

    public static final class_2248 GINKGO_TRAPDOOR = registerBlock("ginkgo_trapdoor",
            new FluidloggableTrapdoorBlock(class_8177.field_42823, class_4970.class_2251.method_9637() //set to copper because this is mainly just a decorative block and not supposed to have any unique redstone functionality
                    .method_22488()
                    .method_29292()
                    .method_31710(class_3620.field_15994)
                    .method_9629(3.0F, 6.0F)
                    .method_9626(class_2498.field_11533)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "ginkgo_trapdoor")))));

    public static final class_2248 GINKGO_BUTTON = registerBlock("ginkgo_button",
            new class_2269(class_8177.field_42823, 10, class_4970.class_2251.method_9637() //set to copper because this is mainly just a decorative block and not supposed to have any unique redstone functionality
                    .method_22488()
                    .method_29292()
                    .method_31710(class_3620.field_15994)
                    .method_9629(3.0F, 6.0F)
                    .method_9626(class_2498.field_11533)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "ginkgo_button")))));

    public static final class_2248 GINKGO_LEAVES = registerBlock("ginkgo_leaves",
            new NonDecayingLeavesBlock(5, CustomParticles.GOLD_INCENSE, class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15994)
                    .method_9626(class_2498.field_11535)
                    .method_50013()
                    .method_9632(0.2F)
                    .method_22488()
                    .method_26235(class_2246::method_26126)
                    .method_26243(class_2246::method_26122)
                    .method_26245(class_2246::method_26122)
                    .method_50012(class_3619.field_15971)
                    .method_26236(class_2246::method_26122)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "ginkgo_leaves")))));

    public static final class_2248 GINKGO_SAPLING = registerBlock("ginkgo_sapling",
            new class_2473(ModSaplingGenerators.GINKGO, class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15994)
                    .method_9626(class_2498.field_11535)
                    .method_50013()
                    .method_22488()
                    .method_9634()
                    .method_50012(class_3619.field_15971)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "ginkgo_sapling")))));

    public static final class_2248 CHANTERELLE = registerBlock("chanterelle",
            new class_2420(ModConfiguredFeatures.GINKGO_KEY, class_4970.class_2251.method_9637() //make large mushroom variant!
                    .method_31710(class_3620.field_15987)
                    .method_9634()
                    .method_9640()
                    .method_9618()
                    .method_9626(class_2498.field_11535)
                    .method_26247(class_2246::method_26113)
                    .method_50012(class_3619.field_15971)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "chanterelle")))));


    public static final class_2248 VAULTS_STANCHION_SAPLING = registerBlock("vaults_stanchion_sapling",
            new class_2473(ModSaplingGenerators.VAULTS_STANCHION, class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_25705)
                    .method_9626(class_2498.field_11535)
                    .method_50013()
                    .method_22488()
                    .method_9634()
                    .method_50012(class_3619.field_15971)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "vaults_stanchion_sapling")))));

    public static final class_2248 AFHD = registerBlock("afhd",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_29292()
                    .method_31710(class_3620.field_15980)
                    .method_9629(3F, 12.0F)
                    .method_9626(class_2498.field_11544)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "afhd")))));

    public static final class_2248 SLATE = registerBlock("slate",
            new class_2465(class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16009)
                    .method_9629(1F, 3.0F)
                    .method_9626(class_2498.field_29035)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "slate")))));

    public static final class_2248 ITORE = registerBlock("itore",
            new class_2465(class_4970.class_2251.method_9637()
                    .method_29292()
                    .method_31710(class_3620.field_16009)
                    .method_9629(1F, 3.0F)
                    .method_9626(class_2498.field_11544)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "itore")))));

    public static final class_2248 TANKARD = registerBlock("tankard",
            new SmallDecorativeBlock(class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15977)
                    .method_9629(0.3F, 1.0F)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "tankard"))),
                    class_2248.method_9541(4.0, 0.0, 5.0, 11.0, 7.0, 10.0),
                    class_2248.method_9541(5.0, 0.0, 6.0, 12.0, 7.0, 11.0),
                    class_2248.method_9541(6.0, 0.0, 4.0, 11.0, 7.0, 11.0),
                    class_2248.method_9541(5.0, 0.0, 5.0, 10.0, 7.0, 12.0)));

    public static final class_2248 SPIRITS = registerBlock("spirits",
            new SmallDecorativeBlock(class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16022)
                    .method_9629(0.3F, 1.0F)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "spirits"))),
                    class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 13.0, 10.0)));

    public static final class_2248 SAUERKRAUT = registerBlock("sauerkraut",
            new SmallDecorativeBlock(class_4970.class_2251.method_9637()
                    .method_9629(0.3F, 1.0F)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "sauerkraut"))),
                    class_2248.method_9541(6.0, 0.0, 6.0, 10.0, 6.5, 10.0)));

    public static final class_2248 WHITE_COFFER = registerBlock("white_coffer",
            new ColouredCofferBlock(class_1767.field_7952, class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15978)
                    .method_9629(1F, 10.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "white_coffer")))));

    public static final class_2248 ORANGE_COFFER = registerBlock("orange_coffer",
            new ColouredCofferBlock(class_1767.field_7946, class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15978)
                    .method_9629(1F, 10.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "orange_coffer")))));

    public static final class_2248 MAGENTA_COFFER = registerBlock("magenta_coffer",
            new ColouredCofferBlock(class_1767.field_7958, class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15978)
                    .method_9629(1F, 10.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "magenta_coffer")))));

    public static final class_2248 LIGHT_BLUE_COFFER = registerBlock("light_blue_coffer",
            new ColouredCofferBlock(class_1767.field_7951, class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15978)
                    .method_9629(1F, 10.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "light_blue_coffer")))));

    public static final class_2248 YELLOW_COFFER = registerBlock("yellow_coffer",
            new ColouredCofferBlock(class_1767.field_7947, class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15978)
                    .method_9629(1F, 10.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "yellow_coffer")))));

    public static final class_2248 LIME_COFFER = registerBlock("lime_coffer",
            new ColouredCofferBlock(class_1767.field_7961, class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15978)
                    .method_9629(1F, 10.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "lime_coffer")))));

    public static final class_2248 PINK_COFFER = registerBlock("pink_coffer",
            new ColouredCofferBlock(class_1767.field_7954, class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15978)
                    .method_9629(1F, 10.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "pink_coffer")))));

    public static final class_2248 GREY_COFFER = registerBlock("grey_coffer",
            new ColouredCofferBlock(class_1767.field_7944, class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15978)
                    .method_9629(1F, 10.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "grey_coffer")))));

    public static final class_2248 LIGHT_GREY_COFFER = registerBlock("light_grey_coffer",
            new ColouredCofferBlock(class_1767.field_7967, class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15978)
                    .method_9629(1F, 10.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "light_grey_coffer")))));

    public static final class_2248 CYAN_COFFER = registerBlock("cyan_coffer",
            new ColouredCofferBlock(class_1767.field_7955, class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15978)
                    .method_9629(1F, 10.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "cyan_coffer")))));

    public static final class_2248 PURPLE_COFFER = registerBlock("purple_coffer",
            new ColouredCofferBlock(class_1767.field_7945, class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15978)
                    .method_9629(1F, 10.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "purple_coffer")))));

    public static final class_2248 BLUE_COFFER = registerBlock("blue_coffer",
            new ColouredCofferBlock(class_1767.field_7966, class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15978)
                    .method_9629(1F, 10.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "blue_coffer")))));

    public static final class_2248 BROWN_COFFER = registerBlock("brown_coffer",
            new ColouredCofferBlock(class_1767.field_7957, class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15978)
                    .method_9629(1F, 10.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "brown_coffer")))));

    public static final class_2248 GREEN_COFFER = registerBlock("green_coffer",
            new ColouredCofferBlock(class_1767.field_7942, class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15978)
                    .method_9629(1F, 10.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "green_coffer")))));

    public static final class_2248 RED_COFFER = registerBlock("red_coffer",
            new ColouredCofferBlock(class_1767.field_7964, class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15978)
                    .method_9629(1F, 10.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "red_coffer")))));

    public static final class_2248 BLACK_COFFER = registerBlock("black_coffer",
            new ColouredCofferBlock(class_1767.field_7963, class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15978)
                    .method_9629(1F, 10.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "black_coffer")))));

    public static final class_2248 SIMPLE_COFFER = registerBlock("simple_coffer",
            new CustomHorisontalFacingBlock(class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15978)
                    .method_9629(1F, 10.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "simple_coffer")))));



    public static final class_2248 SILVER_ORE = registerBlock("silver_ore",
            new class_2465(class_4970.class_2251.method_9637()
                    .method_29292()
                    .method_31710(class_3620.field_15978)
                    .method_9629(2.6F, 4.0F)
                    .method_9626(class_2498.field_11544)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "silver_ore")))));

    public static final class_2248 SILVER_VEIN = registerBlock("silver_vein",
            new class_2465(class_4970.class_2251.method_9637()
                    .method_29292()
                    .method_31710(class_3620.field_15978)
                    .method_9629(2.6F, 4.0F)
                    .method_9626(class_2498.field_11544)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "silver_vein")))));

    public static final class_2248 RAW_SILVER_BLOCK = registerBlock("raw_silver_block",
            new class_2465(class_4970.class_2251.method_9637()
                    .method_29292()
                    .method_31710(class_3620.field_15978)
                    .method_9629(2.6F, 4.0F)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "raw_silver_block")))));

    public static final class_2248 SILVER_BLOCK = registerBlock("silver_block",
            new class_2465(class_4970.class_2251.method_9637()
                    .method_29292()
                    .method_31710(class_3620.field_15993)
                    .method_9629(2.8F, 4.0F)
                    .method_9626(class_2498.field_11533)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "silver_block")))));

    public static final class_2248 SILVER_WALL = registerBlock("silver_wall",
            new FluidloggableWallBlock(class_4970.class_2251.method_9637()
                    .method_22488()
                    .method_29292()
                    .method_31710(class_3620.field_15993)
                    .method_9629(2.8F, 4.0F)
                    .method_9626(class_2498.field_11533)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "silver_wall")))));

    public static final class_2248 SILVER_STAIRS = registerBlock("silver_stairs",
            new FluidloggableStairsBlock(class_2246.field_10489.method_9564(), class_4970.class_2251.method_9637()
                    .method_22488()
                    .method_29292()
                    .method_31710(class_3620.field_15993)
                    .method_9629(2.8F, 4.0F)
                    .method_9626(class_2498.field_11533)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "silver_stairs")))));

    public static final class_2248 SILVER_SLAB = registerBlock("silver_slab",
            new FluidloggableSlabBlock(class_4970.class_2251.method_9637()
                    .method_22488()
                    .method_29292()
                    .method_31710(class_3620.field_15993)
                    .method_9629(2.8F, 4.0F)
                    .method_9626(class_2498.field_11533)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "silver_slab")))));

    public static final class_2248 SILVER_COLUMN = registerBlock("silver_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_22488()
                    .method_29292()
                    .method_31710(class_3620.field_15993)
                    .method_9629(2.8F, 4.0F)
                    .method_9626(class_2498.field_11533)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "silver_column")))));

    public static final class_2248 SILVER_LANTERN = registerBlock("silver_lantern",
            new FluidloggableLanternBlock(class_4970.class_2251.method_9637()
                    .method_29292()
                    .method_31710(class_3620.field_15993)
                    .method_9629(2.8F, 4.0F)
                    .method_9626(class_2498.field_11533)
                    .method_9631(state -> 15)
                    .method_50012(class_3619.field_15971)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "silver_lantern")))));

    public static final class_2248 SILVER_THURIBLE = registerBlock("silver_thurible",
            new ThuribleBlock(CustomParticles.WHITE_INCENSE, class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15993)
                    .method_51369()
                    .method_9632(2.8F)
                    .method_9626(class_2498.field_17734)
                    .method_22488()
                    .method_50012(class_3619.field_15971)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "silver_thurible")))));

    public static final class_2248 GRAVESTONE = registerBlock("gravestone",
            new StorageTemplateBlock(class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_15978)
                    .method_9629(1.3F, 50.0F)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "gravestone")))));

    public static final class_2248 REDSTONE_LANTERN = registerBlock("redstone_lantern",
            new FluidloggableLanternBlock(class_4970.class_2251.method_9637()
                    .method_29292()
                    .method_31710(class_3620.field_16012)
                    .method_9629(2.8F, 4.0F)
                    .method_9626(class_2498.field_11533)
                    .method_9631(state -> 15)
                    .method_50012(class_3619.field_15971)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "redstone_lantern")))));

    public static final class_2248 REDSTONE_CHAIN = registerBlock("redstone_chain",
            new class_5172(class_4970.class_2251.method_9637()
                    .method_51369()
                    .method_29292()
                    .method_9629(5.0F, 6.0F)
                    .method_9626(class_2498.field_24119)
                    .method_22488()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "redstone_chain")))));

    public static final class_2248 EMERALD_WALL = registerBlock("emerald_wall",
            new FluidloggableWallBlock(class_4970.class_2251.method_9637()
                    .method_22488()
                    .method_29292()
                    .method_31710(class_3620.field_16001)
                    .method_9629(5.0F, 6.0F)
                    .method_9626(class_2498.field_11533)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "emerald_wall")))));

    public static final class_2248 EMERALD_STAIRS = registerBlock("emerald_stairs",
            new FluidloggableStairsBlock(class_2246.field_10489.method_9564(), class_4970.class_2251.method_9637()
                    .method_22488()
                    .method_29292()
                    .method_31710(class_3620.field_16001)
                    .method_9629(5.0F, 6.0F)
                    .method_9626(class_2498.field_11533)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "emerald_stairs")))));

    public static final class_2248 EMERALD_SLAB = registerBlock("emerald_slab",
            new FluidloggableSlabBlock(class_4970.class_2251.method_9637()
                    .method_22488()
                    .method_29292()
                    .method_31710(class_3620.field_16001)
                    .method_9629(5.0F, 6.0F)
                    .method_9626(class_2498.field_11533)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "emerald_slab")))));

    public static final class_2248 EMERALD_COLUMN = registerBlock("emerald_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_22488()
                    .method_29292()
                    .method_31710(class_3620.field_16001)
                    .method_9629(5.0F, 6.0F)
                    .method_9626(class_2498.field_11533)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "emerald_column")))));

    public static final class_2248 KAOLIN = registerBlock("kaolin",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16025)
                    .method_9629(1.1F, 1.0F)
                    .method_9626(class_2498.field_37641)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "kaolin")))));

    public static final class_2248 IMPERIAL_JADE_BLOCK = registerBlock("imperial_jade_block",
            new class_2248(class_4970.class_2251.method_9637()
                    .method_31710(class_3620.field_16001)
                    .method_9629(4F, 10.0F)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "imperial_jade_block")))));

    public static final class_2248 IMPERIAL_JADE_LANTERN = registerBlock("imperial_jade_lantern",
            new FluidloggableLanternBlock(class_4970.class_2251.method_9637()
                    .method_29292()
                    .method_31710(class_3620.field_16001)
                    .method_9629(5F, 10.0F)
                    .method_9631(state -> 15)
                    .method_50012(class_3619.field_15971)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "imperial_jade_lantern")))));


    public static class_2248 registerBlock(String name, class_2248 block) { //this is the method to load a new (non-item) block
        class_2960 id = class_2960.method_60655("the_tower", name);
        class_5321<class_2248> blockKey = class_5321.method_29179(class_7924.field_41254, id);
        return class_2378.method_39197(class_7923.field_41175, blockKey, block);
    }

    public static void registerBlockItem(String name, class_2248 block) {
        class_5321<class_1792> itemKey = class_5321.method_29179(class_7924.field_41197, The_Tower.id(name));
        class_1747 blockItem = new class_1747(block, new class_1792.class_1793().method_63686(itemKey));
        item_init.register(name, blockItem);
    }

    public static void load() {
        registerBlockItem("darkness",DARKNESS);
        registerBlockItem("oxidised_darkness",OXIDISED_DARKNESS);
        registerBlockItem("cube_of_flesh",CUBE_OF_FLESH);
        registerBlockItem("cube_of_perceiving", CUBE_OF_PERCEIVING); //*add texture
        registerBlockItem("pulled_teeth", PULLED_TEETH);
        registerBlockItem("skin", SKIN);
        registerBlockItem("filth", FILTH);
        registerBlockItem("heavens_light", HEAVENS_LIGHT);
        registerBlockItem("potent_heavens_light", POTENT_HEAVENS_LIGHT);
        registerBlockItem("heavens_earth", HEAVENS_EARTH);
        registerBlockItem("cube_of_gluh", CUBE_OF_GLUH);
        registerBlockItem("stitched_flesh", STITCHED_FLESH);
        registerBlockItem("gluh_vine_stage0",GLUH_VINE_STAGE0);
        registerBlockItem("gluh_vine_stage1",GLUH_VINE_STAGE1);
        registerBlockItem("gluh_vine_stage2",GLUH_VINE_STAGE2);
        registerBlockItem("gluh_vine_stage3",GLUH_VINE_STAGE3);
        registerBlockItem("gluh_vine_stage4",GLUH_VINE_STAGE4);
        registerBlockItem("gluh_vine_stage5",GLUH_VINE_STAGE5);
        registerBlockItem("gluh_vine_stage6",GLUH_VINE_STAGE6);
        registerBlockItem("gluh_vine_stage7",GLUH_VINE_STAGE7);
        registerBlockItem("cerulean_petals", CERULEAN_PETALS);
        registerBlockItem("blue_bell", BLUE_BELL);
        registerBlockItem("blue_foxglove", BLUE_FOXGLOVE);
        registerBlockItem("cerulean_wildgrass", CERULEAN_WILDGRASS);
        registerBlockItem("starlight_lichen", STARLIGHT_LICHEN);
        registerBlockItem("gabriels_trumpets_bush", GABRIELS_TRUMPETS_BUSH); // make berries and change loot table
        registerBlockItem("sapphire_rose", SAPPHIRE_ROSE);
        registerBlockItem("infested_rock", INFESTED_ROCK);
        registerBlockItem("dragons_eye_ore", DRAGONS_EYE_ORE);
        registerBlockItem("petrified_stone", PETRIFIED_STONE);
        registerBlockItem("cracked_petrified_stone", CRACKED_PETRIFIED_STONE);
        registerBlockItem("embossed_petrified_stone", EMBOSSED_PETRIFIED_STONE);
        registerBlockItem("cracked_embossed_petrified_stone", CRACKED_EMBOSSED_PETRIFIED_STONE);
        registerBlockItem("adorned_petrified_stone", ADORNED_PETRIFIED_STONE);
        registerBlockItem("tiled_petrified_stone", TILED_PETRIFIED_STONE);
        registerBlockItem("cracked_tiled_petrified_stone", CRACKED_TILED_PETRIFIED_STONE);
        registerBlockItem("petrified_stone_stairs", PETRIFIED_STONE_STAIRS);
        registerBlockItem("petrified_stone_wall", PETRIFIED_STONE_WALL);
        registerBlockItem("petrified_stone_column", PETRIFIED_STONE_COLUMN);
        registerBlockItem("petrified_stone_slab", PETRIFIED_STONE_SLAB);
        registerBlockItem("embossed_petrified_stone_stairs", EMBOSSED_PETRIFIED_STONE_STAIRS);
        registerBlockItem("embossed_petrified_stone_wall", EMBOSSED_PETRIFIED_STONE_WALL);
        registerBlockItem("embossed_petrified_stone_column", EMBOSSED_PETRIFIED_STONE_COLUMN);
        registerBlockItem("embossed_petrified_stone_slab", EMBOSSED_PETRIFIED_STONE_SLAB);
        registerBlockItem("tiled_petrified_stone_stairs", TILED_PETRIFIED_STONE_STAIRS);
        registerBlockItem("tiled_petrified_stone_wall", TILED_PETRIFIED_STONE_WALL);
        registerBlockItem("tiled_petrified_stone_column", TILED_PETRIFIED_STONE_COLUMN);
        registerBlockItem("tiled_petrified_stone_slab", TILED_PETRIFIED_STONE_SLAB);
        registerBlockItem("adorned_petrified_stone_stairs", ADORNED_PETRIFIED_STONE_STAIRS);
        registerBlockItem("adorned_petrified_stone_wall", ADORNED_PETRIFIED_STONE_WALL);
        registerBlockItem("adorned_petrified_stone_column", ADORNED_PETRIFIED_STONE_COLUMN);
        registerBlockItem("adorned_petrified_stone_slab", ADORNED_PETRIFIED_STONE_SLAB);
        registerBlockItem("cerulean_shortgrass", CERULEAN_SHORTGRASS);
        registerBlockItem("rod_of_luminescence", ROD_OF_LUMINESCENCE);
        registerBlockItem("can_of_retardation", CAN_OF_RETARDATION);
        registerBlockItem("dragons_leap", DRAGONS_LEAP);
        registerBlockItem("jesters_hat", JESTERS_HAT);
        registerBlockItem("loaf", LOAF);
        registerBlockItem("gravestone", GRAVESTONE);
        registerBlockItem("shadow", SHADOW);
        registerBlockItem("blue_hostas", BLUE_HOSTAS);
        registerBlockItem("salt", SALT);
        registerBlockItem("golden_thurible", GOLDEN_THURIBLE);
        registerBlockItem("gold_wall", GOLD_WALL);
        registerBlockItem("gold_stairs", GOLD_STAIRS);
        registerBlockItem("gold_slab", GOLD_SLAB);
        registerBlockItem("gold_column", GOLD_COLUMN);
        registerBlockItem("afhd", AFHD);
        registerBlockItem("slate", SLATE);
        registerBlockItem("itore", ITORE);
        registerBlockItem("tankard", TANKARD);
        registerBlockItem("spirits", SPIRITS);
        registerBlockItem("blaj_ore", BLAJ_ORE);
        registerBlockItem("blaj_lesser_ore", BLAJ_LESSER_ORE);
        registerBlockItem("gold_bars", GOLD_BARS);
        registerBlockItem("grotesque", GROTESQUE);
        registerBlockItem("gold_trapdoor", GOLD_TRAPDOOR);
        registerBlockItem("gold_ladder", GOLD_LADDER);
        registerBlockItem("sauerkraut", SAUERKRAUT);
        registerBlockItem("white_coffer", WHITE_COFFER);
        registerBlockItem("orange_coffer", ORANGE_COFFER);
        registerBlockItem("magenta_coffer", MAGENTA_COFFER);
        registerBlockItem("light_blue_coffer", LIGHT_BLUE_COFFER);
        registerBlockItem("yellow_coffer", YELLOW_COFFER);
        registerBlockItem("lime_coffer", LIME_COFFER);
        registerBlockItem("pink_coffer", PINK_COFFER);
        registerBlockItem("grey_coffer", GREY_COFFER);
        registerBlockItem("light_grey_coffer", LIGHT_GREY_COFFER);
        registerBlockItem("cyan_coffer", CYAN_COFFER);
        registerBlockItem("purple_coffer", PURPLE_COFFER);
        registerBlockItem("blue_coffer", BLUE_COFFER);
        registerBlockItem("brown_coffer", BROWN_COFFER);
        registerBlockItem("green_coffer", GREEN_COFFER);
        registerBlockItem("red_coffer", RED_COFFER);
        registerBlockItem("black_coffer", BLACK_COFFER);
        registerBlockItem("simple_coffer", SIMPLE_COFFER);
        registerBlockItem("ginkgo_log", GINKGO_LOG);
        registerBlockItem("ginkgo_leaves", GINKGO_LEAVES);
        registerBlockItem("silver_ore", SILVER_ORE);
        registerBlockItem("silver_vein", SILVER_VEIN);
        registerBlockItem("gold_button", GOLD_BUTTON);
        registerBlockItem("silver_lantern", SILVER_LANTERN);
        registerBlockItem("silver_block", SILVER_BLOCK);
        registerBlockItem("old_soil", OLD_SOIL);
        registerBlockItem("old_meadow", OLD_MEADOW);
        registerBlockItem("silver_thurible", SILVER_THURIBLE);
        registerBlockItem("raw_silver_block", RAW_SILVER_BLOCK);
        registerBlockItem("emerald_wall", EMERALD_WALL);
        registerBlockItem("emerald_column", EMERALD_COLUMN);
        registerBlockItem("emerald_slab", EMERALD_SLAB);
        registerBlockItem("emerald_stairs", EMERALD_STAIRS);
        registerBlockItem("kaolin", KAOLIN);
        registerBlockItem("silver_wall", SILVER_WALL);
        registerBlockItem("silver_column", SILVER_COLUMN);
        registerBlockItem("silver_slab", SILVER_SLAB);
        registerBlockItem("silver_stairs", SILVER_STAIRS);
        registerBlockItem("ginkgo_planks", GINKGO_PLANKS);
        registerBlockItem("ginkgo_stairs", GINKGO_STAIRS);
        registerBlockItem("ginkgo_slab", GINKGO_SLAB);
        registerBlockItem("ginkgo_trapdoor", GINKGO_TRAPDOOR);
        registerBlockItem("ginkgo_button", GINKGO_BUTTON);
        registerBlockItem("stripped_ginkgo_log", STRIPPED_GINKGO_LOG);
        registerBlockItem("vaults_stanchion", VAULTS_STANCHION_SAPLING);
        registerBlockItem("imperial_jade_block", IMPERIAL_JADE_BLOCK);
        registerBlockItem("imperial_jade_lantern", IMPERIAL_JADE_LANTERN);
        registerBlockItem("veins", VEINS);
        registerBlockItem("chanterelle", CHANTERELLE);
        registerBlockItem("redstone_lantern", REDSTONE_LANTERN);
        registerBlockItem("redstone_chain", REDSTONE_CHAIN);
        registerBlockItem("pile_of_meat", PILE_OF_MEAT);
    } //to load into game

}
