package mia.the_tower.initialisation.block;

import mia.the_tower.initialisation.fluid.FluidLogging;
import net.minecraft.class_10225;
import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2399;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3610;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

public class FluidloggableLadderBlock extends class_2399 implements ModFluidLoggable {
    public FluidloggableLadderBlock(class_2251 settings) {
        super(settings);
        this.method_9590(FluidLogging.withDefaultFluid(this.method_9564()));
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return FluidLogging.withPlacementFluid(super.method_9605(ctx), ctx);
    }

    @Override
    protected class_2680 method_9559(
            class_2680 state,
            class_4538 world,
            class_10225 tickView,
            class_2338 pos,
            class_2350 direction,
            class_2338 neighborPos,
            class_2680 neighborState,
            class_5819 random
    ) {
        FluidLogging.scheduleFluidTick(state, tickView, world, pos);
        return super.method_9559(state, world, tickView, pos, direction, neighborPos, neighborState, random);
    }

    @Override
    protected class_3610 method_9545(class_2680 state) {
        return FluidLogging.getFluidState(state, super.method_9545(state));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        FluidLogging.appendProperty(builder);
    }
}
