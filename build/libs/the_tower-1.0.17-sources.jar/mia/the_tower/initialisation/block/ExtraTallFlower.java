package mia.the_tower.initialisation.block;

import com.mojang.serialization.MapCodec;
import mia.the_tower.initialisation.entity.ModEntities;
import mia.the_tower.initialisation.entity.custom.LampFlyEntity;
import net.minecraft.block.*;
import net.minecraft.class_10225;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2261;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2754;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3730;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_6088;
import org.jetbrains.annotations.Nullable;

public class ExtraTallFlower extends class_2261 {
    public static final class_2754<TripleBlockPart> THIRD = class_2754.method_11850("third", TripleBlockPart.class);

    public static final MapCodec<ExtraTallFlower> CODEC = method_54094(ExtraTallFlower::new);

    @Override
    public MapCodec<? extends ExtraTallFlower> method_53969() {
        return field_46280;
    }

    public ExtraTallFlower(class_2251 settings) {
        super(settings);
        this.method_9590(this.field_10647.method_11664().method_11657(THIRD, TripleBlockPart.LOWER));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(THIRD);
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        class_2338 pos = ctx.method_8037();
        class_1937 world = ctx.method_8045();

        if (pos.method_10264() + 2 > world.method_31600()) return null;

        if (world.method_8320(pos.method_10084()).method_26166(ctx) &&
                world.method_8320(pos.method_10086(2)).method_26166(ctx)) {
            return super.method_9605(ctx).method_11657(THIRD, TripleBlockPart.LOWER);
        }

        return null;
    }

    @Override
    public void method_9567(class_1937 world, class_2338 pos, class_2680 state, class_1309 placer, class_1799 itemStack) {
        world.method_8652(pos.method_10084(), this.method_9564().method_11657(THIRD, TripleBlockPart.MIDDLE), class_2248.field_31036);
        world.method_8652(pos.method_10086(2), this.method_9564().method_11657(THIRD, TripleBlockPart.UPPER), class_2248.field_31036);
    }

    @Override
    public class_2680 method_9576(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
        if (!world.field_9236) {
            if (player.method_7337()) {
                // Prevent drops and cleanly remove the whole stack like vanilla
                onBreakInCreative(world, pos, state, player);
            } else {
                // Your existing survival behavior (break the other parts with drops)
                TripleBlockPart third = state.method_11654(THIRD);
                if (third == TripleBlockPart.UPPER) {
                    world.method_22352(pos.method_10074(), true);
                    world.method_22352(pos.method_10087(2), true);
                } else if (third == TripleBlockPart.MIDDLE) {
                    world.method_22352(pos.method_10074(), true);
                    world.method_22352(pos.method_10084(),   true);
                } else {
                    world.method_22352(pos.method_10084(),   true);
                    world.method_22352(pos.method_10086(2),  true);
                }
            }
        }
        return super.method_9576(world, pos, state, player);
    }


    private static void onBreakInCreative(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
        TripleBlockPart part = state.method_11654(THIRD);

        // Resolve the full stack origin (lower/middle/upper -> lower)
        class_2338 lower = switch (part) {
            case LOWER -> pos;
            case MIDDLE -> pos.method_10074();
            case UPPER -> pos.method_10087(2);
        };
        class_2338 middle = lower.method_10084();
        class_2338 upper  = lower.method_10086(2);

        // Clear each section without drops and with a break animation
        clearNoDrop(world, lower,  player);
        clearNoDrop(world, middle, player);
        clearNoDrop(world, upper,  player);
    }

    private static void clearNoDrop(class_1937 world, class_2338 p, class_1657 player) {
        class_2680 s = world.method_8320(p);
        if (s.method_26204() instanceof ExtraTallFlower) {
            world.method_8652(p, class_2246.field_10124.method_9564(), class_2248.field_31036 | class_2248.field_31032);
            world.method_8444(player, class_6088.field_31144, p, class_2248.method_9507(s));
        }
    }


    @Override
    protected boolean method_9558(class_2680 state, class_4538 world, class_2338 pos) {
        TripleBlockPart third = state.method_11654(THIRD);
        switch (third) {
            case LOWER:
                return super.method_9558(state, world, pos);
            case MIDDLE:
                return world.method_8320(pos.method_10074()).method_27852(this) &&
                        world.method_8320(pos.method_10074()).method_11654(THIRD) == TripleBlockPart.LOWER;
            case UPPER:
                return world.method_8320(pos.method_10074()).method_27852(this) &&
                        world.method_8320(pos.method_10074()).method_11654(THIRD) == TripleBlockPart.MIDDLE;
            default:
                return false;
        }
    }

    @Override //this is for when the block is placed via features, it places the top two parts itself
    public void method_9615(class_2680 state, class_1937 world, class_2338 pos, class_2680 oldState, boolean notify) {
        super.method_9615(state, world, pos, oldState, notify);
        if (world.field_9236) return;

        // Only bootstrap from the LOWER part
        if (!state.method_27852(this) || state.method_11654(THIRD) != TripleBlockPart.LOWER) return;

        // Y-bounds & simple replaceability checks (air is enough for vegetation patches)
        if (pos.method_10264() + 2 > world.method_31600()) return;
        class_2338 mid = pos.method_10084();
        class_2338 top = pos.method_10086(2);
        if (!world.method_8320(mid).method_26215() || !world.method_8320(top).method_26215()) return;

        world.method_8652(mid, this.method_9564().method_11657(THIRD, TripleBlockPart.MIDDLE), class_2248.field_31036);
        world.method_8652(top, this.method_9564().method_11657(THIRD, TripleBlockPart.UPPER),  class_2248.field_31036);
    }

    @Override
    protected class_2680 method_9559(class_2680 state, class_4538 world, class_10225 tickView,
                                                   class_2338 pos, class_2350 dir, class_2338 neighborPos,
                                                   class_2680 neighborState, class_5819 random) {
        TripleBlockPart third = state.method_11654(THIRD);
        boolean valid = switch (third) {
            case LOWER -> world.method_8320(pos.method_10084()).method_27852(this) &&
                    world.method_8320(pos.method_10084()).method_11654(THIRD) == TripleBlockPart.MIDDLE;
            case MIDDLE -> world.method_8320(pos.method_10074()).method_27852(this) &&
                    world.method_8320(pos.method_10074()).method_11654(THIRD) == TripleBlockPart.LOWER &&
                    world.method_8320(pos.method_10084()).method_27852(this) &&
                    world.method_8320(pos.method_10084()).method_11654(THIRD) == TripleBlockPart.UPPER;
            case UPPER -> world.method_8320(pos.method_10074()).method_27852(this) &&
                    world.method_8320(pos.method_10074()).method_11654(THIRD) == TripleBlockPart.MIDDLE;
        };

        return valid ? state : class_2246.field_10124.method_9564();
    }

    @Override
    public void method_9514(class_2680 state, class_3218 world, class_2338 pos, net.minecraft.class_5819 random) {
        // 0) (ServerWorld is already server-side; no extra check needed)

        // 1) Time-slice gate: each plant tries at most once per ~12.8s (256 ticks) on average
        //    but staggered by position so they don't all align.
        if ( ((world.method_8510() + pos.method_10063()) & 0xFFL) != 0L ) return;

        // 2) Extra probabilistic gate: only 1 in 4 time-slices proceeds (~ every ~51s per plant average)
        if (random.method_43048(4) != 0) return;

        // 3) Only if a player is around (64 blocks)
        if (world.method_18459(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5, 64.0, false) == null)
            return;

        // 4) Local density cap: if enough LAMP_FLY are already near, skip
        //    Keep the box modest (<=32) to avoid scanning lots of entities.
        final double radius = 32.0;
        int nearby = world.method_18023(ModEntities.LAMP_FLY,
                new class_238(pos).method_1014(radius),
                e -> true).size();
        if (nearby >= 6) return; // tune this cap

        // 5) Try a few candidate spots slightly above/around the plant
        for (int tries = 0; tries < 3; tries++) {
            int dx = random.method_39332(-3, 3);
            int dz = random.method_39332(-3, 3);
            int dy = 1 + random.method_39332(0, 3);

            class_2338 p = pos.method_10069(dx, dy, dz);

            // Make sure we’re in air with headroom
            if (!world.method_22347(p) || !world.method_22347(p.method_10084())) continue;

            // Optional: keep it above the local ground a bit
            int groundY = world.method_8624(class_2902.class_2903.field_13203, p.method_10263(), p.method_10260());
            if (p.method_10264() < groundY + 2) continue;

            // 6) Create and place the entity
            LampFlyEntity fly = ModEntities.LAMP_FLY.method_5883(world, class_3730.field_16459);
            if (fly == null) return;

            fly.method_5808(p.method_10263() + 0.5, p.method_10264() + 0.5, p.method_10260() + 0.5, random.method_43057() * 360f, 0f);
            // Small upward nudge so FlightMoveControl takes over smoothly (if you use it)
            fly.method_18799(fly.method_18798().method_1031(0.0, 0.08, 0.0));

            // Don’t spawn if colliding (leaves/caves etc.)
            if (!world.method_17892(fly)) continue;

            world.method_8649(fly);
            break; // only one per tick per plant
        }
    }

}