package mia.the_tower.initialisation.block;

import mia.the_tower.initialisation.fluid.FluidLogging;
import net.minecraft.class_10225;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_3610;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

public class LaunchBlock extends class_2248 implements ModFluidLoggable {

    public LaunchBlock(class_2251 settings) {
        super(settings);
        method_9590(FluidLogging.withDefaultFluid(method_9564()
                .method_11657(NORTH, false)
                .method_11657(EAST, false)
                .method_11657(SOUTH, false)
                .method_11657(WEST, false)));
    }

    @Override
    public void method_9548(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity) {
        if (!world.field_9236) {
            class_243 velocity = entity.method_18798();
            entity.method_18800(velocity.field_1352, velocity.field_1351+1.3, velocity.field_1350);
            entity.field_6037 = true;

        }
    }

    //for connected textures
    public static final class_2746 NORTH = class_2746.method_11825("north");
    public static final class_2746 EAST = class_2746.method_11825("east");
    public static final class_2746 SOUTH = class_2746.method_11825("south");
    public static final class_2746 WEST = class_2746.method_11825("west");

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(NORTH, EAST, SOUTH, WEST);
        FluidLogging.appendProperty(builder);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx) {
        class_1936 world = ctx.method_8045();
        class_2338 pos = ctx.method_8037();

        return FluidLogging.withPlacementFluid(this.method_9564()
                .method_11657(NORTH, connectsTo(world, pos.method_10095()))
                .method_11657(EAST,  connectsTo(world, pos.method_10078()))
                .method_11657(SOUTH, connectsTo(world, pos.method_10072()))
                .method_11657(WEST,  connectsTo(world, pos.method_10067())), ctx);
    }

    @Override
    protected class_2680 method_9559(
            class_2680 state,
            class_4538 world,
            class_10225 tickView,
            class_2338 pos,
            class_2350 direction,
            class_2338 neighborPos,
            class_2680 neighborState,
            class_5819 random
    ) {
        FluidLogging.scheduleFluidTick(state, tickView, world, pos);
        return super.method_9559(state, world, tickView, pos, direction, neighborPos, neighborState, random);
    }

    @Override
    protected class_3610 method_9545(class_2680 state) {
        return FluidLogging.getFluidState(state, super.method_9545(state));
    }

    @Override
    public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
        if (state.method_26204() != newState.method_26204()) {
            updateNeighbors(world, pos);
        }
        super.method_9536(state, world, pos, newState, moved);
    }

    @Override
    public void method_9567(class_1937 world, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 itemStack) {
        updateNeighbors(world, pos);
    }

    private boolean connectsTo(class_1936 world, class_2338 pos) {
        return world.method_8320(pos).method_26204() == this;
    }

    private void updateNeighbors(class_1937 world, class_2338 pos) {
        for (class_2350 dir : class_2350.class_2353.field_11062) {
            class_2338 neighborPos = pos.method_10093(dir);
            class_2680 neighborState = world.method_8320(neighborPos);
            if (neighborState.method_26204() == this) {
                world.method_8652(neighborPos, getUpdatedState(world, neighborPos), class_2248.field_31036);
            }
        }
    }

    private class_2680 getUpdatedState(class_1936 world, class_2338 pos) {
        class_2680 currentState = world.method_8320(pos);
        class_2680 state = currentState.method_27852(this) ? currentState : this.method_9564();
        return state
                .method_11657(NORTH, connectsTo(world, pos.method_10095()))
                .method_11657(EAST,  connectsTo(world, pos.method_10078()))
                .method_11657(SOUTH, connectsTo(world, pos.method_10072()))
                .method_11657(WEST,  connectsTo(world, pos.method_10067()));
    }

}
