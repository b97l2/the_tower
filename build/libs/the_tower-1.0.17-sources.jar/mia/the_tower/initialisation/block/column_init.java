package mia.the_tower.initialisation.block;

import mia.the_tower.initialisation.fluid.FluidLogging;
import net.minecraft.block.*;
import net.minecraft.class_10225;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2465;
import net.minecraft.class_2498;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_5819;
import net.minecraft.class_7924;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

import static mia.the_tower.initialisation.block_init.registerBlock;
import static mia.the_tower.initialisation.block_init.registerBlockItem;

public class column_init extends class_2465 implements ModFluidLoggable {

    public column_init(class_2251 settings) {
        super(settings);
        this.method_9590(FluidLogging.withDefaultFluid(this.method_9564()));
    }

    public static class_2248 STONE_COLUMN = registerBlock("stone_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_9626(class_2498.field_11544)
                    .method_9629(1.5F, 8.0F)
                    .method_29292()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "stone_column")))));

    public static class_2248 COBBLESTONE_COLUMN = registerBlock("cobblestone_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_9626(class_2498.field_11544)
                    .method_9629(1.5F, 8.0F)
                    .method_29292()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "cobblestone_column")))));

    public static class_2248 SMOOTH_STONE_COLUMN = registerBlock("smooth_stone_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_9626(class_2498.field_11544)
                    .method_9629(1.5F, 8.0F)
                    .method_29292()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "smooth_stone_column")))));

    public static class_2248 STONE_BRICK_COLUMN = registerBlock("stone_brick_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_9626(class_2498.field_11544)
                    .method_9629(1.5F, 8.0F)
                    .method_29292()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "stone_brick_column")))));

    public static class_2248 BLACKSTONE_COLUMN = registerBlock("blackstone_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_9626(class_2498.field_11544)
                    .method_9629(1.5F, 8.0F)
                    .method_29292()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "blackstone_column")))));

    public static class_2248 POLISHED_BLACKSTONE_COLUMN = registerBlock("polished_blackstone_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_9626(class_2498.field_11544)
                    .method_9629(1.5F, 8.0F)
                    .method_29292()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "polished_blackstone_column")))));

    public static class_2248 POLISHED_BLACKSTONE_BRICK_COLUMN = registerBlock("polished_blackstone_brick_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_9626(class_2498.field_11544)
                    .method_9629(1.5F, 8.0F)
                    .method_29292()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "polished_blackstone_brick_column")))));

    public static class_2248 COBBLED_DEEPSLATE_COLUMN = registerBlock("cobbled_deepslate_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_9626(class_2498.field_11544)
                    .method_9629(1.5F, 8.0F)
                    .method_29292()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "cobbled_deepslate_column")))));

    public static class_2248 POLISHED_DEEPSLATE_COLUMN = registerBlock("polished_deepslate_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_9626(class_2498.field_11544)
                    .method_9629(1.5F, 8.0F)
                    .method_29292()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "polished_deepslate_column")))));

    public static class_2248 DEEPSLATE_BRICK_COLUMN = registerBlock("deepslate_brick_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_9626(class_2498.field_11544)
                    .method_9629(1.5F, 8.0F)
                    .method_29292()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "deepslate_brick_column")))));

    public static class_2248 DEEPSLATE_TILE_COLUMN = registerBlock("deepslate_tile_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_9626(class_2498.field_11544)
                    .method_9629(1.5F, 8.0F)
                    .method_29292()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "deepslate_tile_column")))));


    @Override
    public class_265 method_9530(class_2680 state, class_1922 view, class_2338 pos, class_3726 context) {
        class_2350.class_2351 axis = state.method_11654(field_11459);
        switch (axis) {
            case field_11048:
                return class_259.method_1081(0.0F, 0.25F, 0.25F, 1.0F, 0.75F, 0.75F);
            case field_11052:
                return class_259.method_1081(0.25F, 0.0F, 0.25F, 0.75F, 1.0F, 0.75F);
            case field_11051:
            default:
                return class_259.method_1081(0.25F, 0.25F, 0.0F, 0.75F, 0.75F, 1.0F);
        }

    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return FluidLogging.withPlacementFluid(super.method_9605(ctx), ctx);
    }

    @Override
    protected class_2680 method_9559(
            class_2680 state,
            class_4538 world,
            class_10225 tickView,
            class_2338 pos,
            class_2350 direction,
            class_2338 neighborPos,
            class_2680 neighborState,
            class_5819 random
    ) {
        FluidLogging.scheduleFluidTick(state, tickView, world, pos);

        return super.method_9559(state, world, tickView, pos, direction, neighborPos, neighborState, random);
    }

    @Override
    protected class_3610 method_9545(class_2680 state) {
        return FluidLogging.getFluidState(state, super.method_9545(state));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        FluidLogging.appendProperty(builder);
    }

    @Override
    public boolean method_10310(@Nullable class_1657 player, class_1922 world, class_2338 pos, class_2680 state, class_3611 fluid) {
        return ModFluidLoggable.super.method_10310(player, world, pos, state, fluid);
    }

    @Override
    public boolean method_10311(class_1936 world, class_2338 pos, class_2680 state, class_3610 fluidState) {
        return ModFluidLoggable.super.method_10311(world, pos, state, fluidState);
    }

    @Override
    public class_1799 method_9700(@Nullable class_1657 player, class_1936 world, class_2338 pos, class_2680 state) {
        return ModFluidLoggable.super.method_9700(player, world, pos, state);
    }

    @Override
    public Optional<class_3414> method_32351() {
        return ModFluidLoggable.super.method_32351();
    }

    public static void load() {
        registerBlockItem("stone_column",STONE_COLUMN);
        registerBlockItem("cobblestone_column",COBBLESTONE_COLUMN);
        registerBlockItem("smooth_stone_column",SMOOTH_STONE_COLUMN);
        registerBlockItem("stone_brick_column",STONE_BRICK_COLUMN);
        registerBlockItem("blackstone_column",BLACKSTONE_COLUMN);
        registerBlockItem("polished_blackstone_column",POLISHED_BLACKSTONE_COLUMN);
        registerBlockItem("polished_blackstone_brick_column",POLISHED_BLACKSTONE_BRICK_COLUMN);
        registerBlockItem("cobbled_deepslate_column",COBBLED_DEEPSLATE_COLUMN);
        registerBlockItem("polished_deepslate_column",POLISHED_DEEPSLATE_COLUMN);
        registerBlockItem("deepslate_brick_column",DEEPSLATE_BRICK_COLUMN);
        registerBlockItem("deepslate_tile_column",DEEPSLATE_TILE_COLUMN);
    } //to load into game

}
