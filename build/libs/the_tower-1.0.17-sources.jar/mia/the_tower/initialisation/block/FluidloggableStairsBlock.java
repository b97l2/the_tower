package mia.the_tower.initialisation.block;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import mia.the_tower.initialisation.fluid.FluidLogging;
import net.minecraft.class_10225;
import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2510;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3610;
import net.minecraft.class_4538;
import net.minecraft.class_4970;
import net.minecraft.class_5819;

public class FluidloggableStairsBlock extends class_2510 implements ModFluidLoggable {
    public static final MapCodec<FluidloggableStairsBlock> CODEC = RecordCodecBuilder.mapCodec(
            instance -> instance.group(class_2680.field_24734.fieldOf("base_state").forGetter(block -> block.field_11574), method_54096())
                    .apply(instance, FluidloggableStairsBlock::new)
    );

    public FluidloggableStairsBlock(class_2680 baseBlockState, class_4970.class_2251 settings) {
        super(baseBlockState, settings);
        this.method_9590(FluidLogging.withDefaultFluid(this.method_9564()));
    }

    @Override
    public MapCodec<? extends class_2510> method_53969() {
        return field_46280;
    }

    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return FluidLogging.withPlacementFluid(super.method_9605(ctx), ctx);
    }

    @Override
    protected class_2680 method_9559(
            class_2680 state,
            class_4538 world,
            class_10225 tickView,
            class_2338 pos,
            class_2350 direction,
            class_2338 neighborPos,
            class_2680 neighborState,
            class_5819 random
    ) {
        FluidLogging.scheduleFluidTick(state, tickView, world, pos);
        return super.method_9559(state, world, tickView, pos, direction, neighborPos, neighborState, random);
    }

    @Override
    protected class_3610 method_9545(class_2680 state) {
        return FluidLogging.getFluidState(state, super.method_9545(state));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        FluidLogging.appendProperty(builder);
    }
}
