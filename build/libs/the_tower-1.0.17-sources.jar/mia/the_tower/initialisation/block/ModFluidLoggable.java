package mia.the_tower.initialisation.block;

import mia.the_tower.initialisation.fluid.FluidLogging;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3414;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3737;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

public interface ModFluidLoggable extends class_3737 {
    @Override
    default boolean method_10310(@Nullable class_1657 player, class_1922 world, class_2338 pos, class_2680 state, class_3611 fluid) {
        return FluidLogging.canFillWithFluid(player, world, pos, state, fluid);
    }

    @Override
    default boolean method_10311(class_1936 world, class_2338 pos, class_2680 state, class_3610 fluidState) {
        return FluidLogging.tryFillWithFluid(world, pos, state, fluidState);
    }

    @Override
    default class_1799 method_9700(@Nullable class_1657 player, class_1936 world, class_2338 pos, class_2680 state) {
        return FluidLogging.tryDrainFluid(world, pos, state);
    }

    @Override
    default Optional<class_3414> method_32351() {
        return FluidLogging.getBucketFillSound();
    }
}
