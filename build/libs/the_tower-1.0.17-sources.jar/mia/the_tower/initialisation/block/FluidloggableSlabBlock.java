package mia.the_tower.initialisation.block;

import com.mojang.serialization.MapCodec;
import mia.the_tower.initialisation.fluid.FluidLogging;
import net.minecraft.class_10225;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2482;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2771;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_4538;
import net.minecraft.class_4970;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

public class FluidloggableSlabBlock extends class_2482 implements ModFluidLoggable {
    public static final MapCodec<FluidloggableSlabBlock> CODEC = method_54094(FluidloggableSlabBlock::new);

    public FluidloggableSlabBlock(class_4970.class_2251 settings) {
        super(settings);
        this.method_9590(FluidLogging.withDefaultFluid(this.method_9564()));
    }

    @Override
    public MapCodec<? extends class_2482> method_53969() {
        return field_46445;
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        class_2680 state = super.method_9605(ctx);
        if (state == null) {
            return null;
        }
        if (state.method_11654(field_11501) == class_2771.field_12682) {
            return FluidLogging.withSlot(state, FluidLogging.Slot.NONE);
        }
        return FluidLogging.withPlacementFluid(state, ctx);
    }

    @Override
    public boolean method_10310(@Nullable class_1657 player, class_1922 world, class_2338 pos, class_2680 state, class_3611 fluid) {
        return state.method_11654(field_11501) != class_2771.field_12682 && ModFluidLoggable.super.method_10310(player, world, pos, state, fluid);
    }

    @Override
    public boolean method_10311(class_1936 world, class_2338 pos, class_2680 state, class_3610 fluidState) {
        return state.method_11654(field_11501) != class_2771.field_12682 && ModFluidLoggable.super.method_10311(world, pos, state, fluidState);
    }

    @Override
    protected class_2680 method_9559(
            class_2680 state,
            class_4538 world,
            class_10225 tickView,
            class_2338 pos,
            class_2350 direction,
            class_2338 neighborPos,
            class_2680 neighborState,
            class_5819 random
    ) {
        FluidLogging.scheduleFluidTick(state, tickView, world, pos);
        return super.method_9559(state, world, tickView, pos, direction, neighborPos, neighborState, random);
    }

    @Override
    protected class_3610 method_9545(class_2680 state) {
        return FluidLogging.getFluidState(state, super.method_9545(state));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        super.method_9515(builder);
        FluidLogging.appendProperty(builder);
    }
}
