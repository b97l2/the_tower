package mia.the_tower.initialisation.block;

import com.mojang.serialization.MapCodec;
import mia.the_tower.initialisation.fluid.FluidLogging;
import net.minecraft.class_10225;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3610;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

public class SauerkrautBlock extends class_2383 implements ModFluidLoggable {

    public static final MapCodec<SauerkrautBlock> CODEC = method_54094(SauerkrautBlock::new);

    public SauerkrautBlock(class_2251 settings) {
        super(settings);
        this.method_9590(FluidLogging.withDefaultFluid(this.method_9564().method_11657(field_11177, class_2350.field_11043)));
    }

    @Override
    protected MapCodec<? extends class_2383> method_53969() {
        return field_46280;
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return FluidLogging.withPlacementFluid(
                this.method_9564().method_11657(field_11177, ctx.method_8042().method_10153()),
                ctx
        );
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11177);
        FluidLogging.appendProperty(builder);
    }

    @Override
    protected class_2680 method_9559(
            class_2680 state,
            class_4538 world,
            class_10225 tickView,
            class_2338 pos,
            class_2350 direction,
            class_2338 neighborPos,
            class_2680 neighborState,
            class_5819 random
    ) {
        FluidLogging.scheduleFluidTick(state, tickView, world, pos);
        return super.method_9559(state, world, tickView, pos, direction, neighborPos, neighborState, random);
    }

    @Override
    protected class_3610 method_9545(class_2680 state) {
        return FluidLogging.getFluidState(state, super.method_9545(state));
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 view, class_2338 pos, class_3726 context) {
                return class_259.method_1081(0.375F, 0F, 0.375F, 0.625F, 0.406F, 0.625F);
    }
}
