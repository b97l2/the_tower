package mia.the_tower.initialisation.items;

import mia.the_tower.initialisation.entity.custom.PlateEntity;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_5712;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

public class PlateItem extends class_1792 {
    public PlateItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_2350 direction = context.method_8038();
        if (direction != class_2350.field_11036) {
            return class_1269.field_5814;
        }

        class_1657 player = context.method_8036();
        class_1799 stack = context.method_8041();
        class_2338 platePos = context.method_8037().method_10093(direction);
        class_1937 world = context.method_8045();
        if (world.method_31606(platePos) || player != null && !player.method_7343(platePos, direction, stack)) {
            return class_1269.field_5814;
        }

        PlateEntity plate = new PlateEntity(world, platePos, class_2350.field_11036);
        class_9279 nbtComponent = stack.method_57825(class_9334.field_49609, class_9279.field_49302);
        if (!nbtComponent.method_57458()) {
            class_1299.method_5881(world, player, plate, nbtComponent);
        }

        if (!plate.method_6888()) {
            return class_1269.field_21466;
        }

        if (!world.field_9236) {
            plate.method_6894();
            world.method_43275(player, class_5712.field_28738, plate.method_19538());
            world.method_8649(plate);
        }

        stack.method_7934(1);
        return class_1269.field_5812;
    }
}
