package mia.the_tower.initialisation.items;

import mia.the_tower.initialisation.fluid.FluidLogging;
import net.minecraft.class_1657;
import net.minecraft.class_1755;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2402;
import net.minecraft.class_2680;
import net.minecraft.class_3609;
import net.minecraft.class_3611;
import net.minecraft.class_3965;
import org.jetbrains.annotations.Nullable;

public class FluidloggingBucketItem extends class_1755 {
    private final class_3611 fluid;

    public FluidloggingBucketItem(class_3611 fluid, class_1793 settings) {
        super(fluid, settings);
        this.fluid = fluid;
    }

    @Override
    public boolean method_7731(@Nullable class_1657 player, class_1937 world, class_2338 pos, @Nullable class_3965 hitResult) {
        if (this.fluid instanceof class_3609 flowableFluid) {
            if (this.tryFluidlog(player, world, pos, flowableFluid)) {
                return true;
            }

            if (hitResult != null) {
                class_2338 clickedPos = hitResult.method_17777();
                if (!clickedPos.equals(pos) && this.tryFluidlog(player, world, clickedPos, flowableFluid)) {
                    return true;
                }

                if (clickedPos.equals(pos) && FluidLogging.getSlot(this.fluid) != FluidLogging.Slot.NONE) {
                    class_2680 clickedState = world.method_8320(clickedPos);
                    if (clickedState.method_26204() instanceof class_2402) {
                        return false;
                    }
                }
            }
        }

        return super.method_7731(player, world, pos, hitResult);
    }

    private boolean tryFluidlog(@Nullable class_1657 player, class_1937 world, class_2338 pos, class_3609 flowableFluid) {
        class_2680 state = world.method_8320(pos);
        if (state.method_26204() instanceof class_2402 fluidFillable
                && fluidFillable.method_10310(player, world, pos, state, this.fluid)
                && fluidFillable.method_10311(world, pos, state, flowableFluid.method_15729(false))) {
            this.method_7727(player, world, pos);
            return true;
        }

        return false;
    }
}
