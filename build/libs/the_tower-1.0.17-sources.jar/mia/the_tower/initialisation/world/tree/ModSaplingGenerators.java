package mia.the_tower.initialisation.world.tree;

import mia.the_tower.The_Tower;
import mia.the_tower.initialisation.world.ModConfiguredFeatures;
import net.minecraft.class_8813;
import java.util.Optional;

public class ModSaplingGenerators {
    public static final class_8813 GINKGO = new class_8813(The_Tower.MOD_ID + ":ginkgo",
            Optional.empty(), Optional.of(ModConfiguredFeatures.GINKGO_KEY), Optional.empty());

    public static final class_8813 VAULTS_STANCHION = new class_8813(The_Tower.MOD_ID + ":vaults_stanchion",
            Optional.empty(), Optional.of(ModConfiguredFeatures.VAULTS_STANCHION_KEY), Optional.empty());
}
