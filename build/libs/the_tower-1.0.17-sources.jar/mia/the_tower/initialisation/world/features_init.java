package mia.the_tower.initialisation.world;

import mia.the_tower.initialisation.world.misc.DecoratedPitPlacer;

public class features_init {
//    //for registering my custom features
//
//
//    public static final RegistryKey<Feature<?>> DECORATED_PIT_KEY =
//            RegistryKey.of(RegistryKeys.FEATURE, Identifier.of("the_tower", "decorated_pit"));
//
//    public static final Feature<DecoratedPitPlacer.Config> DECORATED_PIT = new DecoratedPitPlacer();
//
//    // Called by your RegistryBuilder / bootstrap wiring
//    public static void bootstrap(Registerable<Feature<?>> ctx) {
//        ctx.register(DECORATED_PIT_KEY, DECORATED_PIT);
//    }

   public static void load() {}

}
