package mia.the_tower.initialisation.world.ore;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2680;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_3124;
import net.minecraft.class_5281;
import net.minecraft.class_5819;
import net.minecraft.class_5821;
import net.minecraft.class_6017;
import net.minecraft.class_7923;

import static mia.the_tower.The_Tower.id;

public class SheetOreFeature extends class_3031<SheetOreFeature.Config> {
    public static record Config(
            List<class_3124.class_5876> targets,
            class_6017 width,
            class_6017 height,
            float density,
            float discardOnAirChance
    ) implements class_3037 {
        public static final Codec<Config> CODEC = RecordCodecBuilder.create(instance ->
                instance.group(
                        Codec.list(class_3124.class_5876.field_29067)
                                .fieldOf("targets")
                                .forGetter(Config::targets),
                        class_6017.method_35004(1, 128)
                                .fieldOf("width")
                                .forGetter(Config::width),
                        class_6017.method_35004(1, 16)
                                .fieldOf("height")
                                .forGetter(Config::height),
                        Codec.floatRange(0.0F, 1.0F)
                                .optionalFieldOf("density", 0.9F)
                                .forGetter(Config::density),
                        Codec.floatRange(0.0F, 1.0F)
                                .optionalFieldOf("discard_chance_on_air_exposure", 0.0F)
                                .forGetter(Config::discardOnAirChance)
                ).apply(instance, Config::new)
        );
    }

    public static final class_3031<Config> SHEET_ORE =
            class_2378.method_10230(class_7923.field_41144, id("sheet_ore"), new SheetOreFeature());

    public SheetOreFeature() {
        super(Config.CODEC);
    }

    public static void init() {}

    @Override
    public boolean method_13151(class_5821<Config> context) {
        Config config = context.method_33656();
        class_5281 world = context.method_33652();
        class_5819 random = context.method_33654();
        class_2338 origin = context.method_33655();

        int width = config.width().method_35008(random);
        int height = config.height().method_35008(random);
        if (width <= 0 || height <= 0 || config.targets().isEmpty()) {
            return false;
        }

        int xRadius = Math.max(1, width / 2 + random.method_39332(-Math.max(1, width / 8), Math.max(1, width / 8)));
        int zRadius = Math.max(1, width / 2 + random.method_39332(-Math.max(1, width / 8), Math.max(1, width / 8)));
        int baseY = origin.method_10264() - height / 2;
        int layerRadiusFuzz = Math.max(1, width / 10);
        int layerDrift = Math.max(1, width / 12);
        int placed = 0;

        class_2338.class_2339 mutable = new class_2338.class_2339();
        for (int dy = 0; dy < height; dy++) {
            int y = baseY + dy;
            if (world.method_31601(y)) {
                continue;
            }

            int layerXRadius = Math.max(1, xRadius + random.method_39332(-layerRadiusFuzz, layerRadiusFuzz));
            int layerZRadius = Math.max(1, zRadius + random.method_39332(-layerRadiusFuzz, layerRadiusFuzz));
            int layerX = origin.method_10263() + random.method_39332(-layerDrift, layerDrift);
            int layerZ = origin.method_10260() + random.method_39332(-layerDrift, layerDrift);

            for (int dx = -layerXRadius; dx <= layerXRadius; dx++) {
                double normalizedX = (double) dx / (double) layerXRadius;

                for (int dz = -layerZRadius; dz <= layerZRadius; dz++) {
                    double normalizedZ = (double) dz / (double) layerZRadius;
                    double distance = normalizedX * normalizedX + normalizedZ * normalizedZ;
                    if (distance > 1.0D) {
                        continue;
                    }

                    mutable.method_10103(layerX + dx, y, layerZ + dz);
                    if (!world.method_37368(mutable)) {
                        continue;
                    }

                    class_2680 currentState = world.method_8320(mutable);
                    for (class_3124.class_5876 target : config.targets()) {
                        if (shouldPlace(currentState, world, random, config, target, mutable)) {
                            world.method_8652(mutable, target.field_29069, class_2248.field_31028);
                            placed++;
                            break;
                        }
                    }
                }
            }
        }

        return placed > 0;
    }

    private static boolean shouldPlace(class_2680 state, class_5281 world, class_5819 random, Config config,
                                       class_3124.class_5876 target, class_2338.class_2339 pos) {
        if (!target.field_29068.method_16768(state, random)) {
            return false;
        }

        if (config.discardOnAirChance() <= 0.0F || random.method_43057() >= config.discardOnAirChance()) {
            return true;
        }

        return !class_3031.method_33981(world::method_8320, pos);
    }
}
