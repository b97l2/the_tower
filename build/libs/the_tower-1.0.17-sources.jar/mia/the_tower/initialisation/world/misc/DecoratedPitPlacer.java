package mia.the_tower.initialisation.world.misc;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import mia.the_tower.initialisation.world.tree.GiantFoliagePlacer;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2680;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_3532;
import net.minecraft.class_4651;
import net.minecraft.class_5281;
import net.minecraft.class_5819;
import net.minecraft.class_5821;
import net.minecraft.class_6017;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;

import static mia.the_tower.The_Tower.id;


public class DecoratedPitPlacer extends class_3031<DecoratedPitPlacer.Config> {

    public static record Config(
            class_6017 radius,              // radius at rim
            class_6017 depth,               // max depth at center
            class_4651 surfaceProvider  // weighted list of 3 blocks, etc.
    ) implements class_3037 {

        public static final Codec<Config> CODEC = RecordCodecBuilder.create(instance ->
                instance.group(
                        class_6017.field_33450
                                .fieldOf("radius")
                                .forGetter(Config::radius),
                        class_6017.field_33451
                                .fieldOf("depth")
                                .forGetter(Config::depth),
                        class_4651.field_24937
                                .fieldOf("surface_provider")
                                .forGetter(Config::surfaceProvider)
                ).apply(instance, Config::new)
        );
    }

    public DecoratedPitPlacer() {
        super(Config.CODEC);
    }

    public static final class_3031<DecoratedPitPlacer.Config> DECORATED_PIT =
            class_2378.method_10230(class_7923.field_41144, id("decorated_pit"), new DecoratedPitPlacer());

    public static void init() {}

    @Override
    public boolean method_13151(class_5821<Config> context) {
        Config config = context.method_33656();
        class_5281 world = context.method_33652();
        class_5819 random = context.method_33654();
        class_2338 origin = context.method_33655();


        int radius = config.radius().method_35008(random);
        int depth = config.depth().method_35008(random);

        if (radius <= 0 || depth <= 0) {
            return false;
        }

        int bottomY = world.method_31607();
        int topY = world.method_31600();
        int originY = origin.method_10264();

        if (originY <= bottomY || originY >= topY) {
            return false;
        }

        boolean changed = false;

        int originX = origin.method_10263();
        int originZ = origin.method_10260();
        double radiusSq = (double) radius * (double) radius;

        class_2338.class_2339 mutable = new class_2338.class_2339();

        // -------------------------------------------------
        // 1. Carve a bowl-shaped paraboloid of air
        //    z = depth * (1 - (r^2 / R^2)), r^2 = dx^2 + dz^2
        // -------------------------------------------------
        for (int dx = -radius; dx <= radius; dx++) {
            int x = originX + dx;

            for (int dz = -radius; dz <= radius; dz++) {
                int z = originZ + dz;

                double distSq = (double) dx * dx + (double) dz * dz;
                if (distSq > radiusSq) {
                    continue;
                }

                // 0 at center, 1 at rim
                double normalizedRadial = distSq / radiusSq;
                double columnDepthDouble = (double) depth * (1.0 - normalizedRadial);
                int columnDepth = class_3532.method_15357(columnDepthDouble);

                if (columnDepth <= 0) {
                    continue;
                }

                // clamp so we don't go below world bottom
                int maxSteps = Math.min(columnDepth, originY - bottomY - 1);
                if (maxSteps <= 0) {
                    continue;
                }

                for (int dy = 0; dy < maxSteps; dy++) {
                    int y = originY - dy;
                    mutable.method_10103(x, y, z);

                    class_2680 state = world.method_8320(mutable);

                    // don't replace obsidian
                    if (state.method_27852(class_2246.field_10540)) {
                        continue;
                    }

                    if (!state.method_26215()) {
                        changed = true;
                    }

                    world.method_8652(mutable, class_2246.field_10124.method_9564(), class_2248.field_31028);
                }
            }
        }

        // -------------------------------------------------
        // 2. Decorate inside floor surface
        //    "Inside surface" = blocks with air directly above them,
        //    within the paraboloid footprint.
        // -------------------------------------------------
        class_4651 surfaceProvider = config.surfaceProvider();
        int minY = Math.max(bottomY + 1, originY - depth - 1);

        for (int dx = -radius; dx <= radius; dx++) {
            int x = originX + dx;

            for (int dz = -radius; dz <= radius; dz++) {
                int z = originZ + dz;

                double distSq = (double) dx * dx + (double) dz * dz;
                if (distSq > radiusSq) {
                    continue;
                }

                // Only columns that actually had some depth carved
                double normalizedRadial = distSq / radiusSq;
                double columnDepthDouble = (double) depth * (1.0 - normalizedRadial);
                int columnDepth = class_3532.method_15357(columnDepthDouble);
                if (columnDepth <= 0) {
                    continue;
                }

                int y = originY;
                mutable.method_10103(x, y, z);

                // walk down through the air we carved until we hit solid
                while (y > minY && world.method_8320(mutable).method_26215()) {
                    y--;
                    mutable.method_33098(y);
                }

                class_2680 floorState = world.method_8320(mutable);
                if (y <= minY) {
                    continue;
                }

                // skip if we didn't hit solid, or it's obsidian,
                // or it no longer has air above (not an interior floor).
                if (floorState.method_26215() || floorState.method_27852(class_2246.field_10540)) {
                    continue;
                }

                if (!world.method_8320(mutable.method_10084()).method_26215()) {
                    continue;
                }

                class_2680 decoration = surfaceProvider.method_23455(random, mutable);
                world.method_8652(mutable, decoration, class_2248.field_31028);
                changed = true;
            }
        }

        return changed;
    }

}
