package mia.the_tower.initialisation.world;

import mia.the_tower.initialisation.block_init;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_5321;
import net.minecraft.class_5450;
import net.minecraft.class_5843;
import net.minecraft.class_5925;
import net.minecraft.class_6019;
import net.minecraft.class_6732;
import net.minecraft.class_6792;
import net.minecraft.class_6793;
import net.minecraft.class_6795;
import net.minecraft.class_6796;
import net.minecraft.class_6797;
import net.minecraft.class_6799;
import net.minecraft.class_6817;
import net.minecraft.class_6819;
import net.minecraft.class_6880;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.world.gen.feature.*;
import net.minecraft.world.gen.placementmodifier.*;

import java.util.List;
//relevant mc files to look at: VegetationPlacedFeatures
public class ModPlacedFeatures {

    //features need a line here

    //ore
    public static final class_5321<class_6796> AFHD_PLACED_KEY = registerKey("afhd_placed");
    public static final class_5321<class_6796> DRAGONS_EYE_ORE_PLACED_KEY = registerKey("dragons_eye_ore_placed");
    public static final class_5321<class_6796> ITORE_PLACED_KEY = registerKey("itore_placed");
    public static final class_5321<class_6796> KAOLIN_SHEET_ORE_PLACED_KEY = registerKey("kaolin_sheet_ore_placed");
    public static final class_5321<class_6796> SILVER_ORE_PLACED_KEY = registerKey("silver_ore_placed");
    public static final class_5321<class_6796> SLATE_SHEET_ORE_PLACED_KEY = registerKey("slate_sheet_ore_placed");
    public static final class_5321<class_6796> SILVER_VEIN_PLACED_KEY = registerKey("silver_vein_placed");

    //vegetation
    public static final class_5321<class_6796> CERULEAN_GRASS_PATCH_PLACED_KEY = registerKey("cerulean_grass_patch_placed");
    public static final class_5321<class_6796> CERULEAN_COAST_FLOWERS_PATCH_PLACED_KEY = registerKey("cerulean_coast_flowers_patch_placed");
    public static final class_5321<class_6796> PILE_OF_MEAT_PLACED_KEY = registerKey("pile_of_meat_placed");

    //tree
    public static final class_5321<class_6796> GINKGO_PLACED_KEY = registerKey("ginkgo_placed");

    //other
    public static final class_5321<class_6796> DECORATED_PIT_PLACED_KEY = registerKey("decorated_pit_placed");

    public static void bootstrap(class_7891<class_6796> context) {
        var configuredFeatures = context.method_46799(class_7924.field_41239);

        //ore
        //needs a line here
        register(context, AFHD_PLACED_KEY, configuredFeatures.method_46747(ModConfiguredFeatures.AFHD_KEY),
                ModOrePlacement.modifiersWithCount(3, //veins per chunk
                        class_6795.method_39634(class_5843.method_33841(-120), class_5843.method_33841(30)))); //first one is min y level, second is max y level
        //you can use other HeightRangePlacementModifiers as well, or make your owm.
        //uniform gives uniform distribution in between min and max y
        //trapezoid gives highest probability in the middle between the two values which decreases either side
        register(context, DRAGONS_EYE_ORE_PLACED_KEY, configuredFeatures.method_46747(ModConfiguredFeatures.DRAGONS_EYE_ORE_KEY),
                ModOrePlacement.modifiersWithCount(3, //veins per chunk
                        class_6795.method_39637(class_5843.method_33841(-200), class_5843.method_33841(-30))));
        register(context, ITORE_PLACED_KEY, configuredFeatures.method_46747(ModConfiguredFeatures.ITORE_KEY),
                ModOrePlacement.modifiersWithCount(5,
                        class_6795.method_39637(class_5843.method_33841(-140), class_5843.method_33841(60))));
        register(context, KAOLIN_SHEET_ORE_PLACED_KEY, configuredFeatures.method_46747(ModConfiguredFeatures.KAOLIN_SHEET_ORE_KEY),
                class_6799.method_39659(4),
                class_5450.method_39639(),
                class_5925.method_39638(class_2902.class_2903.field_13203),
                class_6732.method_39656(class_6019.method_35017(-7, -2)),
                class_6792.method_39614());
        register(context, SILVER_ORE_PLACED_KEY, configuredFeatures.method_46747(ModConfiguredFeatures.SILVER_ORE_KEY),
                ModOrePlacement.modifiersWithCount(5, //veins per chunk
                        class_6795.method_39637(class_5843.method_33841(-120), class_5843.method_33841(50))));
        register(context, SLATE_SHEET_ORE_PLACED_KEY, configuredFeatures.method_46747(ModConfiguredFeatures.SLATE_SHEET_ORE_KEY),
                ModOrePlacement.modifiersWithRarity(4,
                        class_6795.method_39634(class_5843.method_33841(-120), class_5843.method_33841(0))));
        register(context, SILVER_VEIN_PLACED_KEY, configuredFeatures.method_46747(ModConfiguredFeatures.SILVER_VEIN_KEY),
                ModOrePlacement.modifiersWithCount(2, //veins per chunk
                        class_6795.method_39634(class_5843.method_33841(-160), class_5843.method_33841(-60))));
        //for ore then we go to gen/ModOreGeneration

        //vegetation
        class_6817.method_40370(
                context,
                CERULEAN_GRASS_PATCH_PLACED_KEY,
                configuredFeatures.method_46747(ModConfiguredFeatures.CERULEAN_GRASS_PATCH_KEY),
                class_6793.method_39623(3),
                class_6799.method_39659(2),
                class_5450.method_39639(),
                class_6817.field_36078,
                class_6792.method_39614()
        );
        class_6817.method_40370(
                context,
                CERULEAN_COAST_FLOWERS_PATCH_PLACED_KEY,
                configuredFeatures.method_46747(ModConfiguredFeatures.CERULEAN_COAST_FLOWERS_PATCH_KEY),
                class_6793.method_39623(3),
                class_6799.method_39659(2),
                class_5450.method_39639(),
                class_6817.field_36078,
                class_6792.method_39614()
        );
        class_6817.method_40370(
                context,
                PILE_OF_MEAT_PLACED_KEY,
                configuredFeatures.method_46747(ModConfiguredFeatures.PILE_OF_MEAT_KEY),
                class_6799.method_39659(5),
                class_5450.method_39639(),
                class_6817.field_55187,
                class_6792.method_39614()
        );

        //tree
        register(context, GINKGO_PLACED_KEY, configuredFeatures.method_46747(ModConfiguredFeatures.GINKGO_KEY),
                class_6819.method_39741(
                        class_6799.method_39659(6), // ~1 attempt per 6 chunks
                        block_init.GINKGO_SAPLING));

        //other
        register(
                context,
                DECORATED_PIT_PLACED_KEY,
                configuredFeatures.method_46747(ModConfiguredFeatures.DECORATED_PIT_KEY),
                class_6799.method_39659(7),
                // spread attempts in the chunk
                class_5450.method_39639(),
                // pick the Y from the motion-blocking heightmap (surface)
                class_6817.field_36078,
                // only in allowed biomes
                class_6792.method_39614()
        );

        //for any feature then you go to the gen/ModXXXGeneration file, or create it.
        //I am not sure if this is necessary for spawning in custom biomes, or if it is only for vanilla.
        //Best include it anyways I suppose

    }
//this is the method to load a placed feature
    public static class_5321<class_6796> registerKey(String name) {
        return class_5321.method_29179(class_7924.field_41245, class_2960.method_60655("the_tower", name));
    }

    private static void register(class_7891<class_6796> context, class_5321<class_6796> key, class_6880<class_2975<?, ?>> configuration,
                                 List<class_6797> modifiers) {
        context.method_46838(key, new class_6796(configuration, List.copyOf(modifiers)));
    }

    private static <FC extends class_3037, F extends class_3031<FC>> void register(class_7891<class_6796> context, class_5321<class_6796> key,
                                                                                   class_6880<class_2975<?, ?>> configuration,
                                                                                   class_6797... modifiers) {
        register(context, key, configuration, List.of(modifiers));
    }
}
