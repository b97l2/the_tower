package mia.the_tower.initialisation.blockentity;

import com.mojang.serialization.MapCodec;
import mia.the_tower.initialisation.block.ModFluidLoggable;
import mia.the_tower.initialisation.fluid.FluidLogging;
import mia.the_tower.initialisation.blockentity.util.ColouredInventory;
import mia.the_tower.initialisation.items.KeyItem;
import net.minecraft.class_10225;
import net.minecraft.class_1264;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_3218;
import net.minecraft.class_3610;
import net.minecraft.class_3908;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5558;
import net.minecraft.class_5819;
import net.minecraft.util.*;
import java.util.List;

public class ColouredCofferBlock extends class_2237 implements ModFluidLoggable {

    private final MapCodec<ColouredCofferBlock> codec;
    public static final class_2754<class_2350> FACING = class_2741.field_12481;
    public static final class_2746 OPEN = class_2741.field_12537;

    public ColouredCofferBlock(class_1767 color, class_2251 settings) {
        super(settings);
        this.color = color;
        this.codec = class_2248.method_54094(s -> new ColouredCofferBlock(color, s));
        this.method_9590(FluidLogging.withDefaultFluid(this.field_10647.method_11664().method_11657(FACING, class_2350.field_11043).method_11657(OPEN, false)));
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return this.codec;
    }

    private final class_1767 color;

    public class_1767 getColor() {
        return color;
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new ColouredCofferBlockEntity(pos, state);
    }


    @Override
    public void method_9567(class_1937 world, class_2338 pos, class_2680 state, class_1309 placer, class_1799 stack) {
        super.method_9567(world, pos, state, placer, stack);
    }

    @Override
    protected class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    protected class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, OPEN);
        FluidLogging.appendProperty(builder);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx) {
        // If placing on a vertical face, face the player; otherwise use the clicked horizontal face.
        class_2350 dir = ctx.method_8038().method_10166().method_10179()
                ? ctx.method_8038()
                : ctx.method_8042().method_10153();
        return FluidLogging.withPlacementFluid(this.method_9564().method_11657(FACING, dir), ctx);
    }

    @Override
    protected class_2680 method_9559(
            class_2680 state,
            class_4538 world,
            class_10225 tickView,
            class_2338 pos,
            class_2350 direction,
            class_2338 neighborPos,
            class_2680 neighborState,
            class_5819 random
    ) {
        FluidLogging.scheduleFluidTick(state, tickView, world, pos);
        return super.method_9559(state, world, tickView, pos, direction, neighborPos, neighborState, random);
    }

    @Override
    protected class_3610 method_9545(class_2680 state) {
        return FluidLogging.getFluidState(state, super.method_9545(state));
    }

    @Override
    public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
        if (state.method_26204() != newState.method_26204()) {
            class_2586 be = world.method_8321(pos);
            if (!world.field_9236 && be instanceof ColouredCofferBlockEntity cofferBe) {
                class_3218 sw = (class_3218) world;
                List<class_1799> overflow = ColouredInventory.get(sw, color).onContainerRemoved();
                for (class_1799 s : overflow) {
                    if (!s.method_7960()) class_1264.method_5449(world, pos.method_10263(), pos.method_10264(), pos.method_10260(), s);
                }
                world.method_8455(pos, this);
            }
            super.method_9536(state, world, pos, newState, moved);
        } else {
            super.method_9536(state, world, pos, newState, moved);
        }
    }

    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        if (world.field_9236) return null;
        return tickerIf(type, blockentity_init.COLORED_COFFER);
    }

    /** Local replacement for BlockWithEntity.checkType */
    @SuppressWarnings("unchecked")
    private static <T extends class_2586> class_5558<T> tickerIf(
            class_2591<T> given,
            class_2591<? extends ColouredCofferBlockEntity> expected
    ) {
        if (given == expected) {
            // Cast the serverTick method reference to the expected generic type.
            return (class_5558<T>) (class_5558<ColouredCofferBlockEntity>) ColouredCofferBlockEntity::serverTick;
        }
        return null;
    }

//for the screen handler below

    @Override
    public net.minecraft.class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {

        if (player.method_6047().method_7909() instanceof KeyItem
                || player.method_6079().method_7909() instanceof KeyItem) {
            return class_1269.field_5811; // let the item handle the interaction
        }

        if (world.field_9236) return net.minecraft.class_1269.field_5812;
        class_2586 be = world.method_8321(pos);
        if (be instanceof class_3908 factory) {
            player.method_17355(factory); // server → client sync
            return net.minecraft.class_1269.field_21466;
        }
        return net.minecraft.class_1269.field_5811;
    }

}
