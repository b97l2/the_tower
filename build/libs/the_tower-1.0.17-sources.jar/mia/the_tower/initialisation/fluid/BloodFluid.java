package mia.the_tower.initialisation.fluid;

import mia.the_tower.initialisation.item_init;
import mia.the_tower.initialisation.particle.CustomParticles;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_4538;
import net.minecraft.class_5819;

public abstract class BloodFluid extends BaseFluid {
    @Override public class_3611 method_15751() { return fluid_init.STILL_BLOOD; }
    @Override public class_3611 method_15750() { return fluid_init.FLOWING_BLOOD; }
    @Override public class_1792 method_15774() { return item_init.CHALICE_OF_BLOOD; }
    @Override protected class_2680 method_15790(class_3610 state) {
        return fluid_init.BLOOD.method_9564().method_11657(class_2741.field_12538, method_15741(state));
    }

    public static class Flowing extends BloodFluid {
        @Override protected void method_15775(class_2689.class_2690<class_3611, class_3610> builder) {
            super.method_15775(builder);
            builder.method_11667(field_15900);
        }
        @Override public int method_15779(class_3610 state) { return state.method_11654(field_15900); }
        @Override public boolean method_15793(class_3610 state) { return false; }
    }

    public static class Still extends BloodFluid {
        @Override public int method_15779(class_3610 state) { return 8; }
        @Override public boolean method_15793(class_3610 state) { return true; }
    }

    @Override
    public int method_15733(class_4538 world) {
        return 1;
    }

    @Override protected int method_15739(class_4538 world) { return 1; }
    @Override public int method_15789(class_4538 world) { return 10; }

    @Override
    public void method_15776(class_1937 world, class_2338 pos, class_3610 state, class_5819 random) {
        if (!state.method_15771() && !(Boolean)state.method_11654(field_15902)) {
            if (random.method_43048(64) == 0) {
                world.method_8486(
                        pos.method_10263() + 0.5,
                        pos.method_10264() + 0.5,
                        pos.method_10260() + 0.5,
                        class_3417.field_15237,
                        class_3419.field_15245,
                        random.method_43057() * 0.25F + 0.75F,
                        random.method_43057() + 0.5F,
                        false
                );
            }
        } else if (random.method_43048(10) == 0) {
            world.method_8406(
                    CustomParticles.UNDERBLOOD, pos.method_10263() + random.method_43058(), pos.method_10264() + random.method_43058(), pos.method_10260() + random.method_43058(), 0.0, 0.0, 0.0
            );
        }
    }

}
