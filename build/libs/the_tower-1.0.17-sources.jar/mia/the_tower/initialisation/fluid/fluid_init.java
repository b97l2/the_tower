package mia.the_tower.initialisation.fluid;

import mia.the_tower.The_Tower;
import mia.the_tower.initialisation.item_init;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_3609;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class fluid_init {
    public static final class_3609 STILL_BLOOD = class_2378.method_39197(class_7923.field_41173,
            class_5321.method_29179(class_7924.field_41270, The_Tower.id("blood")),
            new BloodFluid.Still());

    public static final class_3609 FLOWING_BLOOD = class_2378.method_39197(class_7923.field_41173,
            class_5321.method_29179(class_7924.field_41270, The_Tower.id("flowing_blood")),
            new BloodFluid.Flowing());

    public static final class_2248 BLOOD = class_2378.method_39197(class_7923.field_41175,
            class_5321.method_29179(class_7924.field_41254, The_Tower.id("blood")),
            new BloodFluidBlock(STILL_BLOOD, class_4970.class_2251.method_9637()
                    .method_51371()
                    .method_31710(class_3620.field_16012)
                    .method_22488()
                    .method_9632(100.0F)
                    .method_50012(class_3619.field_15971)
                    .method_42327()
                    .method_51177()
                    .method_9626(class_2498.field_44608)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, The_Tower.id("blood")))));

    public static final class_3609 STILL_GUNK = class_2378.method_39197(class_7923.field_41173,
            class_5321.method_29179(class_7924.field_41270, The_Tower.id("gunk")),
            new GunkFluid.Still());

    public static final class_3609 FLOWING_GUNK = class_2378.method_39197(class_7923.field_41173,
            class_5321.method_29179(class_7924.field_41270, The_Tower.id("flowing_gunk")),
            new GunkFluid.Flowing());

    public static final class_2248 GUNK = class_2378.method_39197(class_7923.field_41175,
            class_5321.method_29179(class_7924.field_41254, The_Tower.id("gunk")),
            new GunkFluidBlock(STILL_GUNK, class_4970.class_2251.method_9637()
                    .method_51371()
                    .method_31710(class_3620.field_16009)
                    .method_22488()
                    .method_9632(400.0F)
                    .method_50012(class_3619.field_15971)
                    .method_42327()
                    .method_51177()
                    .method_9626(class_2498.field_44608)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, The_Tower.id("gunk")))));

    public static final FluidLogging.Slot BLOOD_LOGGING_SLOT = registerLoggedFluid(
            FluidLogging.Slot.BLOOD,
            STILL_BLOOD,
            FLOWING_BLOOD,
            () -> item_init.CHALICE_OF_BLOOD
    );

    public static final FluidLogging.Slot GUNK_LOGGING_SLOT = registerLoggedFluid(
            FluidLogging.Slot.GUNK,
            STILL_GUNK,
            FLOWING_GUNK,
            () -> item_init.CUP_OF_GUNK
    );

    public static void load() {
    }

    private static FluidLogging.Slot registerLoggedFluid(
            FluidLogging.Slot slot,
            class_3609 still,
            class_3609 flowing,
            java.util.function.Supplier<net.minecraft.class_1792> bucketItem
    ) {
        FluidLogging.register(slot, still, flowing, () -> new net.minecraft.class_1799(bucketItem.get()));
        return slot;
    }
}
