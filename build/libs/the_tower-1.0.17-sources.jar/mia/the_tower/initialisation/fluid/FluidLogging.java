package mia.the_tower.initialisation.fluid;

import org.jetbrains.annotations.Nullable;

import java.util.EnumMap;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;
import net.minecraft.class_10225;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_3414;
import net.minecraft.class_3542;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_4538;

public final class FluidLogging {
    public static final class_2754<Slot> FLUID = class_2754.method_11850("fluid", Slot.class);

    private static final EnumMap<Slot, Entry> ENTRIES = new EnumMap<>(Slot.class);
    private static final Map<class_3611, Slot> FLUID_TO_SLOT = new IdentityHashMap<>();

    static {
        register(Slot.WATER, class_3612.field_15910, class_3612.field_15909, () -> new class_1799(class_1802.field_8705));
    }

    private FluidLogging() {
    }

    public static void appendProperty(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FLUID);
    }

    public static class_2680 withDefaultFluid(class_2680 state) {
        return state.method_11657(FLUID, Slot.NONE);
    }

    @Nullable
    public static class_2680 withPlacementFluid(@Nullable class_2680 state, class_1750 ctx) {
        if (state == null) {
            return null;
        }

        return withFluid(state, ctx.method_8045().method_8316(ctx.method_8037()).method_15772());
    }

    public static class_2680 withFluid(class_2680 state, class_3611 fluid) {
        return withSlot(state, getSlot(fluid));
    }

    public static class_2680 withSlot(class_2680 state, Slot slot) {
        if (state.method_28498(FLUID)) {
            state = state.method_11657(FLUID, slot);
        }
        if (state.method_28498(class_2741.field_12508)) {
            state = state.method_11657(class_2741.field_12508, slot == Slot.WATER);
        }
        return state;
    }

    public static class_2680 withoutFluidProperty(class_2680 state) {
        return state.method_28498(FLUID) ? state.method_11657(FLUID, Slot.NONE) : state;
    }

    public static boolean canFillWithFluid(@Nullable class_1657 player, class_1922 world, class_2338 pos, class_2680 state, class_3611 fluid) {
        return getLoggedSlot(state) == Slot.NONE && getSlot(fluid) != Slot.NONE;
    }

    public static boolean tryFillWithFluid(class_1936 world, class_2338 pos, class_2680 state, class_3610 fluidState) {
        Slot slot = getSlot(fluidState.method_15772());
        if (getLoggedSlot(state) != Slot.NONE || slot == Slot.NONE) {
            return false;
        }

        if (!world.method_8608()) {
            class_2680 newState = withSlot(state, slot);
            world.method_8652(pos, newState, class_2248.field_31036);
            scheduleFluidTick(newState, world, pos);
        }

        return true;
    }

    public static class_1799 tryDrainFluid(class_1936 world, class_2338 pos, class_2680 state) {
        Slot slot = getLoggedSlot(state);
        if (slot == Slot.NONE) {
            return class_1799.field_8037;
        }

        world.method_8652(pos, withSlot(state, Slot.NONE), class_2248.field_31036);
        if (!state.method_26184(world, pos)) {
            world.method_22352(pos, true);
        }

        Entry entry = ENTRIES.get(slot);
        return entry == null ? class_1799.field_8037 : entry.bucketStack().method_7972();
    }

    public static Optional<class_3414> getBucketFillSound() {
        return class_3612.field_15910.method_32359();
    }

    public static class_3610 getFluidState(class_2680 state, class_3610 fallback) {
        Entry entry = ENTRIES.get(getLoggedSlot(state));
        return entry == null ? fallback : entry.still().method_15785();
    }

    public static void scheduleFluidTick(class_2680 state, class_10225 tickView, class_4538 world, class_2338 pos) {
        Entry entry = ENTRIES.get(getLoggedSlot(state));
        if (entry != null) {
            tickView.method_64312(pos, entry.still(), entry.still().method_15789(world));
        }
    }

    public static void scheduleFluidTick(class_2680 state, class_1936 world, class_2338 pos) {
        Entry entry = ENTRIES.get(getLoggedSlot(state));
        if (entry != null) {
            world.method_64312(pos, entry.still(), entry.still().method_15789(world));
        }
    }

    public static boolean isFluidLogged(class_2680 state) {
        return getLoggedSlot(state) != Slot.NONE;
    }

    public static Slot getLoggedSlot(class_2680 state) {
        if (state.method_28498(FLUID)) {
            Slot slot = state.method_11654(FLUID);
            if (slot != Slot.NONE) {
                return slot;
            }
        }
        if (state.method_28498(class_2741.field_12508) && state.method_11654(class_2741.field_12508)) {
            return Slot.WATER;
        }
        return Slot.NONE;
    }

    public static Slot getSlot(class_3611 fluid) {
        return FLUID_TO_SLOT.getOrDefault(fluid, Slot.NONE);
    }

    public static void register(Slot slot, class_3611 still, @Nullable class_3611 flowing, Supplier<class_1799> bucketStackSupplier) {
        if (slot == Slot.NONE) {
            throw new IllegalArgumentException("Cannot register a logged fluid to the none slot");
        }
        if (ENTRIES.containsKey(slot)) {
            throw new IllegalStateException("Logged fluid slot is already registered: " + slot.method_15434());
        }

        Entry entry = new Entry(still, bucketStackSupplier);
        ENTRIES.put(slot, entry);
        FLUID_TO_SLOT.put(still, slot);
        if (flowing != null) {
            FLUID_TO_SLOT.put(flowing, slot);
        }
    }

    public static Slot register(class_3611 still, @Nullable class_3611 flowing, Supplier<class_1799> bucketStackSupplier) {
        for (Slot slot : Slot.values()) {
            if (slot != Slot.NONE && !ENTRIES.containsKey(slot)) {
                register(slot, still, flowing, bucketStackSupplier);
                return slot;
            }
        }

        throw new IllegalStateException("No free logged fluid slots remain");
    }

    private record Entry(class_3611 still, Supplier<class_1799> bucketStackSupplier) {
        class_1799 bucketStack() {
            return this.bucketStackSupplier.get();
        }
    }

    public enum Slot implements class_3542 {
        NONE("none"),
        WATER("water"),
        BLOOD("blood"),
        GUNK("gunk"),
        FLUID_4("fluid_4"),
        FLUID_5("fluid_5"),
        FLUID_6("fluid_6"),
        FLUID_7("fluid_7"),
        FLUID_8("fluid_8"),
        FLUID_9("fluid_9"),
        FLUID_10("fluid_10"),
        FLUID_11("fluid_11"),
        FLUID_12("fluid_12"),
        FLUID_13("fluid_13"),
        FLUID_14("fluid_14"),
        FLUID_15("fluid_15");

        private final String name;

        Slot(String name) {
            this.name = name;
        }

        @Override
        public String method_15434() {
            return this.name;
        }
    }
}
