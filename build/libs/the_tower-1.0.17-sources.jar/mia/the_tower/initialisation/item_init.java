package mia.the_tower.initialisation;

import mia.the_tower.The_Tower;
import mia.the_tower.initialisation.block.stake_init;
import mia.the_tower.initialisation.entity.ModEntities;
import mia.the_tower.initialisation.items.*;
import mia.the_tower.initialisation.particle.CustomParticles;
import mia.the_tower.initialisation.status_effects.InstantMineEffect;
import mia.the_tower.initialisation.status_effects.SanguineStatusEffect;
import mia.the_tower.initialisation.status_effects.levitate_init;
import mia.the_tower.initialisation.status_effects.pale_death_init;
import net.minecraft.class_10128;
import net.minecraft.class_10132;
import net.minecraft.class_10192;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1322;
import net.minecraft.class_1747;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1814;
import net.minecraft.class_1826;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import net.minecraft.class_4174;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9274;
import net.minecraft.class_9285;
import net.minecraft.class_9334;
import net.minecraft.component.type.*;
import net.minecraft.item.*;

import static mia.the_tower.initialisation.block_init.*;

public class item_init { //this is the class that initialises items in the mod

    public static class_1792 GLOOP;
    public static class_1792 GLUH;
    public static class_1792 YUMP; //*add textures
    public static class_1792 KLAEN;
    public static class_1792 BLAJ;
    public static class_1792 CHALICE_OF_BLOOD;
    public static class_1792 CUP_OF_GUNK;
    public static class_1792 STAVE;
    public static class_1792 PILLAR_OF_SALT;
    public static class_1792 PILE_OF_SALT;
    public static class_1792 GABRIELS_TRUMPET;
    public static class_1792 DRAGONS_EYE;
    public static class_1792 PEARL_OF_BLOOD;
    public static class_1792 HORNWORM;
    public static class_1792 SANGUINE_FLASK;
    public static class_1792 BUCKET_OF_BILE;
    public static class_1792 FINGER;
    public static class_1792 BLOODY_NAIL;
    public static class_1792 TOOTH;
    public static class_1792 SANGUINE_SYRINGE;
    public static class_1792 CONTRACT;
    public static class_1792 PALE_AXE;
    public static class_1792 MY_RAGE;
    public static class_1792 MY_FUEL;
    public static class_1792 SHEPHERDS_STAFF;
    public static class_1792 VOID_MOTH_SPAWN_EGG;
    public static class_1792 GINKGO_LEAF;
    public static class_1792 CIRCLET_OF_GLUT;
    public static class_1792 PLATE;
    public static class_1792 WHITE_KEY;
    public static class_1792 ORANGE_KEY;
    public static class_1792 MAGENTA_KEY;
    public static class_1792 LIGHT_BLUE_KEY;
    public static class_1792 YELLOW_KEY;
    public static class_1792 LIME_KEY;
    public static class_1792 PINK_KEY;
    public static class_1792 GREY_KEY;
    public static class_1792 LIGHT_GREY_KEY;
    public static class_1792 CYAN_KEY;
    public static class_1792 PURPLE_KEY;
    public static class_1792 BLUE_KEY;
    public static class_1792 BROWN_KEY;
    public static class_1792 GREEN_KEY;
    public static class_1792 RED_KEY;
    public static class_1792 BLACK_KEY;
    public static class_1792 KEY;
    public static class_1792 GINKGO_FRUIT;
    public static class_1792 SUPERIOR_BLAJ_ORE_ITEM;
    public static class_1792 LESSER_BLAJ_ORE_ITEM;
    public static class_1792 ITORE_ORE;
    public static class_1792 GOLDEN_SEED;
    public static class_1792 RAW_SILVER;
    public static class_1792 RAW_SILVER_NUGGET;
    public static class_1792 SILVER_INGOT;
    public static class_1792 SILVER_WIRE;
    public static class_1792 RUFESCENT_PEARL;
    public static class_1792 TWINTAIL_BERRY;
    public static class_1792 CHOCOLATE_BAR;
    public static class_1792 FRAYED_NOTE;
    public static class_1792 DIVINING_ROD;
    public static class_1792 TOAST;
    public static class_1792 TOFFEE_APPLE;
    public static class_1792 CHUNK_OF_KAOLIN;
    public static class_1792 SKYNUT;
    public static class_1792 FATIGUE;
    public static class_1792 LAVALIERE_OF_THE_GOLDEN_SUN;
    public static class_1792 PORCELAIN;

    public static void load() {
        GLOOP = register("gloop", new class_1792(new class_1792.class_1793()
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("gloop")))));

        GLUH = register("gluh", new class_1747(
                crop_init.GLUH_VINE,
                new class_1792.class_1793().method_62833(
                        new class_4174.class_4175()
                                .method_19240()
                                .method_19242(),
                        new class_10128().method_62858()
                                .method_62854(new class_10132(new class_1293(levitate_init.LEVITATE, 60 * 20, 1), 1.0f))
                                .method_62851())
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("gluh")))));

        YUMP = register("yump", new class_1792(new class_1792.class_1793()
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("yump")))));

        BLAJ = register("blaj", new BlajItem(new class_1792.class_1793()
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("blaj")))));

        SUPERIOR_BLAJ_ORE_ITEM = register("superior_blaj_ore_item", new class_1792(new class_1792.class_1793()
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("superior_blaj_ore_item")))));

        LESSER_BLAJ_ORE_ITEM = register("lesser_blaj_ore_item", new class_1792(new class_1792.class_1793()
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("lesser_blaj_ore_item")))));

        ITORE_ORE = register("itore_ore", new class_1792(new class_1792.class_1793()
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("itore_ore")))));

        KLAEN = register("klaen", new class_1747(
                stake_init.STAKE, //change
                new class_1792.class_1793().method_62833(
                                new class_4174.class_4175()
                                        .method_19240()
                                        .method_19242(),
                                new class_10128().method_62858()
                                        .method_62854(new class_10132(new class_1293(pale_death_init.PALE_DEATH, 13 * 20, 1), 1.0f))
                                        .method_62851())
                        .method_7889(9)
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("klaen")))));

        CHALICE_OF_BLOOD = class_2378.method_39197(class_7923.field_41178,
                class_5321.method_29179(class_7924.field_41197, The_Tower.id("chalice_of_blood")),
                new FluidloggingBucketItem(STILL_BLOOD, new class_1792.class_1793()
                        .method_7896(net.minecraft.class_1802.field_8550)
                        .method_7889(1)
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("chalice_of_blood")))));

        CUP_OF_GUNK = class_2378.method_39197(class_7923.field_41178,
                class_5321.method_29179(class_7924.field_41197, The_Tower.id("cup_of_gunk")),
                new FluidloggingBucketItem(STILL_GUNK, new class_1792.class_1793()
                        .method_7896(net.minecraft.class_1802.field_8550)
                        .method_7889(1)
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("cup_of_gunk")))));

        BUCKET_OF_BILE = class_2378.method_39197(class_7923.field_41178,
                class_5321.method_29179(class_7924.field_41197, The_Tower.id("bucket_of_bile")),
                new FluidloggingBucketItem(STILL_GUNK, new class_1792.class_1793()
                        .method_7896(net.minecraft.class_1802.field_8550)
                        .method_7889(1)
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("bucket_of_bile")))));

        STAVE = register("stave", new StaveItem(new class_1792.class_1793()
                .method_7889(1)
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("stave")))));

        PILLAR_OF_SALT = register("pillar_of_salt", new PillarOfSaltItem(new class_1792.class_1793()
                .method_7889(1)
                .method_62832(3)
                .method_7894(class_1814.field_8907)
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("pillar_of_salt")))));

        DIVINING_ROD = register("divining_rod", new SeekingItem(block_init.GRAVESTONE, CustomParticles.GOLD_ORB, new class_1792.class_1793()
                .method_7889(1)
                .method_62832(3)
                .method_7894(class_1814.field_8907)
                .method_7895(10)
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("divining_rod")))));

        PILE_OF_SALT = register("pile_of_salt", new class_1792(new class_1792.class_1793().method_62833(
                        new class_4174.class_4175()
                                .method_19240()
                                .method_19242(),
                        new class_10128().method_62858()
                                .method_62854(new class_10132(new class_1293(InstantMineEffect.WHAMMY_HAND, 49 * 20, 1), 1.0f))
                                .method_62851())
                .method_7889(9)
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("pile_of_salt"))))); //crafting exclusive, change later on

        GABRIELS_TRUMPET = register("gabriels_trumpet", new class_1792(new class_1792.class_1793()
                .method_7889(1)
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("gabriels_trumpet"))))); //add logic in custom class

        DRAGONS_EYE = register("dragons_eye", new class_1792(new class_1792.class_1793()
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("dragons_eye"))))); //add logic in custom class

        PEARL_OF_BLOOD = register("pearl_of_blood", new class_1792(new class_1792.class_1793()
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("pearl_of_blood")))));

        HORNWORM = register("hornworm", new class_1792(new class_1792.class_1793()
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("hornworm")))));

        SANGUINE_FLASK = register("sanguine_flask", new class_1792(new class_1792.class_1793().method_62833(
                        new class_4174.class_4175()
                                .method_19240()
                                .method_19242(),
                        new class_10128().method_62859()
                                .method_62854(new class_10132(new class_1293(SanguineStatusEffect.SANGUINE, 120 * 20, 0), 1.0f))
                                .method_62851())
                .method_7889(9)
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("sanguine_flask"))))); //only gotten through distilling process

        FINGER = register("finger", new class_1792(new class_1792.class_1793()
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("finger")))));

        BLOODY_NAIL = register("bloody_nail", new class_1792(new class_1792.class_1793()
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("bloody_nail")))));

        TOOTH = register("tooth", new class_1792(new class_1792.class_1793()
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("tooth")))));

        SANGUINE_SYRINGE = register("sanguine_syringe", new class_1792(new class_1792.class_1793()
                .method_7889(9)
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("sanguine_syringe")))));

        CONTRACT = register("contract", new class_1792(new class_1792.class_1793()
                .method_7889(1)
                .method_7894(class_1814.field_8904)
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("contract")))));

        PALE_AXE = register("pale_axe", new class_1792(new class_1792.class_1793()
                .method_7894(class_1814.field_8904)
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("pale_axe")))));

        MY_RAGE = register("my_rage", new class_1792(new class_1792.class_1793()
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("my_rage")))));

        MY_FUEL = register("my_fuel", new class_1792(new class_1792.class_1793()
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("my_fuel")))));

        SHEPHERDS_STAFF = register("shepherds_staff", new ShepherdsStaffItem(new class_1792.class_1793()
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("shepherds_staff")))));

        VOID_MOTH_SPAWN_EGG = register("void_moth_spawn_egg", new class_1826(ModEntities.VOID_MOTH, new class_1792.class_1793()
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("void_moth_spawn_egg")))));

        GINKGO_LEAF = register("ginkgo_leaf", new class_1792(new class_1792.class_1793()
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("ginkgo_leaf")))));

        GOLDEN_SEED = register("golden_seed", new class_1747(
                GINKGO_SAPLING, //change
                new class_1792.class_1793()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("golden_seed")))));

        GINKGO_FRUIT = register("ginkgo_fruit", new class_1792(new class_1792.class_1793()
                .method_62833(
                        new class_4174.class_4175()
                                .method_19240()
                                .method_19242(),
                        new class_10128().method_62858()
                                .method_62854(new class_10132(new class_1293(class_1294.field_5899, 15 * 20, 1), 1.0f))
                                .method_62851())
                .method_62834(GOLDEN_SEED)
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("ginkgo_fruit")))));

        SKYNUT = register("skynut", new class_1747(
                VAULTS_STANCHION_SAPLING, //change
                new class_1792.class_1793()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("skynut")))));


        CIRCLET_OF_GLUT = register("circlet_of_glut", new CircletOfGlutItem(new class_1792.class_1793()
                //.equippable(EquipmentSlot.HEAD)
                .method_7894(class_1814.field_8904)
                .method_7889(1)
                .method_57349(class_9334.field_49636, class_9285.method_57480()
                        .method_57487(
                                class_5134.field_23721, // +4 max HP
                                new class_1322(
                                        class_2960.method_60655("the_tower","circlet_of_glut_attack_damage"),
                                        -3000,
                                        class_1322.class_1323.field_6328),
                                class_9274.field_49223
                        )
                        .method_57487(
                                class_5134.field_23724, // +4 max HP
                                new class_1322(
                                        class_2960.method_60655("the_tower","circlet_of_glut_armour"),
                                        -40,
                                        class_1322.class_1323.field_6328),
                                class_9274.field_49223
                        )
                        .method_57487(
                                class_5134.field_23725, // +4 max HP
                                new class_1322(
                                        class_2960.method_60655("the_tower","circlet_of_glut_armour_toughness"),
                                        -40,
                                        class_1322.class_1323.field_6328),
                                class_9274.field_49223
                        )
                        .method_57486()
                )
                .method_57349(
                        class_9334.field_54196,
                        class_10192.method_64202(class_1304.field_6169)
                                .method_64205(class_3417.field_15191)
                                .method_64204(CustomEquipmentAssets.CIRCLET_OF_GLUT)
                                .method_64210(false)
                                .method_64203()
                )
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("circlet_of_glut")))));

        LAVALIERE_OF_THE_GOLDEN_SUN = register("lavaliere_of_the_golden_sun", new CircletOfGlutItem(new class_1792.class_1793()
                //.equippable(EquipmentSlot.HEAD)
                .method_7894(class_1814.field_8907)
                .method_7889(1)
//                .component(DataComponentTypes.ATTRIBUTE_MODIFIERS, AttributeModifiersComponent.builder()
//                        .add(
//                                EntityAttributes.GRAVITY,
//                                new EntityAttributeModifier(
//                                        Identifier.of("the_tower","lavaliere_of_the_golden_sun"),
//                                        -3000,
//                                        EntityAttributeModifier.Operation.ADD_VALUE),
//                                AttributeModifierSlot.BODY
//                        )
//                        .build()
//                )
                .method_57349(
                        class_9334.field_54196,
                        class_10192.method_64202(class_1304.field_6174)
                                .method_64205(class_3417.field_15191)
                                .method_64204(CustomEquipmentAssets.LAVALIERE_OF_THE_GOLDEN_SUN)
                                .method_64210(false)
                                .method_64203()
                )
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("lavaliere_of_the_golden_sun")))));


        PLATE = register("plate", new PlateItem(
                new class_1792.class_1793()
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("plate")))));

        WHITE_KEY = register("white_key", new KeyItem(class_1767.field_7952,
                new class_1792.class_1793()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("white_key")))));

        ORANGE_KEY = register("orange_key", new KeyItem(class_1767.field_7946,
                new class_1792.class_1793()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("orange_key")))));

        MAGENTA_KEY = register("magenta_key", new KeyItem(class_1767.field_7958,
                new class_1792.class_1793()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("magenta_key")))));

        LIGHT_BLUE_KEY = register("light_blue_key", new KeyItem(class_1767.field_7951,
                new class_1792.class_1793()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("light_blue_key")))));

        YELLOW_KEY = register("yellow_key", new KeyItem(class_1767.field_7947,
                new class_1792.class_1793()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("yellow_key")))));

        LIME_KEY = register("lime_key", new KeyItem(class_1767.field_7961,
                new class_1792.class_1793()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("lime_key")))));

        PINK_KEY = register("pink_key", new KeyItem(class_1767.field_7954,
                new class_1792.class_1793()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("pink_key")))));

        GREY_KEY = register("grey_key", new KeyItem(class_1767.field_7944,
                new class_1792.class_1793()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("grey_key")))));

        LIGHT_GREY_KEY = register("light_grey_key", new KeyItem(class_1767.field_7967,
                new class_1792.class_1793()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("light_grey_key")))));

        CYAN_KEY = register("cyan_key", new KeyItem(class_1767.field_7955,
                new class_1792.class_1793()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("cyan_key")))));

        PURPLE_KEY = register("purple_key", new KeyItem(class_1767.field_7945,
                new class_1792.class_1793()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("purple_key")))));

        BLUE_KEY = register("blue_key", new KeyItem(class_1767.field_7966,
                new class_1792.class_1793()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("blue_key")))));

        BROWN_KEY = register("brown_key", new KeyItem(class_1767.field_7957,
                new class_1792.class_1793()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("brown_key")))));

        GREEN_KEY = register("green_key", new KeyItem(class_1767.field_7942,
                new class_1792.class_1793()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("green_key")))));

        RED_KEY = register("red_key", new KeyItem(class_1767.field_7964,
                new class_1792.class_1793()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("red_key")))));

        BLACK_KEY = register("black_key", new KeyItem(class_1767.field_7963,
                new class_1792.class_1793()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("black_key")))));

        KEY = register("key", new class_1792(
                new class_1792.class_1793()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("key")))));

        RAW_SILVER = register("raw_silver", new class_1792(
                new class_1792.class_1793()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("raw_silver")))));

        RAW_SILVER_NUGGET = register("raw_silver_nugget", new class_1792(
                new class_1792.class_1793()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("raw_silver_nugget")))));

        SILVER_INGOT = register("silver_ingot", new class_1792(
                new class_1792.class_1793()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("silver_ingot")))));

        SILVER_WIRE = register("silver_wire", new class_1792(
                new class_1792.class_1793()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("silver_wire")))));

        RUFESCENT_PEARL = register("rufescent_pearl", new class_1792(
                new class_1792.class_1793()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("rufescent_pearl")))));

        TWINTAIL_BERRY = register("twintail_berry", new class_1792(new class_1792.class_1793()
                .method_19265(
                        new class_4174.class_4175()
                                .method_19238(3)
                                .method_19237(0.4F)
                                .method_19242())
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("twintail_berry")))));

        CHOCOLATE_BAR = register("chocolate_bar", new class_1792(new class_1792.class_1793()
                .method_19265(
                        new class_4174.class_4175()
                                .method_19238(6)
                                .method_19237(0.2F)
                                .method_19242())
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("chocolate_bar")))));

        TOAST = register("toast", new class_1792(new class_1792.class_1793()
                .method_19265(
                        new class_4174.class_4175()
                                .method_19238(2)
                                .method_19237(0.2F)
                                .method_19242())
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("toast")))));

        TOFFEE_APPLE = register("toffee_apple", new class_1792(new class_1792.class_1793()
                .method_19265(
                        new class_4174.class_4175()
                                .method_19238(4)
                                .method_19237(0.3F)
                                .method_19242())
                .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("toffee_apple")))));

        FRAYED_NOTE = register("frayed_note", new class_1792(
                new class_1792.class_1793()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("frayed_note")))));

        CHUNK_OF_KAOLIN = register("chunk_of_kaolin", new class_1792(
                new class_1792.class_1793()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("chunk_of_kaolin")))));

        PORCELAIN = register("porcelain", new class_1792(
                new class_1792.class_1793()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("porcelain")))));

        FATIGUE = register("fatigue", new class_1792(
                new class_1792.class_1793()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, The_Tower.id("fatigue")))));

    }

    public static class_1792 register(String name, class_1792 item) {
        class_2960 id = The_Tower.id(name);
        class_5321<class_1792> itemKey = class_5321.method_29179(class_7924.field_41197, id);
        return class_2378.method_39197(class_7923.field_41178, itemKey, item);
    }


    //public static void load() {} //This method allows us to load the items here into the game

}

