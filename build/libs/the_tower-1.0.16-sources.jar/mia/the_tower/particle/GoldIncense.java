package mia.the_tower.particle;

import net.minecraft.class_2400;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;
import net.minecraft.client.particle.*;
import org.jetbrains.annotations.Nullable;


public class GoldIncense extends class_4003 {
    private final class_4002 sprites;


    public GoldIncense(class_638 world, double x, double y, double z,
                       double vx, double vy, double vz, class_4002 sprites) {
        super(world, x, y, z, vx, vy, vz);
        this.sprites = sprites;
        this.field_17867 *= this.field_3840.method_43057() * 0.6F + 1.5F;
        this.field_3847 = (int)((double)3000.0F / (Math.random() * 0.8 + 0.2));
        this.field_28786 = 0.1f;
        this.field_3844 = 0.45f;
        this.field_3862 = true;
        this.field_3852 = vx;
        this.field_3869 = vy;
        this.field_3850 = vz;
        //this.setSpriteForAge(sprites);
    }

@Override
    public class_3999 method_18122(){
        return class_3999.field_17829;
}

/*
    @Override
    public void tick() {
        super.tick();                  // increments age
        this.setSpriteForAge(sprites); // updates frame based on age/maxAge
    }

 */



    public static class Factory implements class_707<class_2400> {
        private final class_4002 spriteProvider;

        public Factory(class_4002 spriteProvider) {
            this.spriteProvider = spriteProvider;
        }

        @Nullable
        @Override
        public class_703 createParticle(class_2400 parameters, class_638 world, double x, double y, double z,
                                       double velocityX, double velocityY, double velocityZ) {

            GoldIncense particle = new GoldIncense(world, x, y, z, velocityX, velocityY, velocityZ, this.spriteProvider);
            particle.method_18141(spriteProvider.method_18139(world.field_9229));
            return particle;
        }
    }



}
