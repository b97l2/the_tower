package mia.the_tower;

import mia.the_tower.initialisation.biomes.*;
import mia.the_tower.initialisation.datagen.ModWorldGenerator;
import mia.the_tower.initialisation.dimentions.TheFrage;
import mia.the_tower.initialisation.world.ModConfiguredFeatures;
import mia.the_tower.initialisation.world.ModPlacedFeatures;
import net.fabricmc.fabric.api.datagen.v1.DataGeneratorEntrypoint;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.minecraft.class_7877;
import net.minecraft.class_7924;

public class The_TowerDataGenerator implements DataGeneratorEntrypoint {
	@Override
	public void onInitializeDataGenerator(FabricDataGenerator fabricDataGenerator) {
		FabricDataGenerator.Pack pack = fabricDataGenerator.createPack();
		pack.addProvider(ModWorldGenerator::new);
	}

	@Override
	public void buildRegistry(class_7877 registryBuilder) { //need one for datagen here
		registryBuilder.method_46777(class_7924.field_41236, Shadowlands::bootstrap);
		registryBuilder.method_46777(class_7924.field_41236, ThePit::bootstrap);
		registryBuilder.method_46777(class_7924.field_41236, CeruleanCoast::bootstrap);
		registryBuilder.method_46777(class_7924.field_41236, GoldenWeald::bootstrap);
		registryBuilder.method_46777(class_7924.field_41241, TheFrage::bootstrapType);
		registryBuilder.method_46777(class_7924.field_41239, ModConfiguredFeatures::bootstrap);
		registryBuilder.method_46777(class_7924.field_41245, ModPlacedFeatures::bootstrap);
	}
}
