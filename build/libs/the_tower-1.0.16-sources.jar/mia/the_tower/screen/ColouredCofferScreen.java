package mia.the_tower.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import mia.the_tower.initialisation.screen.CofferScreenHandler;
import net.minecraft.class_1661;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4264;
import net.minecraft.class_465;

public class
ColouredCofferScreen extends class_465<CofferScreenHandler> {
    // vanilla chest background works for 9x3 if we size regions appropriately
    private static final class_2960 BG = class_2960.method_60655("the_tower", "textures/gui/container/coffer_screen.png");
    private static final class_2960 TEX_PREV = class_2960.method_60655("the_tower", "textures/gui/container/pagination_button_coloured_coffer_left.png");
    private static final class_2960 TEX_NEXT = class_2960.method_60655("the_tower", "textures/gui/container/pagination_button_coloured_coffer_right.png");

    private IconButton prevBtn;
    private IconButton nextBtn;

    // derived sizes for 9x3
    private static final int TOP_HEIGHT = 17 + CofferScreenHandler.ROWS_VISIBLE * 18; // 71 for 3 rows
    private static final int BOTTOM_HEIGHT = 96; // player inv panel

    private float scroll = 0.0f; // 0..1

    public ColouredCofferScreen(CofferScreenHandler handler, class_1661 inv, class_2561 title) {
        super(handler, inv, title);
        this.field_2792  = 176;
        this.field_2779 = TOP_HEIGHT + BOTTOM_HEIGHT; // 71 + 96 = 167 (close to vanilla 166)
        this.field_25270 = this.field_2779 - 94; // vanilla convention
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        // 12x12 buttons beside the grid; adjust positions as you like
        prevBtn = new IconButton(0, 0, 12, 12, TEX_PREV, () ->
                this.field_22787.field_1761.method_2900(this.field_2797.field_7763, 0) // page--
        );
        nextBtn = new IconButton(0, 0, 12, 12, TEX_NEXT, () ->
                this.field_22787.field_1761.method_2900(this.field_2797.field_7763, 1) // page++
        );

        this.method_37063(prevBtn);
        this.method_37063(nextBtn);

        placeButtons();
    }

    @Override
    protected void method_37432() {
        int page  = this.field_2797.getPage();
        int total = this.field_2797.getTotalPagesSynced();

        if (prevBtn != null) prevBtn.field_22763 = page > 0;
        if (nextBtn != null) nextBtn.field_22763 = page < total - 1;
    }

    @Override
    protected void method_2389(class_332 ctx, float delta, int mouseX, int mouseY) {
        int i = (this.field_22789 - this.field_2792) / 2;
        int j = (this.field_22790 - this.field_2779) / 2;
        ctx.method_25290(class_1921::method_62277, BG, i, j, 0.0F, 0.0F, this.field_2792, this.field_2779, 256, 256);
    }


    @Override
    protected void method_2388(class_332 ctx, int mouseX, int mouseY) {
        //these are to draw titles, but I don't want this for this block
//        ctx.drawText(this.textRenderer, this.title, this.titleX, this.titleY, 0x404040, false);
//        ctx.drawText(this.textRenderer, this.playerInventoryTitle, this.playerInventoryTitleX, this.playerInventoryTitleY, 0x404040, false);

        //this is for page indicator
        String p = (field_2797.getPage() + 1) + " of " + field_2797.getTotalPagesSynced();
        int w = this.field_22793.method_1727(p);
        ctx.method_51433(this.field_22793, p, this.field_2792/2 - w/2, this.field_2779/2 - 10, 0x404040, false);
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        //this.renderBackground(ctx);                 // 1) dim the world behind
        super.method_25394(ctx, mouseX, mouseY, delta);   // 2) draw slots/items/etc.
        this.method_2380(ctx, mouseX, mouseY); // 3) draw item tooltips last
    }

    private static final class IconButton extends class_4264 {
        private final class_2960 texture;
        private final Runnable onClick;

        IconButton(int x, int y, int w, int h, class_2960 texture, Runnable onClick) {
            super(x, y, w, h, class_2561.method_43473());
            this.texture = texture;
            this.onClick = onClick;
        }

        @Override
        public void method_25306() {
            if (onClick != null) onClick.run();
        }

        @Override
        protected void method_48579(class_332 ctx, int mouseX, int mouseY, float delta) {
            int state = !this.field_22763 ? 2 : (this.method_49606() ? 1 : 0); // 0=normal,1=hover,2=disabled
            float u = 0.0f;
            float v = state * this.field_22759;
            int sheetW = this.field_22758;   // set to full sheet width (or 256 if using an atlas-style sheet)
            int sheetH = this.field_22759 * 3;

            ctx.method_25290(class_1921::method_62277, texture, this.method_46426(), this.method_46427(),
                    u, v, this.field_22758, this.field_22759, sheetW, sheetH);
        }

        @Override
        protected void method_47399(net.minecraft.class_6382 b) {
            // Optional narration; leave empty for icon-only
        }
    }

 //this is to keep buttons in the right place despite resolution changes
    private static final int BTN_W = 12, BTN_H = 12;
    private static final int BTN_MARGIN_RIGHT = 47;   // distance from right edge of the container
    private static final int BTN_TOP_OFFSET   = 71;  // distance from container top to row 1
    private static final int BTN_GAP          = 58;   // gap between prev/next

    private void placeButtons() {
        // anchor to the right edge of the container, not magic numbers
        int right = this.field_2776 + this.field_2792;          // container right x
        int nextX = right - BTN_MARGIN_RIGHT - BTN_W;       // rightmost button
        int prevX = nextX - BTN_GAP - BTN_W;
        int y     = this.field_2800 + BTN_TOP_OFFSET;

        if (prevBtn != null) prevBtn.method_48229(prevX, y);
        if (nextBtn != null) nextBtn.method_48229(nextX, y);
    }

}
