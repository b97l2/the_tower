package mia.the_tower.mixin.client;


import mia.the_tower.initialisation.status_effects.SanguineStatusEffect;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_757.class)
public abstract class GameRendererMixin {

    @Shadow @Final private class_310 client;

    //used by GameRenderer to ease FOV changes frame-to-frame
    @Shadow private float fovMultiplier;
    @Shadow private float lastFovMultiplier;

    @Inject(method = "updateFovMultiplier", at = @At("HEAD"), cancellable = true)
    private void modid$freezeSpeedFovOnOurEffect(CallbackInfo ci) {
        class_1297 cam = this.client.method_1560();
        if (!(cam instanceof class_1309 living)) return;

        boolean hasOurSpeedEffect = living.method_6059(SanguineStatusEffect.SANGUINE);

        if (hasOurSpeedEffect) {
            // Smoothly converge FOV multiplier to 1.0 (neutral: no speed-based FOV change)
            this.lastFovMultiplier = this.fovMultiplier;
            this.fovMultiplier += (1.0F - this.fovMultiplier) * 0.5F;
            ci.cancel(); // Skip vanilla’s computation (which reads movement speed)
        }
    }
}