package mia.the_tower.mixin;

import net.minecraft.class_3222;
import net.minecraft.class_3225;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_3225.class)
public interface ServerPlayerInteractionManagerAccessor {
    @Accessor("player")
    class_3222 getPlayer();
}
