package mia.the_tower.initialisation.sounds;

import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

public class CustomSounds {
    //a line here for each sound
    //a line below for each sound group
    //an entry in the sounds.json for each group and individual sound
    //all sounds in ogg format in the sounds folder
    //then give the chosen thing your sound group
    public static final class_3414 SCREAMING_BLOCK_BREAK = registerSoundEvent("screaming_block_break");
    public static final class_3414 SCREAMING_BLOCK_STEP = registerSoundEvent("screaming_block_step");
    public static final class_3414 SCREAMING_BLOCK_PLACE = registerSoundEvent("screaming_block_place");
    public static final class_3414 SCREAMING_BLOCK_HIT = registerSoundEvent("screaming_block_hit");
    public static final class_3414 SCREAMING_BLOCK_FALL = registerSoundEvent("screaming_block_fall");
//coresponding sound group
    public static final class_2498 SCREAMING_BLOCK = new class_2498(1f, 1f,
            SCREAMING_BLOCK_BREAK, SCREAMING_BLOCK_STEP, SCREAMING_BLOCK_PLACE, SCREAMING_BLOCK_HIT, SCREAMING_BLOCK_FALL);

    public static final class_3414 BLAJ_USE = registerSoundEvent("blaj_use");

    public static final class_3414 BLAJ_BLOCK_BREAK = registerSoundEvent("blaj_block_break");
    public static final class_3414 BLAJ_BLOCK_STEP = registerSoundEvent("blaj_block_step");
    public static final class_3414 BLAJ_BLOCK_PLACE = registerSoundEvent("blaj_block_place");
    public static final class_3414 BLAJ_BLOCK_HIT = registerSoundEvent("blaj_block_hit");
    public static final class_3414 BLAJ_BLOCK_FALL = registerSoundEvent("blaj_block_fall");
    //coresponding sound group
    public static final class_2498 BLAJ_BLOCK = new class_2498(1f, 1f,
            BLAJ_BLOCK_BREAK, BLAJ_BLOCK_STEP, BLAJ_BLOCK_PLACE, BLAJ_BLOCK_HIT, BLAJ_BLOCK_FALL);

    public static final class_3414 SHEPHERDS_STAFF_USE = registerSoundEvent("shepherds_staff_use");




    private static class_3414 registerSoundEvent(String name) {
        class_2960 id = class_2960.method_60655("the_tower", name);
        return class_2378.method_10230(class_7923.field_41172, id, class_3414.method_47908(id));
    }

    public static void load() {}

}
