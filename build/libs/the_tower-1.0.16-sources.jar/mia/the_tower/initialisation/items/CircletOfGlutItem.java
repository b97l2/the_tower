package mia.the_tower.initialisation.items;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1702;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import java.util.List;

public class CircletOfGlutItem extends class_1792 {
    public CircletOfGlutItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public void method_7888(class_1799 stack, class_1937 world, class_1297 entity, int slot, boolean selected) {
        if (world.field_9236 || !(entity instanceof class_1657 player)) return;

        // Only act if THIS stack is actually equipped on the head
        if (player.method_6118(class_1304.field_6169) != stack) return;

        // Run ~once per second to reduce churn
        if ((player.field_6012 % 20) == 0) {
            class_1702 hm = player.method_7344();
            if (hm.method_7586() < 20) hm.method_7580(20);
            if (hm.method_7589() < 20f) hm.method_7581(20f);
        }
    }

    @Override
    @Environment(EnvType.CLIENT)
    public void method_7851(class_1799 stack,
                              class_9635 context,
                              List<class_2561> tooltip,
                              class_1836 type) {
        tooltip.add(class_2561.method_43470("Their end is destruction,").method_27695(class_124.field_1080, class_124.field_1056));
        tooltip.add(class_2561.method_43470("their god is their belly,").method_27695(class_124.field_1080, class_124.field_1056));
        tooltip.add(class_2561.method_43470("and they glory in their shame,").method_27695(class_124.field_1080, class_124.field_1056));
        tooltip.add(class_2561.method_43470("with minds set on earthly things.").method_27695(class_124.field_1080, class_124.field_1056));
    }

}
