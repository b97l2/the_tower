package mia.the_tower.initialisation.items;

import mia.the_tower.initialisation.block_init;
import mia.the_tower.initialisation.particle.CustomParticles;
import mia.the_tower.initialisation.sounds.CustomSounds;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import net.minecraft.class_5819;

public class BlajItem extends class_1792 {

    public BlajItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        user.method_6019(hand);


        if (world.field_9236) {
            return class_1269.field_5812;
        }

        // SERVER: safe to cast now
        class_3218 server = (class_3218) world;

        // play to everyone from server
        world.method_8396(null, user.method_24515(), CustomSounds.BLAJ_USE, class_3419.field_15248, 1.0f, 1.0f);

        // 64-block raycast; include fluids? true here
        var hit = user.method_5745(64.0, 0.0F, true);
        if (!(hit instanceof net.minecraft.class_3965 bhr)) {
            return class_1269.field_5814;
        }

        class_2338 spawnAt = bhr.method_17777().method_10093(bhr.method_17780());
        boolean ok = buildAt(server, spawnAt);

        if (ok && !user.method_7337()) {
            user.method_5998(hand).method_7934(1);
        }
        return ok ? class_1269.field_21466 : class_1269.field_5814;
    }


    public static boolean buildAt(class_3218 world, class_2338 origin) {
        class_5819 random = world.method_8409();

        int height = random.method_39332(8, 18);
        int x = origin.method_10263();
        int z = origin.method_10260();
        int y = origin.method_10264() + height;

        var pos = new net.minecraft.class_2338.class_2339();

        //sets the edges and the faces here
        for (int i = height; i >= 0; i--) {
            int dif = height - i;
            //for creating the edges
            set(world, pos.method_10103(x - dif, y - dif, z), pick(random, EDGES, 5));
            set(world, pos.method_10103(x + dif, y - dif, z), pick(random, EDGES, 5));
            set(world, pos.method_10103(x, y - dif, z + dif), pick(random, EDGES, 5));
            set(world, pos.method_10103(x, y - dif, z - dif), pick(random, EDGES, 5));
            //for creating the faces
            for (int j = dif; j >= 1; j--) {
                if(i != 0) {
                    set(world, pos.method_10103((x - dif) + j, y - dif, z + j), pick(random, FACES, 8));
                }
                else set(world, pos.method_10103((x - dif) + j, y - dif, z + j), pick(random, EDGES, 5));
            }
            for (int j = dif; j >= 1; j--) {
                if(i != 0) {
                set(world, pos.method_10103((x + dif) - j, y - dif, z - j), pick(random, FACES, 8));
                }
                else set(world, pos.method_10103((x + dif) - j, y - dif, z - j), pick(random, EDGES, 5));
            }
            for (int j = dif; j >= 1; j--) {
                if(i != 0) {
                set(world, pos.method_10103(x + j, y - dif, (z + dif) - j), pick(random, FACES, 8));
                }
                set(world, pos.method_10103(x + j, y - dif, (z + dif) - j), pick(random, EDGES, 5));
            }
            for (int j = dif; j >= 1; j--) {
                if(i != 0) {
                set(world, pos.method_10103(x - j, y - dif, (z - dif) + j), pick(random, FACES, 8));
                }
                set(world, pos.method_10103(x - j, y - dif, (z - dif) + j), pick(random, EDGES, 5));
            }
        }

        return true;
    }

    private static void set(net.minecraft.class_5281 world,
                            net.minecraft.class_2338 pos,
                            net.minecraft.class_2680 state) {
        var current = world.method_8320(pos);
        if (current.method_26215()) {
            world.method_8652(pos, state, net.minecraft.class_2248.field_31036);
        }
    }

    //my picker
    private static final net.minecraft.class_2680[] EDGES = new net.minecraft.class_2680[] {
            block_init.BLAJ_LESSER_ORE.method_9564(),
            block_init.BLAJ_ORE.method_9564()
    };

    private static final net.minecraft.class_2680[] FACES = new net.minecraft.class_2680[] {
            block_init.DARKNESS.method_9564(),
            block_init.BLAJ_LESSER_ORE.method_9564()
    };

    private static net.minecraft.class_2680 pick(net.minecraft.class_5819 rand, net.minecraft.class_2680[] State, int primary_weight) {
        int r = rand.method_43048(10);
        if (r < primary_weight) return State[0];
        return State[1];
    }

}


