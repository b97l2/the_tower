package mia.the_tower.initialisation.items;

import mia.the_tower.initialisation.item_init;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_4208;
import net.minecraft.class_9290;
import net.minecraft.class_9334;
import java.util.List;

public class DeathMarkerItem extends class_1792 {

    public DeathMarkerItem(class_1793 settings) {
        super(settings.method_7889(1)); // unstackable
    }

    /** Factory: build a marker with lore lines from a GlobalPos. */
    public static class_1799 of(net.minecraft.class_4208 pos) {
        class_1799 stack = new class_1799(item_init.FRAYED_NOTE); // change to your registry ref
        setLore(stack, pos);
        return stack;
    }

    /** Overwrite the lore to contain coords (line 0) and dimension id (line 1). */
    public static void setLore(class_1799 stack, class_4208 gp) {
        class_2338 p = gp.comp_2208();
        String dim = gp.comp_2207().method_29177().toString(); // e.g., "minecraft:overworld"

        // Line 0: coordinates; Line 1: dimension id (styled like your example)
        class_2561 line0 = class_2561.method_43470(p.method_10263() + ", " + p.method_10264() + ", " + p.method_10260()).method_27695(class_124.field_1062, class_124.field_1056);
        class_2561 line1 = class_2561.method_43470(dim).method_27695(class_124.field_1062, class_124.field_1056);

        stack.method_57379(class_9334.field_49632, new class_9290(List.of(line0, line1)));
    }
}