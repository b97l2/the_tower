package mia.the_tower.initialisation.items;

import mia.the_tower.initialisation.block_init;
import mia.the_tower.initialisation.item_init;
import mia.the_tower.initialisation.items.util.CofferToKey;
import mia.the_tower.initialisation.sounds.CustomSounds;
import net.minecraft.class_1264;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1935;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import java.util.Map;
import java.util.Set;

public class KeyItem extends class_1792 {
    private final class_1767 color;

    public KeyItem(class_1767 color, class_1792.class_1793 settings) { //you need to specify what colour the key is, like a dye item
        super(settings);
        this.color = color;
    }

    private static final Set<class_2248> COFFER_SET =
            Set.of(
                    block_init.SIMPLE_COFFER,//set of coffers
                    block_init.WHITE_COFFER,
                    block_init.ORANGE_COFFER,
                    block_init.MAGENTA_COFFER,
                    block_init.LIGHT_BLUE_COFFER,
                    block_init.YELLOW_COFFER,
                    block_init.LIME_COFFER,
                    block_init.PINK_COFFER,
                    block_init.GREY_COFFER,
                    block_init.LIGHT_GREY_COFFER,
                    block_init.CYAN_COFFER,
                    block_init.PURPLE_COFFER,
                    block_init.BLUE_COFFER,
                    block_init.BROWN_COFFER,
                    block_init.GREEN_COFFER,  //coloured_key -> coloured_coffer
                    block_init.RED_COFFER,
                    block_init.BLACK_COFFER
            );

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1937 world = context.method_8045();
        if (world.field_9236) return class_1269.field_5812;
        class_2338 position = context.method_8037();
        class_2680 clickedBlockState = world.method_8320(position);
        class_2248 clickedBlock = clickedBlockState.method_26204();
        class_1657 player = context.method_8036();

        class_2248 newCoffer = switch (color) { //choses the new coffer colour based on the colour of the key
                    case field_7952 -> block_init.WHITE_COFFER;
                    case field_7946 -> block_init.ORANGE_COFFER;
                    case field_7958 -> block_init.MAGENTA_COFFER;
                    case field_7951 -> block_init.LIGHT_BLUE_COFFER;
                    case field_7947 -> block_init.YELLOW_COFFER;
                    case field_7961 -> block_init.LIME_COFFER;
                    case field_7954 -> block_init.PINK_COFFER;
                    case field_7944 -> block_init.GREY_COFFER;
                    case field_7967 -> block_init.LIGHT_GREY_COFFER;
                    case field_7955 -> block_init.CYAN_COFFER;
                    case field_7945 -> block_init.PURPLE_COFFER;
                    case field_7966 -> block_init.BLUE_COFFER;
                    case field_7957 -> block_init.BROWN_COFFER;
                    case field_7942 -> block_init.GREEN_COFFER;  //coloured_key -> coloured_coffer
                    case field_7964 -> block_init.RED_COFFER;
                    case field_7963 -> block_init.BLACK_COFFER;
            default   -> null;
        };

        if(COFFER_SET.contains(clickedBlock)) { //checks whether the block clicked on is a coffer
            if(!world.method_8608()) {

                class_2680 newState = copyFacing(clickedBlockState, newCoffer.method_9564()); //copy facing direction of old coffer

                world.method_8652(position, newState, class_2248.field_31036);
                world.method_45447(null, context.method_8037(), class_3417.field_16865, class_3419.field_15245);

                if (player == null || !player.method_7337()) {
                    context.method_8041().method_7934(1); // <- this is the held stack (correct hand)
                }

                class_1935 drop = CofferToKey.keyForCoffer(clickedBlock);
                class_1799 stack = new class_1799(drop, 1);
                class_1264.method_5449(world, position.method_10263() + 0.5, position.method_10264() + 0.5, position.method_10260() + 0.5, stack);
                    // Alternatively: Block.dropStack(world, pos, stack);

            }
        }

        return class_1269.field_21466;
    }


    private static class_2680 copyFacing(class_2680 from, class_2680 to) {
        // Full 6-direction facing
        if (from.method_28498(class_2741.field_12481) && to.method_28498(class_2741.field_12481)) {
            return to.method_11657(class_2741.field_12481, from.method_11654(class_2741.field_12481));
        }
        // If the target doesn’t support a compatible facing property, leave defaults
        return to;
    }

}


