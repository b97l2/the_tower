package mia.the_tower.initialisation.items;

import mia.the_tower.initialisation.block.TwoBlockTallRod;
import mia.the_tower.initialisation.block_init; // <-- swap/remove if you use a different marker block
import mia.the_tower.initialisation.particle.CustomParticles;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_2709;
import net.minecraft.class_2756;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5321;
import net.minecraft.class_5819;
import net.minecraft.class_7924;
import net.minecraft.class_9290;
import net.minecraft.class_9334;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;

public class StaveItem extends class_1792 {

    // the_tower:the_frage world key
    private static final class_5321<class_1937> FRAGE_KEY =
            class_5321.method_29179(class_7924.field_41223, class_2960.method_60655("the_tower", "the_frage"));
    private static final class_5321<class_1937> OVERWORLD_KEY = class_1937.field_25179;

    public StaveItem(class_1793 settings) {
        super(settings);
    }

    // Show bow draw animation
    @Override
    public class_1839 method_7853(class_1799 stack) {
        return class_1839.field_8953;
    }

    // Charge time (ticks)
    @Override
    public int method_7881(class_1799 stack, class_1309 user) {
        return 65; //35 for full draw
    }

    // Start charging and block further "use block" handling
    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        user.method_6019(hand);

        if (!world.field_9236) {
            world.method_8396(null, user.method_24515(), class_3417.field_15044, class_3419.field_15248, 0.1f, 2.0f);
            //change to a stabbing sound effect
        }
        return class_1269.field_5812;
    }

    // Optional: visual/sound effects each tick while charging (correct 1.21.4 signature)
    @Override
    public void method_7852(class_1937 world, class_1309 user, class_1799 stack, int remainingUseTicks) {
        class_5819 random = world.method_8409();
        if (!world.field_9236 && world instanceof class_3218 sw) {
            CircleSpawn((class_3218) user.method_37908(), user, 2.5, 100, random); // 24 points, radius 1.5
            FlowerSpawn((class_3218) user.method_37908(), user, 0.45, 100, random);
            CrossSpawn((class_3218) user.method_37908(), user, 0.45, 50, random);
            SphereSpawn((class_3218) user.method_37908(), user, 5.5, 25, random);
            sw.method_65096(
                    class_2398.field_22247,
                    user.method_23317(),
                    user.method_23323(0.5),
                    user.method_23321(),
                    4,           // count
                    1.65, 2.35, 1.65, // position spread (x,y,z)
                    0.0          // speed
            );
        }
    }

    // If released early, do nothing (correct 1.21.4 signature)
    @Override
    public boolean method_7840(class_1799 stack, class_1937 world, class_1309 user, int remainingUseTicks) {
        return false; // no remainder/cooldown changes; we only act at full charge
    }

    // Called automatically when full charge time elapses
    @Override
    public class_1799 method_7861(class_1799 stack, class_1937 world, class_1309 user) {
        if (world.field_9236 || !(user instanceof class_3222 player)) return stack;

        final class_3218 currentWorld = player.method_51469();
        final class_5321<class_1937> currentDim = currentWorld.method_27983();
        final class_2338 here = player.method_24515();

        // --- Optional: place a marker block at the origin (guarded) ---
        try {
            // Replace with your own marker block or remove this whole section.
            world.method_8501(here, block_init.FRAGE_MARKER.method_9564().method_11657(TwoBlockTallRod.HALF, class_2756.field_12607));
            world.method_8501(here.method_10084(), block_init.FRAGE_MARKER.method_9564().method_11657(TwoBlockTallRod.HALF, class_2756.field_12609));
        } catch (Throwable ignored) {
            // If placement fails (non-replaceable, protection, etc.), ignore.
        }
        // ----------------------------------------------------------------

        // Lore layout:
        // line 0 -> last Overworld position (as "x y z")
        // line 1 -> last the_frage position (as "x y z")
        String overworldStr = null;
        String frageStr = null;

        class_9290 lore = stack.method_57824(class_9334.field_49632);
        if (lore != null) {
            if (lore.comp_2400().size() > 0) overworldStr = lore.comp_2400().get(0).getString();
            if (lore.comp_2400().size() > 1) frageStr     = lore.comp_2400().get(1).getString();
        }

        if (currentDim.equals(FRAGE_KEY)) {
            // We are in the_frage: save its marker (line 1) and go to Overworld
            frageStr = posToStr(here);
            saveLore(stack, overworldStr, frageStr);

            class_2338 target = (overworldStr != null && !overworldStr.isBlank())
                    ? strToPos(overworldStr)
                    : new class_2338(0, 100, 0); // fallback
            teleportAbsolute(player, OVERWORLD_KEY, target);
        } else {
            // We are in Overworld/other: save overworld marker (line 0) and go to the_frage
            overworldStr = posToStr(here);
            saveLore(stack, overworldStr, frageStr);

            class_2338 target = (frageStr != null && !frageStr.isBlank())
                    ? strToPos(frageStr)
                    : new class_2338(0, 120, 0); // fallback
            teleportAbsolute(player, FRAGE_KEY, target);
        }

        // -8 HP (4 hearts)
        player.method_64397(currentWorld, player.method_48923().method_48831(), 10.0f);

        return stack;
    }

    private void teleportAbsolute(class_3222 player, class_5321<class_1937> targetKey, class_2338 pos) {
        class_3218 targetWorld = player.method_5682().method_3847(targetKey);
        if (targetWorld == null) return;

        targetWorld.method_8501(pos, class_2246.field_10124.method_9564());

        Set<class_2709> flags = EnumSet.noneOf(class_2709.class); // absolute teleport
        player.method_48105(
                targetWorld,
                pos.method_10263() + 0.5,
                pos.method_10264(),
                pos.method_10260() + 0.5,
                flags,
                player.method_36454(),
                player.method_36455(),
                true // reset camera
        );

        targetWorld.method_8396(null, pos, class_3417.field_14879, class_3419.field_15248, 1.0f, 1.0f);
    }

    private void saveLore(class_1799 stack, String overworldStr, String frageStr) {
        class_2561 line0 = class_2561.method_43470(overworldStr != null ? overworldStr : "");
        class_2561 line1 = class_2561.method_43470(frageStr     != null ? frageStr     : "");
        stack.method_57379(class_9334.field_49632, new class_9290(List.of(line0, line1)));
    }

    private static String posToStr(class_2338 p) {
        return p.method_10263() + " " + p.method_10264() + " " + p.method_10260();
    }

    private static class_2338 strToPos(String s) {
        if (s == null) return new class_2338(0, 100, 0);
        String[] a = s.trim().split("\\s+");
        if (a.length != 3) return new class_2338(0, 100, 0);
        try {
            return new class_2338(Integer.parseInt(a[0]), Integer.parseInt(a[1]), Integer.parseInt(a[2]));
        } catch (NumberFormatException e) {
            return new class_2338(0, 100, 0);
        }
    }

// Call this on the SERVER side (ServerWorld), not client.
// points = how many particles around the ring
// radius = circle radius in blocks

    public static void CircleSpawn(class_3218 sw, class_1309 user, double radius, int points, class_5819 random) {
        // Foot height; bump a bit so it doesn't z-fight with the ground
        double y = user.method_23323(0.0) + 0.15;


        for (int i = 0; i < points; i++) {
            double angle = ((2.0 + random.method_43057()*2) * Math.PI * i ) + 0.001 / points;
            double x = user.method_23317() + radius * Math.cos(angle); //* random.nextTriangular(1, 1.3f);
            double z = user.method_23321() + radius * Math.sin(angle); //* random.nextTriangular(1, 1.3f);

            // count=1, no spread, no speed => exact placement
            sw.method_65096(
                    CustomParticles.EMBERS_OF_THE_FRAGE, // your particle type
                    x, y, z,
                    1,          // count
                    0.0, 0.0, 0.0, // position spread (x,y,z)
                    0.0         // speed
            );
        }
    }

    public static void FlowerSpawn(class_3218 sw, class_1309 user, double radius, int points, class_5819 random) {
        // Foot height; bump a bit so it doesn't z-fight with the ground
        double y = user.method_23323(0.0) + 0.15;


        for (int i = 0; i < points; i++) {
            double angle = ((2.0 + random.method_43057()*2) * Math.PI * i ) + 0.001 / points;
            double x = user.method_23317() + radius * 1/Math.cos(angle); //* random.nextTriangular(1, 1.3f);
            double z = user.method_23321() + radius * 1/Math.sin(angle); //* random.nextTriangular(1, 1.3f);

            sw.method_65096(
                    CustomParticles.EMBERS_OF_THE_FRAGE, // my particle type
                    x, y, z,
                    1,          // count
                    0.0, 0.0, 0.0, // position spread (x,y,z)
                    0.0         // speed
            );
        }
    }

    public static void CrossSpawn(class_3218 sw, class_1309 user, double radius, int points, class_5819 random) {
        // Foot height; bump a bit so it doesn't z-fight with the ground
        double y = user.method_23323(0.0) + 0.15;


        for (int i = 0; i < points; i++) {
            double angle = ((45 * (Math.PI/180) * i ));
            double x = user.method_23317() + radius * Math.cos(angle); //* random.nextTriangular(1, 1.3f);
            double z = user.method_23321() + radius * Math.sin(angle); //* random.nextTriangular(1, 1.3f);
            radius = radius + random.method_62816(0, 1.2f); //random.nextFloat()/10;

            sw.method_65096(
                    CustomParticles.EMBERS_OF_THE_FRAGE, // my particle type
                    x, y, z,
                    1,          // count
                    0.0, 0.0, 0.0, // position spread (x,y,z)
                    0.0         // speed
            );
        }
    }

    public static void SphereSpawn(class_3218 sw, class_1309 user, double radius, int points, class_5819 random) {
        // Foot height; bump a bit so it doesn't z-fight with the ground
        //double y = user.getBodyY(0.0) + 0.15;


        for (int i = 0; i < points; i++) {
            double angle = ((2.0 + random.method_43057()*2) * Math.PI * i ) + 0.001 / points;
            double y = user.method_23318() + radius * Math.tan(angle) + 3; //* random.nextTriangular(1, 1.3f);
            double x = user.method_23317() - radius * Math.cos(angle)*Math.sin(angle); //* random.nextTriangular(1, 1.3f);
            double z = user.method_23321() - radius * Math.sin(angle)*Math.sin(angle); //* random.nextTriangular(1, 1.3f);

            // count=1, no spread, no speed => exact placement
            sw.method_65096(
                    CustomParticles.STAVE_PARTICLE, // your particle type
                    x, y, z,
                    1,          // count
                    0.0, 0.0, 0.0, // position spread (x,y,z)
                    0.0         // speed
            );

            z = user.method_23321() - radius * Math.cos(angle)*Math.sin(angle); //* random.nextTriangular(1, 1.3f);
            x = user.method_23317() - radius * Math.sin(angle)*Math.sin(angle); //* random.nextTriangular(1, 1.3f);
            sw.method_65096(
                    CustomParticles.STAVE_PARTICLE,
                    x, y, z,
                    1,          // count
                    0.0, 0.0, 0.0, // position spread (x,y,z)
                    0.0         // speed
            );

            x = (user.method_23317() + radius * Math.cos(angle)*Math.sin(angle)); //* random.nextTriangular(1, 1.3f);
            z = user.method_23321() + radius * Math.sin(angle)*Math.sin(angle); //* random.nextTriangular(1, 1.3f);
            sw.method_65096(
                    CustomParticles.STAVE_PARTICLE,
                    x, y, z,
                    1,          // count
                    0.0, 0.0, 0.0, // position spread (x,y,z)
                    0.0         // speed
            );

            z = (user.method_23321() + radius * Math.cos(angle)*Math.sin(angle)); //* random.nextTriangular(1, 1.3f);
            x = user.method_23317() + radius * Math.sin(angle)*Math.sin(angle); //* random.nextTriangular(1, 1.3f);
            sw.method_65096(
                    CustomParticles.STAVE_PARTICLE,
                    x, y, z,
                    1,          // count
                    0.0, 0.0, 0.0, // position spread (x,y,z)
                    0.0         // speed
            );
        }
    }

}
