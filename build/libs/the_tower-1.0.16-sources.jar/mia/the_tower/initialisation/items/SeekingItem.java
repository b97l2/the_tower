package mia.the_tower.initialisation.items;


import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2394;
import net.minecraft.class_2561;
import net.minecraft.class_3218;

public class SeekingItem extends class_1792 {

    private final class_2248 targetBlock;
    private final class_2394 customParticle;

    private static final int H_RADIUS = 64;
    private static final int V_RADIUS = 64;

    //higher = slower
    private static final double GENERAL_SPEED = 25;

    public SeekingItem(class_2248 targetBlock,
                                                class_2394 customParticle,
                                                class_1793 settings) {
        super(settings);
        this.targetBlock = targetBlock;
        this.customParticle = customParticle;
    }

    @Override
    public void method_59978(class_1799 stack, class_1309 target, class_1309 attacker) {
        stack.method_7970(2, attacker, class_1304.field_6173);
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);

        if (!(world instanceof class_3218 serverWorld)) {
            return class_1269.field_5812;
        }

        class_2338 origin = user.method_24515();

        Optional<class_2338> nearest = class_2338.method_25997(
                origin,
                H_RADIUS,
                V_RADIUS,
                pos -> serverWorld.method_8320(pos).method_27852(this.targetBlock)
        );

        if (nearest.isEmpty()) {
            user.method_7353(class_2561.method_43470("The rod is still..."), true);
            return class_1269.field_5812;
        }

        class_2338 target = nearest.get();

        // Source: player eyes
        double sx = user.method_23317();
        double sy = user.method_23318() + user.method_5751();
        double sz = user.method_23321();

        // Destination: center of the target block
        double tx = target.method_10263() + 0.5;
        double ty = target.method_10264() + 0.5;
        double tz = target.method_10260() + 0.5;

        double dx = tx - sx;
        double dy = ty - sy;
        double dz = tz - sz;

        //calculating the unit vector so the velocity is constant
        double hypot = Math.sqrt(Math.pow(dx, 2) + Math.pow(dy, 2) + Math.pow(dz, 2));
        double unitx = dx / hypot;
        double unity = dy / hypot;
        double unitz = dz / hypot;

        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (dist < 1.0e-6) {
            // Edge case: player is inside/at target; nudge upwards
            dy = 0.05;
            dist = 0.05;
        }

        /*
         * Spawn ONE particle with an explicit velocity.
         * In the particles packet, when count == 0 the offset arguments are treated as velocity,
         * multiplied by the "extra/speed" parameter. We pass speed = 1.0 to keep vx/vy/vz exact.
         */
        serverWorld.method_65096(
                this.customParticle,
                sx, sy, sz,
                0,          // <-- single particle with explicit velocity semantics
                unitx/GENERAL_SPEED, unity/GENERAL_SPEED, unitz/GENERAL_SPEED, // <-- velocity components
                1.0         // <-- speed/extra multiplier (keep at 1.0)
        );

        class_1304 equipmentSlot = stack.equals(user.method_6118(class_1304.field_6171)) ? class_1304.field_6171 : class_1304.field_6173;
        stack.method_7970(1, user, equipmentSlot);

        return class_1269.field_5812;
    }
}
