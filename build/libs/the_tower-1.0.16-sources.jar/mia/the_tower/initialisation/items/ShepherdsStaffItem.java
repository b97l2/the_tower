package mia.the_tower.initialisation.items;

import mia.the_tower.initialisation.particle.CustomParticles;
import mia.the_tower.initialisation.sounds.CustomSounds;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3419;
import net.minecraft.class_5819;
import net.minecraft.util.*;
import java.util.List;

public class ShepherdsStaffItem extends class_1792 {

    public ShepherdsStaffItem(class_1793 settings) {
        super(settings);
    }

    // Use time (ticks)
    @Override
    public int method_7881(class_1799 stack, class_1309 user) {
        return 1000;
    }

    /*
    @Override
    public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        if (world.isClient) return;                        // spawn on server for multiplayer visibility
        if (!(entity instanceof PlayerEntity player)) return;

        // Figure out if THIS stack is in a hand, and which one.
        Hand hand = null;

        // Main hand: also check 'selected' so we don't fire when it's in the hotbar but not active.
        if (player.getMainHandStack() == stack && selected) {
            hand = Hand.MAIN_HAND;
        }

        // Off-hand has no 'selected' flag; it's either held or not.
        if (player.getOffHandStack() == stack) {
            hand = Hand.OFF_HAND;
        }

        if (hand == null) return;                          // not held → no hand to use

        // Simple rate limit so we don't spawn every tick (tweak 3–5 as you like)
        if (((world.getTime() + entity.getId()) % 4) != 0) return;

        spawnHeldTipParticles(player, hand, (ServerWorld) world);
    }

     */



    /** Hand-relative particle placement. */
    /*
    private static void spawnHeldTipParticles(PlayerEntity player, Hand hand, ServerWorld world) {
        // Base at eye height minus a bit so the tip sits near the held item
        Vec3d base = player.getPos().add(0, player.getStandingEyeHeight() - 0.2, 0);

        // Build a forward/right/up basis from the player's yaw/pitch
        float yawRad = (float) Math.toRadians(player.getYaw());
        float pitchRad = (float) Math.toRadians(player.getPitch());

        Vec3d forward = new Vec3d(
                -Math.sin(yawRad) * Math.cos(pitchRad),
                Math.sin(pitchRad),
                Math.cos(yawRad) * Math.cos(pitchRad)
        );
        Vec3d right = new Vec3d(forward.z, 0, -forward.x).normalize();
        Vec3d up = right.crossProduct(forward).normalize();

        // Left/right hand swap: "is this physical right hand?"
        boolean physicalRightHand = (hand == Hand.MAIN_HAND) == (player.getMainArm() == Arm.RIGHT);

        // Tune these three numbers for your 3D model so the tip lines up.
        double lateral = physicalRightHand ? 0.28 : -0.28; // left/right from center
        double forwardOff = 0.55;                           // in front of the player
        double upOff = -0.20;                               // up/down

        // Small pose tweaks
        if (player.isSneaking()) upOff -= 0.07;
        if (player.isSprinting()) forwardOff += 0.05;

        Vec3d tip = base
                .add(right.multiply(lateral))
                .add(forward.multiply(forwardOff))
                .add(up.multiply(upOff));

        world.spawnParticles(
                CustomParticles.GLUH_PARTICLE,     // replace with your particle type
                tip.x, tip.y, tip.z,
                2,                              // count
                0.0, 0.0, 0.0,                  // spread
                0.0                             // speed
        );
    }
    */

    // Start charging and block further "use block" handling
    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        user.method_6019(hand);

        if (!world.field_9236) {
            world.method_8396(null, user.method_24515(), CustomSounds.SHEPHERDS_STAFF_USE, class_3419.field_15248, 1.0f, 1.0f);
        }
        return class_1269.field_5812;
    }

    // Optional: visual/sound effects each tick while charging (correct 1.21.4 signature)
    @Override
    public void method_7852(class_1937 world, class_1309 user, class_1799 stack, int remainingUseTicks) {
        class_5819 random = world.method_8409();
        if (!world.field_9236 && world instanceof class_3218 sw) {
            CircleSpawn((class_3218) user.method_37908(), user, 6.5, 35, random); // 24 points, radius 1.5
        }
    }

    @Override
    @Environment(EnvType.CLIENT)
    public void method_7851(class_1799 stack,
                              class_9635 context,
                              List<class_2561> tooltip,
                              class_1836 type) {
        // Simple literal line
        tooltip.add(class_2561.method_43470("Happiness can be found even in the ").method_27695(class_124.field_1080, class_124.field_1056));
        tooltip.add(class_2561.method_43470("darkest of times, if one only remembers ").method_27695(class_124.field_1080, class_124.field_1056));
        tooltip.add(class_2561.method_43470("to turn on the light.").method_27695(class_124.field_1080, class_124.field_1056));

        // Or use a translatable key from your lang file:
        // tooltip.add(Text.translatable("item.the_tower.your_item.lore").formatted(Formatting.GRAY));
    }

// Call this on the SERVER side (ServerWorld), not client.
// points = how many particles around the ring
// radius = circle radius in blocks

    public static void CircleSpawn(class_3218 sw, class_1309 user, double radius, int points, class_5819 random) {
        // Foot height; bump a bit so it doesn't z-fight with the ground
        double y = user.method_23323(0.0) + 2.85 + Math.abs(random.method_62816(0, 1.7f));


        for (int i = 0; i < points; i++) {
            double radius2 = radius * random.method_43058();
            double angle = ((2.0 + random.method_43058()*2) * Math.PI * i ) / points;
            double x = user.method_23317() + radius2 * Math.cos(angle) * random.method_62816(1, 1.3f);
            double z = user.method_23321() + radius2 * Math.sin(angle) * random.method_62816(1, 1.3f);

            // count=1, no spread, no speed => exact placement
            sw.method_65096(
                    CustomParticles.WHITE_INCENSE, // your particle type
                    x, y, z,
                    1,          // count
                    0.0, 0.0, 0.0, // position spread (x,y,z)
                    0.0         // speed
            );
        }
    }
}
