package mia.the_tower.initialisation.items;

import mia.the_tower.initialisation.block_init;
import mia.the_tower.initialisation.sounds.CustomSounds;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5281;
import net.minecraft.class_5819;

public class PillarOfSaltItem extends class_1792 {

    public PillarOfSaltItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        user.method_6019(hand);


        if (world.field_9236) {
            return class_1269.field_5812;
        }

        class_3218 server = (class_3218) world;

        // play to everyone from server
        world.method_8396(null, user.method_24515(), class_3417.field_15074, class_3419.field_15248, 1.0f, 0.6f);

        // 64-block raycast; include fluids? true here
        var hit = user.method_5745(64.0, 0.0F, true);
        if (!(hit instanceof net.minecraft.class_3965 bhr )) {
            return class_1269.field_5814;
        }
        if (hit.method_17783() != class_239.class_240.field_1332) {
            return class_1269.field_5814;
        }

        class_2338 spawnAt = bhr.method_17777().method_10093(bhr.method_17780());
        boolean ok = buildAt(server, spawnAt);

        return ok ? class_1269.field_5812 : class_1269.field_5814;
    }


    public static boolean buildAt(class_3218 world, class_2338 origin) {
        class_5819 random = world.method_8409();

        int height = random.method_39332(3, 25);
        int x = origin.method_10263();
        int z = origin.method_10260();
        int y = origin.method_10264();
        double divisor = random.method_43385(2, 0.3);
        int count = 0;
        double mode = 1.7; //this is to dictate how fast the pillar decreases in size. It should always be above 1, lest the salt expands infinitely
                            // 1.7 is a good value for the item
                            // 1.1 is a good value for the biome feature
        var pos = new class_2338.class_2339();

        setAndBellow(world, pos.method_10103(x, y+height, z), SALT); //sets primary column
        while(height >0){
            count++;
            setAndBellow(world, pos.method_10103(x-count, (int) (height/divisor) + y, z), SALT); //sets secondary columns with new height division each time
            divisor = random.method_43385(mode, 0.3);

            setAndBellow(world, pos.method_10103(x+count, (int) (height/divisor) + y, z), SALT);
            divisor = random.method_43385(mode, 0.3);

            setAndBellow(world, pos.method_10103(x, (int) (height/divisor) + y, z-count), SALT);
            divisor = random.method_43385(mode, 0.3);

            setAndBellow(world, pos.method_10103(x, (int) (height/divisor) + y, z+count), SALT);
            divisor = random.method_43385(mode, 0.3);

            height = (int) (height/divisor); //to update to a smaller height for the next tier

            //this is to generate salt "noise" around the base so it is not just a cross in shape
            for(int i = count-1; i > 0; i--){
                int dif = count - 1 - i;
                divisor = random.method_43385(mode+dif, 0.3); // (-, +) axis
                setAndBellow(world, pos.method_10103(x-(count-1), (int) (height/divisor) + y - 1, z+i), SALT);
                setAndBellow(world, pos.method_10103(x-i, (int) (height/divisor) + y - 1, z+count-1), SALT);


                divisor = random.method_43385(mode+dif, 0.3); // (-, -) axis
                setAndBellow(world, pos.method_10103(x-(count-1), (int) (height/divisor) + y - 1, z-i), SALT);
                setAndBellow(world, pos.method_10103(x-i, (int) (height/divisor) + y - 1, z-(count-1)), SALT);

                divisor = random.method_43385(mode+dif, 0.3); // (+, +) axis
                setAndBellow(world, pos.method_10103(x+count-1, (int) (height/divisor) + y - 1, z+i), SALT);
                setAndBellow(world, pos.method_10103(x+i, (int) (height/divisor) + y - 1, z+count-1), SALT);

                divisor = random.method_43385(mode+dif, 0.3); // (+, -) axis
                setAndBellow(world, pos.method_10103(x+count-1, (int) (height/divisor) + y - 1, z-i), SALT);
                setAndBellow(world, pos.method_10103(x+i, (int) (height/divisor) + y - 1, z-(count-1)), SALT);
            }

            divisor = random.method_43385(mode, 0.3); //ready for the next round
        }
        return true;
    }

    private static void setAndBellow(class_5281 world,
                            class_2338 pos,
                            class_2680 state) {
        class_2338.class_2339 pos1 = pos.method_25503();
        var current = world.method_8320(pos);

        while(current.method_26215()) {
            world.method_8652(pos1, state, class_2248.field_31036);
            pos1.method_10098(class_2350.field_11033);
            current = world.method_8320(pos1);
        }
    }

    //my picker
    private static final class_2680 SALT = block_init.SALT.method_9564();

}





