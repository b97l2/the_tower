package mia.the_tower.initialisation.carver;

import org.apache.commons.lang3.mutable.MutableBoolean;

import java.util.function.Function;
import net.minecraft.class_1923;
import net.minecraft.class_1959;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2791;
import net.minecraft.class_2902;
import net.minecraft.class_2939;
import net.minecraft.class_3532;
import net.minecraft.class_5819;
import net.minecraft.class_5873;
import net.minecraft.class_6350;
import net.minecraft.class_6643;
import net.minecraft.class_6880;

public class PitCarver extends class_2939<PitCarverConfig> {

    public PitCarver() {
        super(PitCarverConfig.DIRECT_CODEC); // Carver wants a Codec<C>
    }

    @Override
    public boolean shouldCarve(PitCarverConfig cfg, class_5819 random) {
        return random.method_43057() < cfg.field_13738; // from ProbabilityConfig
    }

    @Override
    public boolean carve(
            class_5873 context,
            PitCarverConfig cfg,
            class_2791 chunk,
            Function<class_2338, class_6880<class_1959>> posToBiome,
            class_5819 random,
            class_6350 aquiferSampler,
            class_1923 chunkPos,
            class_6643 mask
    ) {
        if (!shouldCarve(cfg, random)) return false;

        // Choose a center somewhere inside this chunk
        int xCenter = chunkPos.method_8326() + random.method_43048(16);
        int zCenter = chunkPos.method_8328() + random.method_43048(16);
        int lx = xCenter & 15;
        int lz = zCenter & 15;

        // Anchor the rim near the surface at this column
        int surfaceY = chunk.method_12032(class_2902.class_2903.field_13194).method_12603(lx, lz);

        // Sample a start Y from the config, then clamp near the surface so the opening is visible
        int startY = class_3532.method_15340(cfg.field_31488.method_35391(random, context), surfaceY - 7, surfaceY + 4);

        int depth = Math.max(1, cfg.depth.method_35008(random));
        int baseRadius = Math.max(1, cfg.radius.method_35008(random));
        int taper = Math.max(1, cfg.taperHeight.method_35008(random));
        int bottomY = Math.max(context.method_30462() + 1, startY - depth);

        boolean carvedAny = false;

        // Small horizontal wobble so the shaft isn't perfectly straight
        float driftX = 0f, driftZ = 0f;

        class_2338.class_2339 pos = new class_2338.class_2339();
        class_2338.class_2339 tmp = new class_2338.class_2339();
        MutableBoolean replacedGrassy = new MutableBoolean(false);

        for (int y = startY; y >= bottomY; --y) {
            int dy = startY - y;

            // Smoothly grow radius over the first `taper` layers (sloped rim)
            float t = class_3532.method_15363(dy / (float) taper, 0f, 1f);
            float smooth = t * t * (3f - 2f * t); // smoothstep

            int layerJitter = cfg.radiusJitter.method_35008(random);
            float radiusAtY = Math.max(0f, smooth * (baseRadius + layerJitter));
            int rInt = class_3532.method_15375(radiusAtY);

            driftX += (random.method_43057() - 0.5f) * cfg.horizontalJitterPerY.method_33920(random);
            driftZ += (random.method_43057() - 0.5f) * cfg.horizontalJitterPerY.method_33920(random);

            int x0 = class_3532.method_15375(xCenter + driftX);
            int z0 = class_3532.method_15375(zCenter + driftZ);
            int r2 = rInt * rInt;

            for (int dx = -rInt; dx <= rInt; dx++) {
                int xx = x0 + dx;
                int llx = xx & 15;
                for (int dz = -rInt; dz <= rInt; dz++) {
                    if (dx*dx + dz*dz > r2) continue;

                    int zz = z0 + dz;
                    int llz = zz & 15;
                    pos.method_10103(xx, y, zz);

                    // skip if this local voxel was carved already
                    if (mask.method_38868(llx, y, llz)) continue;

                    // Hand off to base logic: handles replaceables
                    if (this.method_16581(context, cfg, chunk, posToBiome, mask, pos, tmp, aquiferSampler, replacedGrassy)) {
                        chunk.method_12010(pos, class_2246.field_10543.method_9564(), false);
                        carvedAny = true;
                    }
                }
            }
        }

        return carvedAny;
    }


}
