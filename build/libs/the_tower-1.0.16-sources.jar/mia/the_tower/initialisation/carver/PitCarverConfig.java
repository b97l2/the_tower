package mia.the_tower.initialisation.carver;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2248;
import net.minecraft.class_5843;
import net.minecraft.class_5863;
import net.minecraft.class_5871;
import net.minecraft.class_5872;
import net.minecraft.class_6017;
import net.minecraft.class_6122;
import net.minecraft.class_6885;


/**
 * Extends CarverConfig to satisfy Carver<C extends CarverConfig>.
 * We reuse the parent fields (probability, y, yScale, lavaLevel, debugConfig, replaceable)
 * and add our own.
 */


public class PitCarverConfig extends class_5871 {

    public static final MapCodec<PitCarverConfig> CODEC = RecordCodecBuilder.mapCodec(inst -> inst.group(
            class_5871.field_29054.forGetter(c -> c),
            // Custom fields
            class_6017.field_29946.fieldOf("radius").forGetter(c -> c.radius),
            class_6017.field_29946.fieldOf("depth").forGetter(c -> c.depth),
            class_6017.field_29946.fieldOf("taper_height").forGetter(c -> c.taperHeight),
            class_6017.field_29946.fieldOf("radius_jitter").forGetter(c -> c.radiusJitter),
            class_5863.field_29007.fieldOf("horizontal_jitter_per_y").forGetter(c -> c.horizontalJitterPerY)
    ).apply(inst, (base, radius, depth, taper, jitter, hJitter) ->
            new PitCarverConfig(
                    base.field_13738, base.field_31488, base.field_31489, base.field_31490, base.field_29053, base.field_38864,
                    radius, depth, taper, jitter, hJitter
            )
    ));

    // Expose a plain Codec for the Carver constructor
    public static final Codec<PitCarverConfig> DIRECT_CODEC = CODEC.codec();

    public final class_6017 radius;
    public final class_6017 depth;
    public final class_6017 taperHeight;
    public final class_6017 radiusJitter;
    public final class_5863 horizontalJitterPerY;

    public PitCarverConfig(
            float probability,
            class_6122 y,
            class_5863 yScale,
            class_5843 lavaLevel,
            class_5872 debugConfig,
            class_6885<class_2248> replaceable,
            class_6017 radius,
            class_6017 depth,
            class_6017 taperHeight,
            class_6017 radiusJitter,
            class_5863 horizontalJitterPerY
    ) {
        super(probability, y, yScale, lavaLevel, debugConfig, replaceable);
        this.radius = radius;
        this.depth  = depth;
        this.taperHeight = taperHeight;
        this.radiusJitter = radiusJitter;
        this.horizontalJitterPerY = horizontalJitterPerY;
    }


}


