package mia.the_tower.initialisation.carver;

import net.minecraft.class_2378;
import net.minecraft.class_2922;
import net.minecraft.class_2939;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.registry.*;

public final class ModCarvers {

    // Single source of truth for the id
    public static final class_2960 PIT_ID = class_2960.method_60655("the_tower", "pit_carver");

    // Register the CARVER TYPE with its CODEC
    public static final class_2939<PitCarverConfig> PIT_CARVER =
            class_2378.method_10230(class_7923.field_41143, PIT_ID, new PitCarver());

    // Key that points to your JSON-configured carver: data/the_tower/worldgen/configured_carver/pit_carver.json
    public static final class_5321<class_2922<?>> PIT_CARVER_KEY =
            class_5321.method_29179(class_7924.field_41238, PIT_ID);

    public static void load(){}
}

