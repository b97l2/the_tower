package mia.the_tower.initialisation.world;

import net.minecraft.class_2960;
import net.minecraft.class_3031;
import net.minecraft.class_3111;
import net.minecraft.class_5321;
import net.minecraft.class_7891;
import net.minecraft.class_7924;

public class features_init {
    //for registering my custom features


    public static final class_5321<class_3031<?>> BLAJ_FEATURE_KEY =
            class_5321.method_29179(class_7924.field_41267, class_2960.method_60655("the_tower", "blaj_feature"));

    public static final class_3031<class_3111> BLAJ_FEATURE = new BlajFeature(); // your Feature subclass

    // Called by your RegistryBuilder / bootstrap wiring
    public static void bootstrap(class_7891<class_3031<?>> ctx) {
        ctx.method_46838(BLAJ_FEATURE_KEY, BLAJ_FEATURE);
    }


}
