package mia.the_tower.initialisation.world.tree;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2378;
import net.minecraft.class_2465;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import net.minecraft.class_3532;
import net.minecraft.class_3746;
import net.minecraft.class_4643;
import net.minecraft.class_4647.class_5208;
import net.minecraft.class_5141;
import net.minecraft.class_5142;
import net.minecraft.class_5819;
import net.minecraft.class_7923;

import static mia.the_tower.The_Tower.id;

//honestly I just let chatgpt have fun on this one, it is not optimised in any way, but it looks very cool
//that's all I really wanted

public class MediumTrunkPlacer extends class_5141 {
    // Extra params for taper & flare.
    private final float baseRadius;
    private final float topRadius;
    private final float taperPower;
    private final float flareSigma;
    private final float shellThicknessBlocks;  // 2 near base, tapers to ~1 near top
    private final float snakeAccelScale;      // random “accel” magnitude per layer
    private final float snakeDamping;         // velocity damping
    private final float snakeMaxOffset;

    public static final MapCodec<MediumTrunkPlacer> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            Codec.intRange(1, 128).fieldOf("base_height").forGetter(p -> p.field_23760),
            Codec.intRange(0, 128).fieldOf("height_rand_a").forGetter(p -> p.field_23761),
            Codec.intRange(0, 128).fieldOf("height_rand_b").forGetter(p -> p.field_23762),
            Codec.FLOAT.fieldOf("base_radius").forGetter(p -> p.baseRadius),
            Codec.FLOAT.fieldOf("top_radius").forGetter(p -> p.topRadius),
            Codec.FLOAT.fieldOf("taper_power").forGetter(p -> p.taperPower),
            Codec.FLOAT.fieldOf("flare_sigma").forGetter(p -> p.flareSigma),
            Codec.FLOAT.fieldOf("shell_thickness_blocks").forGetter(p -> p.shellThicknessBlocks),
            Codec.FLOAT.fieldOf("snake_accel_scale").forGetter(p -> p.snakeAccelScale),
            Codec.FLOAT.fieldOf("snake_damping").forGetter(p -> p.snakeDamping),
            Codec.FLOAT.fieldOf("snake_max_offset").forGetter(p -> p.snakeMaxOffset)
    ).apply(instance, MediumTrunkPlacer::new));

    public MediumTrunkPlacer(int baseHeight, int randomHeightA, int randomHeightB,
                             float baseRadius, float topRadius, float taperPower,
                             float flareSigma, float shellThicknessBlocks, float snakeAccelScale, float snakeDamping,
                             float snakeMaxOffset) {
        super(baseHeight, randomHeightA, randomHeightB);
        this.baseRadius = baseRadius;
        this.topRadius = topRadius;
        this.taperPower = taperPower;
        this.flareSigma = flareSigma;
        this.shellThicknessBlocks = shellThicknessBlocks;
        this.snakeAccelScale = snakeAccelScale;
        this.snakeDamping = snakeDamping;
        this.snakeMaxOffset = snakeMaxOffset;
    }

    public static final class_5142<MediumTrunkPlacer> MEDIUM_TRUNK =
            class_2378.method_10230(class_7923.field_41151,
                    id("medium_trunk"),
                    new class_5142<>(MediumTrunkPlacer.CODEC));

    public static void init() {}

    @Override
    protected class_5142<?> method_28903() {
        return MEDIUM_TRUNK; // register this
    }

    @Override
    public List<class_5208> method_26991(class_3746 world,
                                            BiConsumer<class_2338, class_2680> replacer,
                                            class_5819 random,
                                            int height,
                                            class_2338 startPos,
                                            class_4643 config) {
        List<class_5208> attachments = new ArrayList<>();
        class_2338.class_2339 m = new class_2338.class_2339();

        // Snaking centerline state
        float cx = 0f, cz = 0f;
        float vx = 0f, vz = 0f;

        // Keep per-layer centers and radii for later decoration/branches
        int[] centerX = new int[height + 2];
        int[] centerZ = new int[height + 2];
        float[] outerR = new float[height + 2];
        float[] innerR = new float[height + 2];

        //for chunk window
        class_1923 origin = new class_1923(startPos);
        GiantFoliagePlacer.CURRENT_TREE_ORIGIN.set(origin);

        // 1) Build hollow, snaking trunk
        for (int y = 0; y < height; y++) {
            float t = (float) y / (float) height;

            // Smooth random walk for the center
            vx = vx * snakeDamping + (random.method_43057() - 0.5f) * snakeAccelScale;
            vz = vz * snakeDamping + (random.method_43057() - 0.5f) * snakeAccelScale;
            cx += vx;
            cz += vz;

            // Clamp offset
            float offLen = class_3532.method_15355(cx * cx + cz * cz);
            if (offLen > snakeMaxOffset) {
                float s = snakeMaxOffset / offLen;
                cx *= s; cz *= s;
            }

            int cxi = startPos.method_10263() + Math.round(cx);
            int czi = startPos.method_10260() + Math.round(cz);
            int cy  = startPos.method_10264() + y;

            float core = class_3532.method_16439((float)Math.pow(t, this.taperPower), this.baseRadius, this.topRadius);
            //the variable of the devil, I am ignoring it because it causes more trouble than what it is worth
            float flareAmplitude = 0;
            float flare = flareAmplitude * (float) Math.exp(-(y * y) / (2f * this.flareSigma * this.flareSigma));
            float rOuter = Math.max(1.0f, core + flare);

            // Thickness tapers slightly with height
            float thick = class_3532.method_16439(t, shellThicknessBlocks, 1.0f);
            float rInner = Math.max(0.0f, rOuter - thick);

            centerX[y] = cxi;
            centerZ[y] = czi;
            outerR[y] = rOuter;
            innerR[y] = rInner;

            int r = class_3532.method_15386(rOuter) + 1;
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    float d2 = dx * dx + dz * dz;
                    // shell region
                    if (d2 <= rOuter * rOuter && d2 > rInner * rInner) {
                        m.method_10103(cxi + dx, cy, czi + dz);
                        if (method_43196(world, m)) {
                            class_2680 log = config.field_21288.method_23455(random, m)
                                    .method_11657(class_2465.field_11459, class_2350.class_2351.field_11052);
                            replacer.accept(m, log);
                        }
                    }
                    // carve interior
                    else if (d2 < rInner * rInner) {
                        m.method_10103(cxi + dx, cy, czi + dz);
                        // Don’t accidentally break liquids/bedrock; basic guard:
                        if (isCarvable(world, m)) {
                            replacer.accept(m, class_2246.field_10124.method_9564());
                        }
                    }
                }
            }
        }

        // Top cap (sealed)
        int topY = startPos.method_10264() + height;
        int cxi = centerX[Math.max(0, height - 1)];
        int czi = centerZ[Math.max(0, height - 1)];
        float rCap = Math.max(1.0f, outerR[Math.max(0, height - 1)] * 0.8f);
        int rC = class_3532.method_15386(rCap);
        for (int dx = -rC; dx <= rC; dx++) {
            for (int dz = -rC; dz <= rC; dz++) {
                if (dx * dx + dz * dz <= rCap * rCap) {
                    m.method_10103(cxi + dx, topY, czi + dz);
                    if (method_43196(world, m)) {
                        class_2680 log = config.field_21288.method_23455(random, m)
                                .method_11657(class_2465.field_11459, class_2350.class_2351.field_11052);
                        replacer.accept(m, log);
                    }
                }
            }
        }

        // 2) Branches from curved centerline
        int branchCount = 5 + random.method_43048(4);
        int minY = height / 2;
        for (int i = 0; i < branchCount; i++) {
            int y = minY + random.method_43048(Math.max(1, height - minY - 4));
            int bx = centerX[y], bz = centerZ[y];  // branch base follows the snake
            float rHere = Math.max(1.0f, outerR[y] * 0.55f);

            double theta = random.method_43058() * Math.PI * 2.0;
            double pitch = class_3532.method_16439(random.method_43057(), 0.70f, 0.90f); //gouverns the angle the branch makes
            int len = class_3532.method_15375(6 + rHere * 2 + random.method_43057() * 3); //gouverns the length of the branches, I changed the constants (2 and 3)

            int sx = bx + (int) Math.round(Math.cos(theta) * (rHere + 1));
            int sz = bz + (int) Math.round(Math.sin(theta) * (rHere + 1));
            int sy = startPos.method_10264() + y;

            int ex = sx + (int) Math.round(Math.cos(theta) * len);
            int ez = sz + (int) Math.round(Math.sin(theta) * len);
            int ey = sy + (int) Math.round(len * pitch);

            drawBranch(world, replacer, random, new class_2338(sx, sy, sz), new class_2338(ex, ey, ez),
                    class_3532.method_15340(class_3532.method_15375(rHere), 1, 3), config);

            // foliage at end
            attachments.add(new class_5208(new class_2338(ex, ey, ez), 0, false));

        }

        // 5) Crown foliage anchor at top
        attachments.add(new class_5208(new class_2338(cxi, topY, czi), 0, false));
        return attachments;

    }


    private boolean isCarvable(class_3746 world, class_2338 pos) {
        // Be stricter than isReplaceable: don’t nuke water/lava/bedrock
        return this.method_43196(world, pos);
    }


    private void drawBranch(class_3746 world, BiConsumer<class_2338, class_2680> replacer, class_5819 random,
                            class_2338 from, class_2338 to, int baseRadius, class_4643 config) {
        int dx = to.method_10263() - from.method_10263();
        int dy = to.method_10264() - from.method_10264();
        int dz = to.method_10260() - from.method_10260();
        int steps = Math.max(Math.max(Math.abs(dx), Math.abs(dy)), Math.abs(dz));
        float fx = from.method_10263();
        float fy = from.method_10264();
        float fz = from.method_10260();
        float stepx = dx / (float) steps;
        float stepy = dy / (float) steps;
        float stepz = dz / (float) steps;

        for (int i = 0; i <= steps; i++) {
            int cx = class_3532.method_15375(fx + i * stepx);
            int cy = class_3532.method_15375(fy + i * stepy);
            int cz = class_3532.method_15375(fz + i * stepz);

            float t = steps == 0 ? 1f : (i / (float) steps);
            float radius = class_3532.method_16439(t, baseRadius, 1f);

            int r = class_3532.method_15375(radius);
            for (int ox = -r; ox <= r; ox++) {
                for (int oz = -r; oz <= r; oz++) {
                    for (int oy = -Math.max(1, r / 2); oy <= Math.max(1, r / 2); oy++) {
                        if (ox * ox + oz * oz + oy * oy <= r * r) {
                            class_2338 p = new class_2338(cx + ox, cy + oy, cz + oz);
                            if (method_43196(world, p)) {
                                // choose axis by dominant delta
                                class_2350.class_2351 axis =
                                        Math.abs(dx) >= Math.abs(dy) && Math.abs(dx) >= Math.abs(dz) ? class_2350.class_2351.field_11048 :
                                                (Math.abs(dy) >= Math.abs(dz) ? class_2350.class_2351.field_11052 : class_2350.class_2351.field_11051);
                                class_2680 log = config.field_21288.method_23455(random, p).method_11657(class_2465.field_11459, axis);
                                replacer.accept(p, log);
                            }
                        }
                    }
                }
            }
        }

    }


    // Pack/unpack helpers for (x,z) pairs
    private static long packXZ(int x, int z) { return (((long)x) << 32) ^ (z & 0xffffffffL); }
    private static int unpackX(long v) { return (int)(v >> 32); }
    private static int unpackZ(long v) { return (int)v; }

    // Is this cell one of our already-placed trunk logs?
// Uses tags so it works with vanilla and custom logs (ensure your logs are in BlockTags.LOGS).
    private boolean isPlacedTrunkLog(class_3746 world, class_2338 pos) {
        return world.method_16358(pos, s ->
                s.method_26204() instanceof class_2465 &&
                        (s.method_26164(class_3481.field_15475) || s.method_26164(class_3481.field_23210))
        );
    }


    // Ray-cast from the trunk center at baseY to estimate the outer radius of the lowest ring.
    private float sampleBaseOuterRadiusByRaycast(class_3746 world,
                                                 int baseY, int cx, int cz,
                                                 int searchR, int angularSamples) {
        if (angularSamples <= 0) angularSamples = 48;
        ArrayList<Float> hits = new ArrayList<>(angularSamples);

        //baseY = baseY + 1; this stops root generation

        // Step along angle rays; record the last r in the FIRST contiguous log segment.
        for (int i = 0; i < angularSamples; i++) {
            double theta = (2.0 * Math.PI) * (i / (double) angularSamples);
            double cos = Math.cos(theta), sin = Math.sin(theta);

            boolean inLog = false;
            double lastLogR = -1.0;

            // Small radial step to avoid skipping narrow shells
            for (double r = 0.0; r <= searchR; r += 0.5) {
                int x = cx + (int)Math.round(cos * r);
                int z = cz + (int)Math.round(sin * r);

                if (isPlacedTrunkLog(world, new class_2338(x, baseY, z))) {
                    inLog = true;
                    lastLogR = r;
                } else if (inLog) {
                    // left the first log segment -> done for this ray
                    break;
                }
            }
            if (lastLogR > 0.0) {
                hits.add((float) lastLogR);
            }
        }

        if (hits.isEmpty()) return -1f;  // caller can fall back

        // Use median to be robust against dents/holes.
        hits.sort(Float::compare);
        return hits.get(hits.size() / 2); //changing this does nothing
    }

}
