package mia.the_tower.initialisation.world.tree;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import mia.the_tower.initialisation.block_init;
import net.minecraft.class_10376;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2378;
import net.minecraft.class_2465;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_3481;
import net.minecraft.class_3532;
import net.minecraft.class_3746;
import net.minecraft.class_4643;
import net.minecraft.class_4647.class_5208;
import net.minecraft.class_5141;
import net.minecraft.class_5142;
import net.minecraft.class_5819;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;

import static mia.the_tower.The_Tower.id;

//honestly I just let chatgpt have fun on this one, it is not optimised in any way, but it looks very cool
//that's all I really wanted

public class GiantTrunkPlacer extends class_5141 {
    // Extra params for taper & flare.
    private final float baseRadius;
    private final float topRadius;
    private final float taperPower;
    private final float flareSigma;
    private final float shellThicknessBlocks;  // 2 near base, tapers to ~1 near top
    private final float snakeAccelScale;      // random “accel” magnitude per layer
    private final float snakeDamping;         // velocity damping
    private final float snakeMaxOffset;

    public static final MapCodec<GiantTrunkPlacer> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            Codec.intRange(1, 128).fieldOf("base_height").forGetter(p -> p.field_23760),
            Codec.intRange(0, 128).fieldOf("height_rand_a").forGetter(p -> p.field_23761),
            Codec.intRange(0, 128).fieldOf("height_rand_b").forGetter(p -> p.field_23762),
            Codec.FLOAT.fieldOf("base_radius").forGetter(p -> p.baseRadius),
            Codec.FLOAT.fieldOf("top_radius").forGetter(p -> p.topRadius),
            Codec.FLOAT.fieldOf("taper_power").forGetter(p -> p.taperPower),
            Codec.FLOAT.fieldOf("flare_sigma").forGetter(p -> p.flareSigma),
            Codec.FLOAT.fieldOf("shell_thickness_blocks").forGetter(p -> p.shellThicknessBlocks),
            Codec.FLOAT.fieldOf("snake_accel_scale").forGetter(p -> p.snakeAccelScale),
            Codec.FLOAT.fieldOf("snake_damping").forGetter(p -> p.snakeDamping),
            Codec.FLOAT.fieldOf("snake_max_offset").forGetter(p -> p.snakeMaxOffset)
    ).apply(instance, GiantTrunkPlacer::new));

    public GiantTrunkPlacer(int baseHeight, int randomHeightA, int randomHeightB,
                            float baseRadius, float topRadius, float taperPower,
                            float flareSigma, float shellThicknessBlocks, float snakeAccelScale, float snakeDamping,
                            float snakeMaxOffset) {
        super(baseHeight, randomHeightA, randomHeightB);
        this.baseRadius = baseRadius;
        this.topRadius = topRadius;
        this.taperPower = taperPower;
        this.flareSigma = flareSigma;
        this.shellThicknessBlocks = shellThicknessBlocks;
        this.snakeAccelScale = snakeAccelScale;
        this.snakeDamping = snakeDamping;
        this.snakeMaxOffset = snakeMaxOffset;
    }

    public static final class_5142<GiantTrunkPlacer> GIANT_TRUNK =
            class_2378.method_10230(class_7923.field_41151,
                    id("giant_trunk"),
                    new class_5142<>(GiantTrunkPlacer.CODEC));

    public static void init() {}

    @Override
    protected class_5142<?> method_28903() {
        return GIANT_TRUNK; // register this
    }

    @Override
    public List<class_5208> method_26991(class_3746 world,
                                            BiConsumer<class_2338, class_2680> replacer,
                                            class_5819 random,
                                            int height,
                                            class_2338 startPos,
                                            class_4643 config) {
        List<class_5208> attachments = new ArrayList<>();
        class_2338.class_2339 m = new class_2338.class_2339();

        // Snaking centerline state
        float cx = 0f, cz = 0f;
        float vx = 0f, vz = 0f;

        // Keep per-layer centers and radii for later decoration/branches
        int[] centerX = new int[height + 2];
        int[] centerZ = new int[height + 2];
        float[] outerR = new float[height + 2];
        float[] innerR = new float[height + 2];

        // 1) Build hollow, snaking trunk
        for (int y = 0; y < height; y++) {
            float t = (float) y / (float) height;

            // Smooth random walk for the center
            vx = vx * snakeDamping + (random.method_43057() - 0.5f) * snakeAccelScale;
            vz = vz * snakeDamping + (random.method_43057() - 0.5f) * snakeAccelScale;
            cx += vx;
            cz += vz;

            // Clamp offset
            float offLen = class_3532.method_15355(cx * cx + cz * cz);
            if (offLen > snakeMaxOffset) {
                float s = snakeMaxOffset / offLen;
                cx *= s; cz *= s;
            }

            int cxi = startPos.method_10263() + Math.round(cx);
            int czi = startPos.method_10260() + Math.round(cz);
            int cy  = startPos.method_10264() + y;

            float core = class_3532.method_16439((float)Math.pow(t, this.taperPower), this.baseRadius, this.topRadius);
            //the variable of the devil, I am ignoring it because it causes more trouble than what it is worth
            float flareAmplitude = 0;
            float flare = flareAmplitude * (float) Math.exp(-(y * y) / (2f * this.flareSigma * this.flareSigma));
            float rOuter = Math.max(1.0f, core + flare);

            // Thickness tapers slightly with height
            float thick = class_3532.method_16439(t, shellThicknessBlocks, 1.0f);
            float rInner = Math.max(0.0f, rOuter - thick);

            centerX[y] = cxi;
            centerZ[y] = czi;
            outerR[y] = rOuter;
            innerR[y] = rInner;

            int r = class_3532.method_15386(rOuter) + 1;
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    float d2 = dx * dx + dz * dz;
                    // shell region
                    if (d2 <= rOuter * rOuter && d2 > rInner * rInner) {
                        m.method_10103(cxi + dx, cy, czi + dz);
                        if (method_43196(world, m)) {
                            class_2680 log = config.field_21288.method_23455(random, m)
                                    .method_11657(class_2465.field_11459, net.minecraft.class_2350.class_2351.field_11052);
                            replacer.accept(m, log);
                        }
                    }
                    // carve interior
                    else if (d2 < rInner * rInner) {
                        m.method_10103(cxi + dx, cy, czi + dz);
                        // Don’t accidentally break liquids/bedrock; basic guard:
                        if (isCarvable(world, m)) {
                            replacer.accept(m, class_2246.field_10124.method_9564());
                        }
                    }
                }
            }
        }

        extendDownWithStringRoots(
                world, replacer, random,
                startPos.method_10264(),            // baseY of the lowest trunk slice
                centerX[0], centerZ[0],     // center you used for y = 0
                config
        );


        // Top cap (sealed)
        int topY = startPos.method_10264() + height;
        int cxi = centerX[Math.max(0, height - 1)];
        int czi = centerZ[Math.max(0, height - 1)];
        float rCap = Math.max(1.0f, outerR[Math.max(0, height - 1)] * 0.8f);
        int rC = class_3532.method_15386(rCap);
        for (int dx = -rC; dx <= rC; dx++) {
            for (int dz = -rC; dz <= rC; dz++) {
                if (dx * dx + dz * dz <= rCap * rCap) {
                    m.method_10103(cxi + dx, topY, czi + dz);
                    if (method_43196(world, m)) {
                        class_2680 log = config.field_21288.method_23455(random, m)
                                .method_11657(class_2465.field_11459, net.minecraft.class_2350.class_2351.field_11052);
                        replacer.accept(m, log);
                    }
                }
            }
        }

        // 2) Branches from curved centerline
        int branchCount = 5 + random.method_43048(4);
        int minY = height / 2;
        for (int i = 0; i < branchCount; i++) {
            int y = minY + random.method_43048(Math.max(1, height - minY - 4));
            int bx = centerX[y], bz = centerZ[y];  // branch base follows the snake
            float rHere = Math.max(1.0f, outerR[y] * 0.55f);

            double theta = random.method_43058() * Math.PI * 2.0;
            double pitch = class_3532.method_16439(random.method_43057(), 0.20f, 0.60f);
            int len = class_3532.method_15375(6 + rHere * 4 + random.method_43057() * 4);

            int sx = bx + (int) Math.round(Math.cos(theta) * (rHere + 1));
            int sz = bz + (int) Math.round(Math.sin(theta) * (rHere + 1));
            int sy = startPos.method_10264() + y;

            int ex = sx + (int) Math.round(Math.cos(theta) * len);
            int ez = sz + (int) Math.round(Math.sin(theta) * len);
            int ey = sy + (int) Math.round(len * pitch);

            drawBranch(world, replacer, random, new class_2338(sx, sy, sz), new class_2338(ex, ey, ez),
                    class_3532.method_15340(class_3532.method_15375(rHere), 1, 3), config);

            // foliage at end
            attachments.add(new class_5208(new class_2338(ex, ey, ez), 0, false));

            // Patch the inner shell immediately “behind” the branch start so the interior stays sealed
            patchBehindBranch(replacer, random, config, new class_2338(sx, sy, sz), bx, bz);
        }

        // 3) Roots (reuse your existing; base at startPos)

        int rootCount = 3 + random.method_43048(4);
        for (int i = 0; i < rootCount; i++) {
            double theta = (2 * Math.PI / rootCount) * i + random.method_43057() * 0.6f;
            makeRoot(world, replacer, random, startPos, theta, config);
        }

        // 4) Interior decoration: WALL_PLANT + FLOOR_PLANT
        decorateInterior(world, replacer, random, startPos.method_10264(), centerX, centerZ, innerR, height);

        // 5) Crown foliage anchor at top
        attachments.add(new class_5208(new class_2338(cxi, topY, czi), 0, false));
        return attachments;
    }


    private boolean isCarvable(class_3746 world, class_2338 pos) {
        // Be stricter than isReplaceable: don’t nuke water/lava/bedrock
        return this.method_43196(world, pos);
    }

    private void patchBehindBranch(BiConsumer<class_2338, class_2680> replacer, class_5819 random,
                                   class_4643 config, class_2338 branchBase, int trunkCx, int trunkCz) {
        // Fill a 3x3x3 lump centered slightly toward trunk center from the branchBase.
        int dx = Integer.compare(trunkCx, branchBase.method_10263());
        int dz = Integer.compare(trunkCz, branchBase.method_10260());
        class_2338 core = branchBase.method_10069(dx, 0, dz);
        class_2338.class_2339 m = new class_2338.class_2339();
        for (int ox = -1; ox <= 1; ox++) for (int oy = -1; oy <= 1; oy++) for (int oz = -1; oz <= 1; oz++) {
            m.method_10103(core.method_10263() + ox, core.method_10264() + oy, core.method_10260() + oz);
            class_2680 log = config.field_21288.method_23455(random, m).method_11657(class_2465.field_11459, net.minecraft.class_2350.class_2351.field_11052);
            replacer.accept(m, log);
        }
    }

    // Helper: choose the outward direction by comparing to cavity center
    private class_2350 pickOutward(int cx, int cz, int x, int z) {
        int dx = x - cx, dz = z - cz;
        if (Math.abs(dx) >= Math.abs(dz)) {
            return dx >= 0 ? class_2350.field_11034 : class_2350.field_11039;
        } else {
            return dz >= 0 ? class_2350.field_11035 : class_2350.field_11043;
        }
    }

    private void decorateInterior(class_3746 world,
                                  BiConsumer<class_2338, class_2680> replacer,
                                  class_5819 random,
                                  int baseY,
                                  int[] centerX, int[] centerZ, float[] innerR, int height) {
        class_2338.class_2339 m = new class_2338.class_2339();

// A) WALL_PLANT: multiface placement like glow lichen
// Given: baseY, centerX[], centerZ[], innerR[], height, ModBlocks.WALL_PLANT
        for (int y = 2; y < height - 2; y++) {
            int cx = centerX[y], cz = centerZ[y];
            float rIn = innerR[y];
            if (rIn < 1.5f) continue;

            int samples = Math.max(8, class_3532.method_15375(6 * rIn));
            for (int i = 0; i < samples; i++) {
                if (random.method_43057() > 0.06f) continue;  // ~6% density
                double ang = (2 * Math.PI * i) / samples;

                int ix = cx + (int)Math.round(Math.cos(ang) * (rIn - 0.5));
                int iz = cz + (int)Math.round(Math.sin(ang) * (rIn - 0.5));
                int iy = baseY + y;
                class_2338 airPos = new class_2338(ix, iy, iz);
                if (!this.method_43196(world, airPos)) continue;

                // Probe neighbors; prefer outward first, then the other 3.
                class_2350 outward = pickOutward(cx, cz, ix, iz);
                class_2350[] order = new class_2350[] {
                        outward,
                        outward.method_10170(),
                        outward.method_10160(),
                        outward.method_10153()
                };

                class_2680 placed = null;
                for (class_2350 d : order) {
                    class_2338 neighbor = airPos.method_10093(d);
                    // "Solid enough" = NOT replaceable (you can tighten if needed)
                    if (!this.method_43196(world, neighbor)) {
                        class_2680 s = block_init.STARLIGHT_LICHEN.method_9564();
                        if (s.method_26204() instanceof class_10376 mgb) {
                            class_2746 face = class_10376.method_33374(d);
                            if (face != null && s.method_28498(face)) {
                                placed = s.method_11657(face, true);
                            }
                        } else if (s.method_28498(class_2741.field_12481)) {
                            // Fallback for a simple facing block: face inward
                            placed = s.method_11657(class_2741.field_12481, d.method_10153());
                        }
                        if (placed != null) {
                            replacer.accept(airPos, placed);
                            break;
                        }
                    }
                }
            }
        }

        // B) FLOOR_PLANT: probe down to real ground per sample
        int startProbeY = baseY + 2;    // a bit above the nominal floor
        int maxDown = 12;               // search window; adjust if needed

        int baseCx = centerX[0], baseCz = centerZ[0];
        float rIn0 = innerR[0];
        if (rIn0 >= 1.5f) {
            int area = class_3532.method_15375((float)Math.PI * rIn0 * rIn0);
            int tries = Math.min(64, Math.max(12, area / 2));
            for (int k = 0; k < tries; k++) {
                double ang = random.method_43058() * Math.PI * 2;
                double rad = random.method_43058() * (rIn0 - 0.5);
                int ix = baseCx + (int)Math.round(Math.cos(ang) * rad);
                int iz = baseCz + (int)Math.round(Math.sin(ang) * rad);

                int groundY = findGroundY(world, ix, startProbeY, iz, maxDown);
                class_2338 plantPos = new class_2338(ix, groundY + 1, iz);

                // Make sure this plant position is inside the cavity at that Y slice
                int yi = class_3532.method_15340(groundY + 1 - baseY, 0, innerR.length - 1);
                int ccx = centerX[yi], ccz = centerZ[yi];
                float rIn = innerR[yi];
                if (rIn < 1.0f) continue;
                double dx = ix - ccx, dz = iz - ccz;
                if (dx * dx + dz * dz >= rIn * rIn) continue; // not inside

                // Place only if air/replaceable
                if (this.method_43196(world, plantPos)) {
                    class_2680 plant = block_init.CERULEAN_SHORTGRASS.method_9564();
                    replacer.accept(plantPos, plant);
                }
            }
        }

    }

    private void drawBranch(class_3746 world, BiConsumer<class_2338, class_2680> replacer, class_5819 random,
                            class_2338 from, class_2338 to, int baseRadius, class_4643 config) {
        int dx = to.method_10263() - from.method_10263();
        int dy = to.method_10264() - from.method_10264();
        int dz = to.method_10260() - from.method_10260();
        int steps = Math.max(Math.max(Math.abs(dx), Math.abs(dy)), Math.abs(dz));
        float fx = from.method_10263();
        float fy = from.method_10264();
        float fz = from.method_10260();
        float stepx = dx / (float) steps;
        float stepy = dy / (float) steps;
        float stepz = dz / (float) steps;

        for (int i = 0; i <= steps; i++) {
            int cx = class_3532.method_15375(fx + i * stepx);
            int cy = class_3532.method_15375(fy + i * stepy);
            int cz = class_3532.method_15375(fz + i * stepz);

            float t = steps == 0 ? 1f : (i / (float) steps);
            float radius = class_3532.method_16439(t, baseRadius, 1f);

            int r = class_3532.method_15375(radius);
            for (int ox = -r; ox <= r; ox++) {
                for (int oz = -r; oz <= r; oz++) {
                    for (int oy = -Math.max(1, r / 2); oy <= Math.max(1, r / 2); oy++) {
                        if (ox * ox + oz * oz + oy * oy <= r * r) {
                            class_2338 p = new class_2338(cx + ox, cy + oy, cz + oz);
                            if (method_43196(world, p)) {
                                // choose axis by dominant delta
                                net.minecraft.class_2350.class_2351 axis =
                                        Math.abs(dx) >= Math.abs(dy) && Math.abs(dx) >= Math.abs(dz) ? net.minecraft.class_2350.class_2351.field_11048 :
                                                (Math.abs(dy) >= Math.abs(dz) ? net.minecraft.class_2350.class_2351.field_11052 : net.minecraft.class_2350.class_2351.field_11051);
                                class_2680 log = config.field_21288.method_23455(random, p).method_11657(class_2465.field_11459, axis);
                                replacer.accept(p, log);
                            }
                        }
                    }
                }
            }
        }
    }

    private void makeRoot(class_3746 world, BiConsumer<class_2338, class_2680> replacer, class_5819 random,
                          class_2338 base, double theta, class_4643 config) {
        int rootLen = 6 + random.method_43048(6);
        // Simple two-segment path that arcs down
        class_2338 p0 = base;
        class_2338 p1 = base.method_10069((int) Math.round(Math.cos(theta) * 3), 0, (int) Math.round(Math.sin(theta) * 3));
        class_2338 p2 = base.method_10069((int) Math.round(Math.cos(theta) * rootLen), -1 - random.method_43048(2),
                (int) Math.round(Math.sin(theta) * rootLen));

        int segments = 16;
        for (int i = 0; i <= segments; i++) {
            float t = i / (float) segments;
            // Quadratic Bézier interpolation
            double x = class_3532.method_48781(t, class_3532.method_48781(t, p0.method_10263(), p1.method_10263()), class_3532.method_48781(t, p1.method_10263(), p2.method_10263()));
            double y = class_3532.method_48781(t, class_3532.method_48781(t, p0.method_10264(), p1.method_10264()), class_3532.method_48781(t, p1.method_10264(), p2.method_10264()));
            double z = class_3532.method_48781(t, class_3532.method_48781(t, p0.method_10260(), p1.method_10260()), class_3532.method_48781(t, p1.method_10260(), p2.method_10260()));

            class_2338 c = class_2338.method_49637(x, y, z);
            // Small radius, sometimes 2 near base
            int r = (i < 4 && random.method_43056()) ? 2 : 1;
            for (int ox = -r; ox <= r; ox++) {
                for (int oz = -r; oz <= r; oz++) {
                    if (ox * ox + oz * oz <= r * r) {
                        class_2338 p = c.method_10069(ox, 0, oz);
                        if (method_43196(world, p)) {
                            class_2680 log = config.field_21288.method_23455(random, p)
                                    .method_11657(class_2465.field_11459, class_2350.class_2351.field_11052);
                            replacer.accept(p, log);
                        }
                    }
                }
            }
        }
    }

    // Pack/unpack helpers for (x,z) pairs
    private static long packXZ(int x, int z) { return (((long)x) << 32) ^ (z & 0xffffffffL); }
    private static int unpackX(long v) { return (int)(v >> 32); }
    private static int unpackZ(long v) { return (int)v; }

    // Is this cell one of our already-placed trunk logs?
// Uses tags so it works with vanilla and custom logs (ensure your logs are in BlockTags.LOGS).
    private boolean isPlacedTrunkLog(class_3746 world, class_2338 pos) {
        return world.method_16358(pos, s ->
                s.method_26204() instanceof class_2465 &&
                        (s.method_26164(class_3481.field_15475) || s.method_26164(class_3481.field_23210))
        );
    }

    /**
     * Read back the bottom-most ring at Y = baseY by scanning a square around the center.
     * Every (x,z) that currently holds a trunk log at that Y is added to the mask.
     */
    private java.util.Set<Long> collectBaseRingMaskByReadback(class_3746 world,
                                                              int baseY, int cx, int cz, int searchR) {
        java.util.HashSet<Long> mask = new java.util.HashSet<>();
        class_2338.class_2339 m = new class_2338.class_2339();
        for (int dx = -searchR; dx <= searchR; dx++) {
            for (int dz = -searchR; dz <= searchR; dz++) {
                m.method_10103(cx + dx, baseY, cz + dz);
                if (isPlacedTrunkLog(world, m)) {
                    mask.add(packXZ(m.method_10263(), m.method_10260()));
                }
            }
        }
        return mask;
    }

    // Ray-cast from the trunk center at baseY to estimate the outer radius of the lowest ring.
    private float sampleBaseOuterRadiusByRaycast(class_3746 world,
                                                 int baseY, int cx, int cz,
                                                 int searchR, int angularSamples) {
        if (angularSamples <= 0) angularSamples = 48;
        java.util.ArrayList<Float> hits = new java.util.ArrayList<>(angularSamples);

        //baseY = baseY + 1; this stops root generation

        // Step along angle rays; record the last r in the FIRST contiguous log segment.
        for (int i = 0; i < angularSamples; i++) {
            double theta = (2.0 * Math.PI) * (i / (double) angularSamples);
            double cos = Math.cos(theta), sin = Math.sin(theta);

            boolean inLog = false;
            double lastLogR = -1.0;

            // Small radial step to avoid skipping narrow shells
            for (double r = 0.0; r <= searchR; r += 0.5) {
                int x = cx + (int)Math.round(cos * r);
                int z = cz + (int)Math.round(sin * r);

                if (isPlacedTrunkLog(world, new class_2338(x, baseY, z))) {
                    inLog = true;
                    lastLogR = r;
                } else if (inLog) {
                    // left the first log segment -> done for this ray
                    break;
                }
            }
            if (lastLogR > 0.0) {
                hits.add((float) lastLogR);
            }
        }

        if (hits.isEmpty()) return -1f;  // caller can fall back

        // Use median to be robust against dents/holes.
        hits.sort(Float::compare);
        return hits.get(hits.size() / 2); //changing this does nothing
    }

    /**
     * Extend the trunk downward where terrain falls away, using many
     * thin curling "string" roots that hang from the base ring.
     *
     * This does NOT modify your existing makeRoot(...). It reads the real base
     * ring radius by raycasting from the center to the first/outer log segment,
     * then drops roots from evenly spaced anchor points on that ring.
     *
     * Requirements:
     *  - Your logs are in BlockTags.LOGS / LOGS_THAT_BURN (already true for vanilla/custom).
     *  - Helper methods present in this class:
     *      - sampleBaseOuterRadiusByRaycast(...)
     *      - findGroundY(...)
     *      - canReplace(...)
     */
    private void extendDownWithStringRoots(
            class_3746 world,
            BiConsumer<class_2338, class_2680> replacer,
            class_5819 random,
            int baseY,
            int cx, int cz,
            class_4643 config
    ) {
         //1) Measure the real outer radius of the bottom ring by reading placed logs.
        int searchR = Math.max(8, class_3532.method_15386(this.baseRadius) + 8);
        float measuredOuter = sampleBaseOuterRadiusByRaycast(world, baseY, cx, cz, searchR, 96);
        int rOuter = measuredOuter > 0 ? class_3532.method_15375(measuredOuter) : Math.max(2, class_3532.method_15386(this.baseRadius));

        //int rOuter = (int) baseRadius;

        // Use a conservative thickness (integer) for string roots.
        int rootThickness = class_3532.method_15340(class_3532.method_15386(this.shellThicknessBlocks * 0.5f), 1, 2);

        // Number of root anchors around the ring scales with radius.
        int anchors = class_3532.method_15340(rOuter * 3, 12, 96);

        // How far down we’re willing to search for ground below the base.
        final int MAX_DOWN = 64;

        // 2) For each anchor around the ring, cast a vertical probe to see if the ground falls away.
        for (int i = 0; i < anchors; i++) {
            double theta = (2.0 * Math.PI * i) / anchors;

            int ax = cx + (int)Math.round(Math.cos(theta) * rOuter);
            int az = cz + (int)Math.round(Math.sin(theta) * rOuter);
            class_2338 anchor = new class_2338(ax, baseY, az);

            // Skip if our anchor isn't a log (rare, but robust).
            if (!isPlacedTrunkLog(world, anchor)) continue;

            // Find the first solid ground below this perimeter point.
            int groundY = findGroundY(world, ax, baseY - 1, az, MAX_DOWN);
            int destY   = groundY + 1; // target air cell to land in

            // If there's no drop, no downward root needed here.
            if (destY >= baseY) continue;

            // 3) Grow a thin curling string root from anchor -> destY.
            growCurlingStringRoot(world, replacer, random, anchor, new class_2338(ax, destY, az),
                    theta, rootThickness, config);
        }
    }

    /**
     * Create a slender, curling path from 'from' down to 'to', with slight horizontal drift
     * and a gentle spiral component. Radius is 1–2; logs are axis-aligned to the dominant step.
     */
    private void growCurlingStringRoot(
            class_3746 world,
            BiConsumer<class_2338, class_2680> replacer,
            class_5819 random,
            class_2338 from,
            class_2338 to,
            double outwardAngle,                 // angle pointing away from trunk center
            int thickness,                       // 1–2
            class_4643 config
    ) {
        // Parametrize a meandering path with small horizontal velocity and damping,
        // with a bias outward (away from trunk center) and a tangential curl.
        double x = from.method_10263() + 0.5;
        double y = from.method_10264() + 0.25;          // start just under the base slice
        double z = from.method_10260() + 0.5;

        double vx = 0.0, vz = 0.0;

        int drop = from.method_10264() - to.method_10264();
        int steps = Math.max(8, drop * 3);      // extra samples to look "stringy"

        // Unit vectors: outward and a perpendicular tangent for curl.
        double ox = Math.cos(outwardAngle), oz = Math.sin(outwardAngle);
        double tx = -oz, tz = ox;               // rotate 90° for tangential component
        double phase = random.method_43058() * Math.PI * 2.0;

        for (int s = 0; s <= steps; s++) {
            double t  = steps == 0 ? 1.0 : (s / (double)steps);
            double dy = class_3532.method_16436(0.6, 0.9, random.method_43058()); // per-step vertical descent

            // Outward bias keeps roots drifting off the trunk wall.
            double outwardPush = 0.06 + 0.05 * random.method_43058();
            vx += ox * outwardPush + (random.method_43058() - 0.5) * 0.08;
            vz += oz * outwardPush + (random.method_43058() - 0.5) * 0.08;

            // Gentle curl: sinusoidal push along tangent, slowly varying.
            double curlMag = 0.05 + 0.03 * Math.sin(t * Math.PI * 2.0 + phase);
            vx += tx * curlMag;
            vz += tz * curlMag;

            // Damp velocities so it doesn't drift too far.
            vx *= 0.72;
            vz *= 0.72;

            // Advance
            x += vx;
            z += vz;
            y -= dy;

            // Clamp to final target height
            if (y <= to.method_10264() + 0.25) y = to.method_10264() + 0.25;

            class_2338 p = class_2338.method_49637(x, y, z);

            // Choose axis by dominant motion; roots look better when axis follows path.
            net.minecraft.class_2350.class_2351 axis;
            {
                double adx = Math.abs(vx), ady = dy, adz = Math.abs(vz);
                if (adx >= ady && adx >= adz) axis = net.minecraft.class_2350.class_2351.field_11048;
                else if (adz >= adx && adz >= ady) axis = net.minecraft.class_2350.class_2351.field_11051;
                else axis = net.minecraft.class_2350.class_2351.field_11052;
            }

            // Place a 1–2 block cross-section (disk) per step, mostly 1.
            int r = (s < 2 && thickness >= 2 && random.method_43056()) ? 2 : 1;
            for (int oxi = -r; oxi <= r; oxi++) {
                for (int ozi = -r; ozi <= r; ozi++) {
                    if (oxi * oxi + ozi * ozi <= r * r) {
                        class_2338 q = p.method_10069(oxi, 0, ozi);
                        if (method_43196(world, q)) {
                            class_2680 log = config.field_21288.method_23455(random, q)
                                    .method_11657(class_2465.field_11459, axis);
                            replacer.accept(q, log);
                        }
                    }
                }
            }

            // Stop when we’ve reached target height.
            if (p.method_10264() <= to.method_10264()) {
                // Optionally bury the tip 1 block for a natural termination if air is underneath.
                class_2338 tipBelow = p.method_10074();
                if (method_43196(world, tipBelow)) {
                    class_2680 log = config.field_21288.method_23455(random, tipBelow)
                            .method_11657(class_2465.field_11459, net.minecraft.class_2350.class_2351.field_11052);
                    replacer.accept(tipBelow, log);
                }
                break;
            }
        }
    }


    private int findGroundY(class_3746 world, int x, int startY, int z, int maxDown) {
        class_2338.class_2339 m = new class_2338.class_2339(x, startY, z);
        for (int i = 0; i < maxDown; i++) {
            // First non-replaceable encountered is the ground.
            if (!this.method_43196(world, m)) {
                return m.method_10264();
            }
            m.method_10098(net.minecraft.class_2350.field_11033);
        }
        return startY - maxDown; // fallback if nothing solid within range
    }




}
