package mia.the_tower.initialisation.world;

import mia.the_tower.initialisation.block_init;
import net.minecraft.class_2338;
import net.minecraft.class_3031;
import net.minecraft.class_3111;
import net.minecraft.class_5281;
import net.minecraft.class_5819;
import net.minecraft.class_5821;

public class BlajFeature extends class_3031<class_3111> {
    public BlajFeature() {
        super(class_3111.field_24893);
    }

    // this method is what is called when the game tries to generate the feature. it is where the actual blocks get placed into the world.
    @Override
    public boolean method_13151(class_5821<class_3111> context) {
        class_5281 world = context.method_33652();
        // the origin is the place where the game starts trying to place the feature
        class_2338 origin = context.method_33655();
        class_5819 random = context.method_33654();
        class_3111 config = context.method_33656();

        int height = random.method_39332(8, 18);
        int x = origin.method_10263();
        int z = origin.method_10260();
        int y = origin.method_10264() + height;

        var pos = new net.minecraft.class_2338.class_2339();

        //sets the edges and the faces here
        for (int i = height; i >= 0; i--) {
            int dif = height - i;
            set(world, pos.method_10103(x - dif, y - dif, z), pick(random, EDGES, 5));
            for (int j = dif; j >= 1; j--) {
                set(world, pos.method_10103((x - dif) + j, y - dif, z + j), pick(random, FACES, 8));
            }
            set(world, pos.method_10103(x + dif, y - dif, z), pick(random, EDGES, 5));
            for (int j = dif; j >= 1; j--) {
                set(world, pos.method_10103((x + dif) - j, y - dif, z - j), pick(random, FACES, 8));
            }
            set(world, pos.method_10103(x, y - dif, z + dif), pick(random, EDGES, 5));
            for (int j = dif; j >= 1; j--) {
                set(world, pos.method_10103(x + j, y - dif, (z + dif) - j), pick(random, FACES, 8));
            }
            set(world, pos.method_10103(x, y - dif, z - dif), pick(random, EDGES, 5));
            for (int j = dif; j >= 1; j--) {
                set(world, pos.method_10103(x - j, y - dif, (z + dif) + j), pick(random, FACES, 8));
            }
        }

        return true;
    }

    private static void set(net.minecraft.class_5281 world,
                            net.minecraft.class_2338 pos,
                            net.minecraft.class_2680 state) {
        var current = world.method_8320(pos);
        if (current.method_26215()) {
            world.method_8652(pos, state, net.minecraft.class_2248.field_31036);
        }
    }

    //my picker
    private static final net.minecraft.class_2680[] EDGES = new net.minecraft.class_2680[] {
            block_init.BLAJ_LESSER_ORE.method_9564(),
            block_init.BLAJ_ORE.method_9564()
    };

    private static final net.minecraft.class_2680[] FACES = new net.minecraft.class_2680[] {
            block_init.DARKNESS.method_9564(),
            block_init.BLAJ_LESSER_ORE.method_9564()
    };

    private static net.minecraft.class_2680 pick(net.minecraft.class_5819 rand, net.minecraft.class_2680[] State, int primary_weight) {
        int r = rand.method_43048(10);
        if (r < primary_weight) return State[0];
        return State[1];
    }
}