package mia.the_tower.initialisation.world.vegetation;

import com.mojang.serialization.Codec;
import mia.the_tower.initialisation.block.TripleBlockPart;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2680;
import net.minecraft.class_2754;
import net.minecraft.class_2769;
import net.minecraft.class_2960;
import net.minecraft.class_3031;
import net.minecraft.class_3175;
import net.minecraft.class_5425;
import net.minecraft.class_5819;
import net.minecraft.class_5821;
import net.minecraft.class_7923;

public class TripleAwareSimpleBlockFeature extends class_3031<class_3175> {
    public TripleAwareSimpleBlockFeature(Codec<class_3175> codec) {
        super(codec);
    }

    @Override
    public boolean method_13151(class_5821<class_3175> ctx) {
        class_5425 world = ctx.method_33652();
        class_2338 pos = ctx.method_33655();
        class_5819 random = ctx.method_33654();
        class_3175 cfg = ctx.method_33656();

        class_2680 state = cfg.comp_156().method_23455(random, pos);

        class_2754<TripleBlockPart> third = findThirdProperty(state);
        if (third != null) {
            // bottom/middle/top; fail if we can't fit
            if (pos.method_10264() + 2 > world.method_31600()) return false;
            if (!world.method_8320(pos).method_26215()
                    || !world.method_8320(pos.method_10084()).method_26215()
                    || !world.method_8320(pos.method_10086(2)).method_26215()) return false;

            class_2680 lower  = state.method_11657(third, TripleBlockPart.LOWER);
            class_2680 middle = state.method_11657(third, TripleBlockPart.MIDDLE);
            class_2680 upper  = state.method_11657(third, TripleBlockPart.UPPER);

            world.method_8652(pos,        lower,  class_2248.field_31036);
            world.method_8652(pos.method_10084(),   middle, class_2248.field_31036);
            world.method_8652(pos.method_10086(2),  upper,  class_2248.field_31036);
            return true;
        }

        // Fallback: behave like SIMPLE_BLOCK
        if (!state.method_26184(world, pos)) return false;
        return world.method_8652(pos, state, class_2248.field_31036);
    }

    @SuppressWarnings("unchecked")
    private static class_2754<TripleBlockPart> findThirdProperty(class_2680 state) {
        for (class_2769<?> p : state.method_26204().method_9595().method_11659()) {
            if (p instanceof class_2754<?> && "third".equals(p.method_11899())) {
                try { return (class_2754<TripleBlockPart>) p; } catch (ClassCastException ignored) {}
            }
        }
        return null;
    }

    public static final class_3031<class_3175> TRIPLE_AWARE_SIMPLE_BLOCK =
            class_2378.method_10230(class_7923.field_41144,
                    class_2960.method_60655("the_tower", "triple_aware_simple_block"),
                    new TripleAwareSimpleBlockFeature(class_3175.field_24909));

    public static void init() {}

}
