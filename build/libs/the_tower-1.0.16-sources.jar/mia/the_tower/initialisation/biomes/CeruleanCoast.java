package mia.the_tower.initialisation.biomes;

import mia.the_tower.initialisation.carver.ModCarvers;
import mia.the_tower.initialisation.entity.ModEntities;
import mia.the_tower.initialisation.world.ModPlacedFeatures;
import net.minecraft.class_1311;
import net.minecraft.class_1959;
import net.minecraft.class_2893;
import net.minecraft.class_2960;
import net.minecraft.class_4763;
import net.minecraft.class_5321;
import net.minecraft.class_5483;
import net.minecraft.class_5485;
import net.minecraft.class_7891;
import net.minecraft.class_7924;


//to create a new biome, it needs one of these, it needs its own line in The_TowerDataGenerator, load() needs to be called, and it needs
//to be mentioned in the_frage json under dimension dir

public class CeruleanCoast {

    public static final class_5321<class_1959> CERULEAN_COAST = class_5321.method_29179(class_7924.field_41236, class_2960.method_60655("the_tower", "cerulean_coast"));

    public static void bootstrap(class_7891<class_1959> context) {
        context.method_46838(CERULEAN_COAST, createCeruleanCoast(context));
    }

    public static class_1959 createCeruleanCoast(class_7891<class_1959> context) {
        class_5483.class_5496 spawnBuilder = new class_5483.class_5496();
        spawnBuilder.method_31011(class_1311.field_6303, new class_5483.class_1964(ModEntities.LAMP_FLY, 50, 6, 15)); //spawning mod entities

        //general
        var placedLookup = context.method_46799(class_7924.field_41245); //?
        var carverLookup  = context.method_46799(class_7924.field_41238);

        class_5485.class_5495 biomeBuilder =
                new class_5485.class_5495(placedLookup, carverLookup);

        //for carver
//        RegistryKey<ConfiguredCarver<?>> PIT_CARVER_KEY =
//                RegistryKey.of(RegistryKeys.CONFIGURED_CARVER, Identifier.of("the_tower", "pit_carver"));
//
//        gen.carver(PIT_CARVER_KEY);

        //add ores here as well
        biomeBuilder.method_46676(
                class_2893.class_2895.field_13176,
                placedLookup.method_46747(ModPlacedFeatures.AFHD_PLACED_KEY)
        );
        biomeBuilder.method_46676(
                class_2893.class_2895.field_13176,
                placedLookup.method_46747(ModPlacedFeatures.DRAGONS_EYE_ORE_PLACED_KEY)
        );
        biomeBuilder.method_46676(
                class_2893.class_2895.field_13176,
                placedLookup.method_46747(ModPlacedFeatures.SILVER_VEIN_PLACED_KEY)
        );
        biomeBuilder.method_46676(
                class_2893.class_2895.field_13176,
                placedLookup.method_46747(ModPlacedFeatures.SILVER_ORE_PLACED_KEY)
        );

        //globalOverworldGeneration(biomeBuilder); //this is for if you want it to spawn in the overworld
        //DefaultBiomeFeatures.addMossyRocks(biomeBuilder);
        //DefaultBiomeFeatures.addDefaultOres(biomeBuilder);
        //DefaultBiomeFeatures.addExtraGoldOre(biomeBuilder);

        //vegetation
        biomeBuilder.method_30992(class_2893.class_2895.field_13178, ModPlacedFeatures.CERULEAN_GRASS_PATCH_PLACED_KEY);
        biomeBuilder.method_30992(class_2893.class_2895.field_13178, ModPlacedFeatures.CERULEAN_COAST_FLOWERS_PATCH_PLACED_KEY);

        return new class_1959.class_1960()
                .method_48164(true)
                .method_8727(0.7f)
                .method_8747(0.7f)
                .method_30973(biomeBuilder.method_46671())
                .method_30974(spawnBuilder.method_31007())
                .method_24379((new class_4763.class_4764())
                        .method_24395(0x0c2242)
                        .method_24397(0x203554)
                        .method_30820(0x203554)
                        .method_30822(0x143d78)
                        .method_30821(0x143d78)
                        .method_24392(0x465c7d)
                        //.moodSound(BiomeMoodSound.CAVE)
                        //.music(MusicType.createIngameMusic(RegistryEntry.of(ModSounds.BAR_BRAWL))) //custom music
                        .method_24391())
                .method_30972();
    }

    public static void load(){}

}
