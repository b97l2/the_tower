package mia.the_tower.initialisation.fluid;

import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;

public abstract class BaseFluid extends class_3609 {
        @Override public boolean method_15780(class_3611 fluid) { return fluid == method_15751() || fluid == method_15750(); }
        @Override protected boolean method_15737(class_3218 world) { return false; }
        @Override protected void method_15730(class_1936 world, class_2338 pos, class_2680 state) { /* drop stacks */ }
        @Override protected boolean method_15777(class_3610 state, class_1922 view, class_2338 pos, class_3611 fluid, class_2350 dir) { return true; }
        //@Override protected int getFlowSpeed(WorldView world) { return 4; }
        @Override protected float method_15784() { return 100.0F; }
    }
