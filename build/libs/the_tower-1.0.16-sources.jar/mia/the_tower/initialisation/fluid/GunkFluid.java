package mia.the_tower.initialisation.fluid;

import mia.the_tower.initialisation.block_init;
import mia.the_tower.initialisation.item_init;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import java.util.Optional;

public abstract class GunkFluid extends BaseFluid {
    @Override public class_3611 method_15751() { return block_init.STILL_GUNK; }
    @Override public class_3611 method_15750() { return block_init.FLOWING_GUNK; }
    @Override public class_1792 method_15774() { return item_init.CUP_OF_GUNK; }
    @Override protected class_2680 method_15790(class_3610 state) {
        return block_init.GUNK.method_9564().method_11657(class_2741.field_12538, method_15741(state));
    }

    public static class Flowing extends GunkFluid {
        @Override protected void method_15775(class_2689.class_2690<class_3611, class_3610> builder) {
            super.method_15775(builder);
            builder.method_11667(field_15900);
        }
        @Override public int method_15779(class_3610 state) { return state.method_11654(field_15900); }
        @Override public boolean method_15793(class_3610 state) { return false; }
    }

    public static class Still extends GunkFluid {
        @Override public int method_15779(class_3610 state) { return 8; }
        @Override public boolean method_15793(class_3610 state) { return true; }
    }

    @Override
    public int method_15733(class_4538 world) {
        return 7;
    }

    @Override protected int method_15739(class_4538 world) { return 1; }
    @Override public int method_15789(class_4538 world) { return 20; }


    @Override
    public void method_15776(class_1937 world, class_2338 pos, class_3610 state, class_5819 random) {
        if (!state.method_15771() && !(Boolean)state.method_11654(field_15902)) {
            if (random.method_43048(64) == 0) {
                world.method_8486(
                        pos.method_10263() + 0.5,
                        pos.method_10264() + 0.5,
                        pos.method_10260() + 0.5,
                        class_3417.field_15237,
                        class_3419.field_15245,
                        random.method_43057() * 0.25F + 0.75F,
                        random.method_43057() + 0.5F,
                        false
                );
            }
        } else if (random.method_43048(10) == 0) {
            world.method_8406(
                    class_2398.field_22247, pos.method_10263() + random.method_43058(), pos.method_10264() + random.method_43058(), pos.method_10260() + random.method_43058(), 0.0, 0.0, 0.0
            );
        }
    }

    /*
    @Override
    public boolean matchesType(Fluid fluid) {
        return fluid == Fluids.WATER || fluid == Fluids.FLOWING_WATER;
    }

     */

    @Override
    public Optional<class_3414> method_32359() {
        return Optional.of(class_3417.field_15126);
    }

}
