package mia.the_tower.initialisation.fluid;

import mia.the_tower.initialisation.entity.ModEntities;
import mia.the_tower.initialisation.status_effects.DecayStatusEffect;
import net.minecraft.class_1293;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2404;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3609;
import net.minecraft.class_5712;
import java.util.HashMap;
import java.util.Map;

public class GunkFluidBlock extends class_2404 {

    // Map to track time spent inside the fluid by each player
    public static final Map<class_1657, Integer> playerTimeInside = new HashMap<>();
    public static final Map<class_1657, Integer> playerTimeOutside = new HashMap<>();

    public GunkFluidBlock(class_3609 fluid, class_2251 settings) {
        super(fluid, settings);
    }

    @Override
    public void method_9548(class_2680 state, class_1937 world, class_2338 pos, net.minecraft.class_1297 entity) {
        if (entity instanceof class_1309 && entity.method_5864() != ModEntities.VOID_MOTH && entity.method_5864() != class_1299.field_20346) { //change to relevant mobs later
            entity.method_5844(state, new class_243(0.8F, 0.75, 0.8F));
        }
        if (entity instanceof class_1657 player) {

            playerTimeOutside.put(player, 0);

            // Check if the player is inside the fluid
            if (world instanceof class_3218) {
                class_3218 serverWorld = (class_3218) world;

                // Track time spent inside the fluid
                int timeInside = playerTimeInside.getOrDefault(player, 0) + 1;
                playerTimeInside.put(player, timeInside);

                // Apply status effect every 80 ticks
                if (timeInside % 400 == 0) {
                    int level = Math.min(timeInside / 400, 5); // Max level 5
                    int duration = level * 200;

                    // Apply or update the status effect
                    player.method_6092(new class_1293(DecayStatusEffect.DECAY, duration, level - 1, true, true));

                }
            }
        }
    }

    @Override
    public class_2680 method_9576(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
        this.method_33614(world, player, pos, state);

        world.method_43276(class_5712.field_28165, pos, class_5712.class_7397.method_43286(player, state));
        playerTimeInside.clear();
        return state;
    }


}
