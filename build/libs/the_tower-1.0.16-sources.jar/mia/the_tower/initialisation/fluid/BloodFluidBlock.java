package mia.the_tower.initialisation.fluid;

import mia.the_tower.initialisation.status_effects.DecayStatusEffect;
import mia.the_tower.initialisation.status_effects.SanguineStatusEffect;
import net.minecraft.class_1293;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2404;
import net.minecraft.class_2680;
import net.minecraft.class_3609;
import net.minecraft.class_5712;
import java.util.HashMap;
import java.util.Map;

public class BloodFluidBlock extends class_2404 {


    public BloodFluidBlock(class_3609 fluid, class_2251 settings) {
        super(fluid, settings);
    }

    @Override
    public void method_9548(class_2680 state, class_1937 world, class_2338 pos, net.minecraft.class_1297 entity) {
        if (entity instanceof class_1657 player) {
            player.method_6092(new class_1293(SanguineStatusEffect.SANGUINE, 60*20, 0, true, true));
        }
    }

    @Override
    public class_2680 method_9576(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
        this.method_33614(world, player, pos, state);
        world.method_43276(class_5712.field_28165, pos, class_5712.class_7397.method_43286(player, state));
        return state;
    }


}
