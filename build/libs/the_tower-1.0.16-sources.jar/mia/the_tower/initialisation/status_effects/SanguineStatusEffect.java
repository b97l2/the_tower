package mia.the_tower.initialisation.status_effects;

import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_1322;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_2378;
import net.minecraft.class_238;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_4081;
import net.minecraft.class_5134;
import net.minecraft.class_5354;
import net.minecraft.class_6880;
import net.minecraft.class_7923;


public class SanguineStatusEffect extends class_1291 {
    public static final class_6880<class_1291> SANGUINE = register(
            "sanguine",
            new SanguineStatusEffect(class_4081.field_18271, 0x420000)
                    .method_5566(
                            class_5134.field_23721,
                            class_2960.method_60655("the_tower", "effect.sanguine.attack_damage"),
                            4, //2 times
                            class_1322.class_1323.field_6328
                    )
                    .method_5566(
                            class_5134.field_23723,
                            class_2960.method_60655("the_tower", "effect.sanguine.attack_speed"),
                            9, //2.5 times
                            class_1322.class_1323.field_6328
                    )
                    .method_5566(
                            class_5134.field_47759,
                            class_2960.method_60655("the_tower", "effect.sanguine.entity_interaction_range"),
                            3,//doubles
                            class_1322.class_1323.field_6328
                    )
                    .method_5566(
                            class_5134.field_23728,
                            class_2960.method_60655("the_tower", "effect.sanguine.jump_strength"),
                            0.42, //doubles
                            class_1322.class_1323.field_6328
                    )
                    .method_5566(
                            class_5134.field_23726,
                            class_2960.method_60655("the_tower", "effect.sanguine.luck"),
                            3, //set
                            class_1322.class_1323.field_6328
                    )
                    .method_5566(
                            class_5134.field_23716,
                            class_2960.method_60655("the_tower", "effect.sanguine.max_health"),
                            10, //1.5 times
                            class_1322.class_1323.field_6328
                    )
                    .method_5566(
                            class_5134.field_51582,
                            class_2960.method_60655("the_tower", "effect.sanguine.movement_efficiency"),
                            0.40, //40 percent increase
                            class_1322.class_1323.field_6328
                    )
                    .method_5566(
                            class_5134.field_23719,
                            class_2960.method_60655("the_tower", "effect.sanguine.movement_speed"),
                            0.12, //adds 0.12 to 0.7
                            class_1322.class_1323.field_6328
                    )
                    .method_5566(
                            class_5134.field_51578,
                            class_2960.method_60655("the_tower", "effect.sanguine.water_movement_efficiency"),
                            0.5, //adds 10 percent
                            class_1322.class_1323.field_6328
                    )
                    .method_5566(
                            class_5134.field_51583,
                            class_2960.method_60655("the_tower", "effect.sanguine.oxygen_bonus"),
                            10, //set
                            class_1322.class_1323.field_6328
                    )
                    .method_5566(
                            class_5134.field_49079,
                            class_2960.method_60655("the_tower", "effect.sanguine.safe_fall_distance"),
                            17, //sets to 10
                            class_1322.class_1323.field_6328
                    )
                    .method_5566(
                            class_5134.field_51584,
                            class_2960.method_60655("the_tower", "effect.sanguine.sneaking_speed"),
                            0.5, //2.5 times
                            class_1322.class_1323.field_6328
                    )
                    .method_5566(
                            class_5134.field_23720,
                            class_2960.method_60655("the_tower", "effect.sanguine.flying_speed"),
                    0.45, //sets to 0.55 from 0.4
                            class_1322.class_1323.field_6328
                    )
                    .method_5566(
                            class_5134.field_49077,
                            class_2960.method_60655("the_tower", "effect.sanguine.fall_damage_multiplier"),
                            -0.8, //one third
                            class_1322.class_1323.field_6328
                    )
                    .method_5566(
                            class_5134.field_49078,
                            class_2960.method_60655("the_tower", "effect.sanguine.gravity"),
                            -0.03, //sets to 0.5 from 0.8
                            class_1322.class_1323.field_6328
                    )
                    .method_5566(
                            class_5134.field_47761,
                            class_2960.method_60655("the_tower", "effect.sanguine.step_height"),
                    2, //sets to 2.6 from 0.6
                            class_1322.class_1323.field_6328
                    )
    );

    @Override
    public boolean method_5552(int duration, int amplifier) {
        //updates every 5 seconds
        return duration % 20*5 == 0;
    }


    @Override
    public boolean method_5572(class_3218 world, class_1309 entity, int amplifier) {
        if (!(entity instanceof class_1657 player)) return true;

        // Don’t do AI work for client, spectators, or creative players
        if (world.method_8608() || player.method_7325() || player.method_7337()) return true;

        final double radius = 64.0;
        final class_238 area = player.method_5829().method_1014(radius);

        class_3218 sw = (class_3218) world;
        // Pull all hostile mobs in a 64-block cube around the player
        var mobs = sw.method_8390(
                class_1588.class,
                area,
                mob -> mob.method_5805() && mob.method_5732()
        );

        for (class_1588 mob : mobs) {
            // Point them at the player
            if (mob.method_5968() != player) {
                mob.method_5980(player);
            }
            mob.method_19540(true);

            // Keep "anger"-based mobs (piglins, endermen, etc.) actually angry
            if (mob instanceof class_5354 angry) {
                angry.method_29513(player.method_5667());
                //refreshes to 60 seconds of anger time
                angry.method_29514(20*60);
            }

            // Nudge their pathfinder so they start moving right away
            mob.method_5942().method_6335(player, 1.2D);
        }
        return true;
    }

    public SanguineStatusEffect(class_4081 category, int color) {
        super(category, color);
    }

    private static class_6880<class_1291> register(String path, class_1291 effect) {
        return class_2378.method_47985(class_7923.field_41174, class_2960.method_60655("the_tower", path), effect);
    }

    public static void load(){}
}