package mia.the_tower.initialisation.status_effects;

import net.minecraft.class_1291;
import net.minecraft.class_1322;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4081;
import net.minecraft.class_5134;
import net.minecraft.class_6880;
import net.minecraft.class_7923;


public class InstantMineEffect extends class_1291 {
    public static final class_6880<class_1291> WHAMMY_HAND = register(
            "whammy_hand",
            new InstantMineEffect(class_4081.field_18271, 0x542E3B)
                    .method_5566(
                            class_5134.field_51581,
                            class_2960.method_60655("the_tower", "effect.whammy_hand.mining_efficiency"),
                            1000,
                            class_1322.class_1323.field_6328
                    )
                    .method_5566(
                            class_5134.field_49076,
                            class_2960.method_60655("the_tower", "effect.whammy_hand.block_break_speed"),
                            1000,
                            class_1322.class_1323.field_6328
                    )
                    .method_5566(
                            class_5134.field_51576,
                            class_2960.method_60655("the_tower", "effect.whammy_hand.submerged_mining_speed"),
                            18,
                            class_1322.class_1323.field_6328
                    )
                    .method_5566(
                            class_5134.field_47758,
                            class_2960.method_60655("the_tower", "effect.whammy_hand.block_interaction_range"),
                            50,
                            class_1322.class_1323.field_6328
                    )
                    .method_5566(
                            class_5134.field_23721,
                            class_2960.method_60655("the_tower", "effect.sanguine.attack_damage"),
                            -1500, //sets to 0
                            class_1322.class_1323.field_6328
                    )
                    .method_5566(
                            class_5134.field_47759,
                            class_2960.method_60655("the_tower", "effect.sanguine.entity_interaction_range"),
                            -60,//sets to 0
                            class_1322.class_1323.field_6328
                    )
    );

    public InstantMineEffect(class_4081 category, int color) {
        super(category, color);
    }

    private static class_6880<class_1291> register(String path, class_1291 effect) {
        return class_2378.method_47985(class_7923.field_41174, class_2960.method_60655("the_tower", path), effect);
    }

    public static void load(){}
}