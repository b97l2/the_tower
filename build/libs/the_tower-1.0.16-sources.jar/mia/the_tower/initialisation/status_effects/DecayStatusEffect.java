package mia.the_tower.initialisation.status_effects;

import java.util.UUID;
import java.util.WeakHashMap;
import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_2378;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_4081;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public class DecayStatusEffect extends class_1291 {
    public DecayStatusEffect() {
        super(class_4081.field_18272, 0x000000); // black
    }
    private static final WeakHashMap<UUID, class_243> lastPositions = new WeakHashMap<>();

    @Override
    public boolean method_5552(int duration, int amplifier) {
        // Run logic every 20 ticks (1 second)
        return duration % 20 == 0;
    }

    @Override
    public boolean method_5572(class_3218 world, class_1309 entity, int amplifier) {
        UUID uuid = entity.method_5667();
        class_243 currentPos = entity.method_19538();
        class_243 lastPos = lastPositions.get(uuid);

        // Detect if the entity has moved since last tick
        boolean hasMoved = lastPos == null || !currentPos.equals(lastPos);

        if (hasMoved) {
            float damage = (amplifier + 1) * 2.0f; // 2 hearts per decay level
            entity.method_64397(world, entity.method_48923().method_48831(), damage);
            lastPositions.put(uuid, currentPos);
            return true;
        }

        return true;
    }

    public static final class_6880<class_1291> DECAY =
            class_2378.method_47985(class_7923.field_41174, class_2960.method_60655("the_tower", "decay"), new DecayStatusEffect());

    public static void load(){}
}
