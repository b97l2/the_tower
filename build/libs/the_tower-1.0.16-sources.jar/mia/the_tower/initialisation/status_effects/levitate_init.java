package mia.the_tower.initialisation.status_effects;

import mia.the_tower.initialisation.block_init;
import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_4081;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public class levitate_init extends class_1291 {

    protected levitate_init() {
        super(class_4081.field_18271, 0x020070); // Light blue color
    }

    @Override
    public boolean method_5572(class_3218 world, class_1309 entity, int amplifier) {
        class_2338 below = entity.method_24515().method_10074();

        if (entity.method_5715()) {
            if (world.method_8320(below).method_27852(block_init.BARRIER)) {
                world.method_8501(below, class_2246.field_10124.method_9564());
            }
            return true;
        }

        if (world.method_8320(below).method_26215()) {
            world.method_8501(below, block_init.BARRIER.method_9564());
        }

        return true; // Must return true to keep applying every tick
    }


    @Override
    public boolean method_5552(int duration, int amplifier) {
        return true; // Apply every tick
    }

    // Internal registration of the status effect
    public static final class_6880<class_1291> LEVITATE =
            class_2378.method_47985(class_7923.field_41174, class_2960.method_60655("the_tower", "levitate"), new levitate_init());

    public static void load(){}
}
