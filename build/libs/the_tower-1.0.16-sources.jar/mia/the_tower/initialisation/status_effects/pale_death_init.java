package mia.the_tower.initialisation.status_effects;

import mia.the_tower.The_Tower;
import net.minecraft.class_1291;
import net.minecraft.class_1309;
import net.minecraft.class_1934;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4081;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public class pale_death_init extends class_1291 {

    public pale_death_init() {
        super(class_4081.field_18271, 0x888888); // gray color
    }

    @Override
    public boolean method_5572(class_3218 world, class_1309 entity, int amplifier) {
        if (!(entity instanceof class_3222 player)) return true;

        // Save original game mode if not saved
        if (!The_Tower.isSpectating(player)) {
            The_Tower.setSpectator(player, player.field_13974.method_14257());
            player.method_7336(class_1934.field_9219);
        }
        // Set health and hunger
        player.method_6033(2.0f); // 1 heart
        player.method_7344().method_7580(6); // 1.5 hunger shanks

        return true; // keep updating each tick
    }

    @Override
    public boolean method_5552(int duration, int amplifier) {
        return true; // Called every tick
    }

    // Internal registration of the status effect
    public static final class_6880<class_1291> PALE_DEATH =
            class_2378.method_47985(class_7923.field_41174, class_2960.method_60655("the_tower", "pale_death"), new pale_death_init());

    public static void load(){}

}