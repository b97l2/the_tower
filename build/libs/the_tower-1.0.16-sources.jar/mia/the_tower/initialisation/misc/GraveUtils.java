package mia.the_tower.initialisation.misc;

import mia.the_tower.initialisation.block_init;
import mia.the_tower.initialisation.blockentity.StorageTemplateBlockEntity;
import net.minecraft.class_1264;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import java.util.ArrayList;
import java.util.List;

public final class GraveUtils {
    private GraveUtils() {}

    /** Copy main, hotbar, armor, offhand (everything in PlayerInventory). */
    public static List<class_1799> snapshotPlayerInventory(class_3222 player) {
        var inv = player.method_31548();
        List<class_1799> out = new ArrayList<>(inv.field_7547.size() + inv.field_7548.size() + inv.field_7544.size());
        // main (includes hotbar)
        for (class_1799 s : inv.field_7547) out.add(s.method_7972());
        // armor
        for (class_1799 s : inv.field_7548) out.add(s.method_7972());
        // offhand
        for (class_1799 s : inv.field_7544) out.add(s.method_7972());
        return out;
    }

    /** Wipe all player stacks so vanilla has nothing to drop. */
    public static void clearPlayerInventory(class_3222 player) {
        var inv = player.method_31548();
        for (int i = 0; i < inv.field_7547.size(); i++) inv.field_7547.set(i, class_1799.field_8037);
        for (int i = 0; i < inv.field_7548.size(); i++) inv.field_7548.set(i, class_1799.field_8037);
        for (int i = 0; i < inv.field_7544.size(); i++) inv.field_7544.set(i, class_1799.field_8037);
        player.field_7512.method_7623(); // keep client in sync
    }

    /** Restore back to player (fallback path). */
    public static void restoreToPlayer(class_3222 player, List<class_1799> stacks) {
        var inv = player.method_31548();
        int idx = 0;
        for (; idx < inv.field_7547.size() && idx < stacks.size(); idx++) inv.field_7547.set(idx, stacks.get(idx));
        // armor
        for (int a = 0; a < inv.field_7548.size() && idx < stacks.size(); a++, idx++) inv.field_7548.set(a, stacks.get(idx));
        // offhand
        for (int o = 0; o < inv.field_7544.size() && idx < stacks.size(); o++, idx++) inv.field_7544.set(o, stacks.get(idx));
        player.field_7512.method_7623();
    }

    /** Try to place the grave and insert stacks; drop overflow. */
    public static boolean placeAndFillGrave(class_3218 world, class_2338 pos, class_3222 owner, List<class_1799> stacks) {
        class_2680 state = block_init.GRAVESTONE.method_9564();
        if (!canPlaceAt(world, pos)) pos = findSafeGravePos(world, pos);

        if (!world.method_8501(pos, state)) return false;

        class_2586 be = world.method_8321(pos);
        if (!(be instanceof StorageTemplateBlockEntity grave)) return false;

        // Insert all stacks, dropping leftovers at the grave if it overflows.
        for (class_1799 s : stacks) {
            if (s.method_7960()) continue;
            s = s.method_7972(); // do not mutate snapshot list
            s = insertAsMuchAsPossible(grave, s);
            if (!s.method_7960()) class_1264.method_5449(world, pos.method_10263() + 0.5, pos.method_10264() + 1, pos.method_10260() + 0.5, s);
        }
        grave.method_5431();
        world.method_8413(pos, state, state, 3);
        return true;
    }

    /** Simple “merge then fill empty” inserter. Adjust to your BE’s API. */
    private static class_1799 insertAsMuchAsPossible(StorageTemplateBlockEntity inv, class_1799 stack) {
        // 1) merge into existing stacks
        for (int i = 0; i < inv.method_5439() && !stack.method_7960(); i++) {
            var slot = inv.method_5438(i);
            if (!slot.method_7960() && class_1799.method_7984(slot, stack) && slot.method_7947() < slot.method_7914()) {
                int toMove = Math.min(slot.method_7914() - slot.method_7947(), stack.method_7947());
                if (toMove > 0) {
                    slot.method_7933(toMove);
                    stack.method_7934(toMove);
                    inv.method_5447(i, slot);
                }
            }
        }
        // 2) fill empty slots
        for (int i = 0; i < inv.method_5439() && !stack.method_7960(); i++) {
            if (inv.method_5438(i).method_7960()) {
                inv.method_5447(i, stack.method_7972());
                stack.method_7939(0);
            }
        }
        return stack; // leftover (if any)
    }

    private static boolean isReplaceable(class_3218 world, class_2338 pos) {
        return world.method_8320(pos).method_45474();
    }

     /* New policy:
            * - If below world bottom (void), clamp to bottomY + 1 (can be in air).
            * - Allow air or fluids (any replaceable) without adjustment.
            * - If inside a non-replaceable block, move up until we find a replaceable one.
     * - Do not require solid ground underneath.
            */
    public static class_2338 findSafeGravePos(class_3218 world, class_2338 deathPos) {
        final int minY = world.method_31607();
        final int maxY = world.method_31600() - 1; // highest buildable Y in most mappings

        // Start from the death position, clamped to the world height range.
        class_2338 pos = deathPos;
        if (pos.method_10264() < minY) pos = new class_2338(pos.method_10263(), minY + 1, pos.method_10260());
        if (pos.method_10264() > maxY) pos = new class_2338(pos.method_10263(), maxY, pos.method_10260());

        // If not replaceable, nudge upward until we find a replaceable block or hit the ceiling.
        int guard = (maxY - pos.method_10264()) + 2; // simple safety cap
        while (guard-- > 0 && !isReplaceable(world, pos) && pos.method_10264() < maxY) {
            pos = pos.method_10084();
        }
        return pos;
    }

    /** With the new policy, "can we place here" simply means "is this block replaceable". */
    private static boolean canPlaceAt(class_3218 world, class_2338 pos) {
        return isReplaceable(world, pos);
    }

    // In your placeAndFillGrave(...), keep calling findSafeGravePos(...) before setBlockState(...)
    // and keep the overflow/drop + restore fallback exactly as you had it.
}
