package mia.the_tower.initialisation.misc;

import mia.the_tower.initialisation.items.DeathMarkerItem;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1928;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4208;
import java.util.List;

public final class ModDeaths {
    public static void init() {
        //fills grave
        ServerLivingEntityEvents.ALLOW_DEATH.register(ModDeaths::onAllowDeath);

        //give player note
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            if (alive) return; // only run on death respawn, not dimension change

            class_4208 gp = newPlayer.method_43122().orElse(null);
            if (gp == null) gp = oldPlayer.method_43122().orElse(null);
            if (gp == null) return; // no recorded death location (very early cases)

            class_1799 marker = DeathMarkerItem.of(gp);
            newPlayer.method_31548().method_7398(marker);
        });
    }

    // Return true to let death proceed (we do); false would cancel death entirely.
    private static boolean onAllowDeath(class_1309 entity, class_1282 src, float amount) {
        if (!(entity instanceof class_3222 player)) return true;

        class_3218 world = player.method_51469();
        // Respect keepInventory and creative/spectator
        if (world.method_64395().method_8355(class_1928.field_19389)) return true;
        if (player.method_7337() || player.method_7325()) return true;

        // 1) Snapshot everything we plan to store
        List<class_1799> snapshot = GraveUtils.snapshotPlayerInventory(player);
        if (snapshot.isEmpty()) return true;

        // 2) Clear the player so vanilla has nothing to drop
        GraveUtils.clearPlayerInventory(player);

        // 3) Place + fill the grave
        class_2338 base = class_2338.method_49638(player.method_19538());
        class_2338 gravePos = GraveUtils.findSafeGravePos(world, base);
        boolean placed = GraveUtils.placeAndFillGrave(world, gravePos, player, snapshot);

        // If placement somehow failed, put stacks back so vanilla can drop them as usual.
        if (!placed) GraveUtils.restoreToPlayer(player, snapshot);


        return true;
    }
}
