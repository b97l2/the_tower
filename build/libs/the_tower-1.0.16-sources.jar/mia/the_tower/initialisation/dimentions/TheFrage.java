package mia.the_tower.initialisation.dimentions;

import java.util.OptionalLong;
import net.minecraft.class_1937;
import net.minecraft.class_2874;
import net.minecraft.class_2960;
import net.minecraft.class_3481;
import net.minecraft.class_5321;
import net.minecraft.class_5363;
import net.minecraft.class_6019;
import net.minecraft.class_7134;
import net.minecraft.class_7891;
import net.minecraft.class_7924;

public class TheFrage {
    public static final class_5321<class_5363> THE_FRAGE_KEY = class_5321.method_29179(class_7924.field_41224,
            class_2960.method_60655("the_tower", "the_frage"));
    public static final class_5321<class_1937> THE_FRAGE_LEVEL_KEY = class_5321.method_29179(class_7924.field_41223,
            class_2960.method_60655("the_tower", "the_frage"));
    public static final class_5321<class_2874> THE_FRAGE_TYPE = class_5321.method_29179(class_7924.field_41241,
            class_2960.method_60655("the_tower", "the_frage_type"));

    public static void bootstrapType(class_7891<class_2874> context) {
        context.method_46838(THE_FRAGE_TYPE, new class_2874(
                OptionalLong.empty(), //OptionalLong.of(12000), // fixedTime
                true, // hasSkylight
                false, // hasCeiling
                false, // ultraWarm
                true, // natural
                1.0, // coordinateScale
                true, // bedWorks
                true, // respawnAnchorWorks
                -160, // minY
                640, // height
                640, // logicalHeight
                class_3481.field_25588, // infiniburn
                class_7134.field_37670, // effectsLocation
                3.0f, // ambientLight
                new class_2874.class_7512(false, false, class_6019.method_35017(0, 0), 0)));
    }

    public static void load(){}

}
