package mia.the_tower.initialisation;

import mia.the_tower.The_Tower;
import net.minecraft.block.*;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1922;
import net.minecraft.class_1935;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3726;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class crop_init {
    // This is where we create new crop blocks
    public static final class_2248 GLUH_VINE = registerBlock("gluh_vine",
                new crop_init.CustomCropBlock(class_4970.class_2251.method_9630(class_2246.field_10293)
                        .method_22488()
                        .method_9634()
                        .method_9640()
                        .method_9618()
                        .method_9626(class_2498.field_17580)
                        .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "gluh_vine")))
                )
        );

    // Define your custom crop block class
    public static class CustomCropBlock extends class_2302 {
        private static final class_265[] AGE_TO_SHAPE = new class_265[]{
                class_2248.method_9541(0.0D, 0.0D, 0.0D, 16.0D, 2.0D, 16.0D),
                class_2248.method_9541(0.0D, 0.0D, 0.0D, 16.0D, 3.0D, 16.0D),
                class_2248.method_9541(0.0D, 0.0D, 0.0D, 16.0D, 4.0D, 16.0D),
                class_2248.method_9541(0.0D, 0.0D, 0.0D, 16.0D, 5.0D, 16.0D),
                class_2248.method_9541(0.0D, 0.0D, 0.0D, 16.0D, 6.0D, 16.0D),
                class_2248.method_9541(0.0D, 0.0D, 0.0D, 16.0D, 7.0D, 16.0D),
                class_2248.method_9541(0.0D, 0.0D, 0.0D, 16.0D, 8.0D, 16.0D),
                class_2248.method_9541(0.0D, 0.0D, 0.0D, 16.0D, 9.0D, 16.0D)
        };

        public CustomCropBlock(class_4970.class_2251 settings) {
            super(settings);
        }

        @Override
        protected class_1935 method_9832() {
            return item_init.GLUH;
        }

        @Override
        protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
            return AGE_TO_SHAPE[this.method_9829(state)];
        }

    }

    public static class_2248 registerBlock(String name, class_2248 block) { //this is the method to load a new (non item) block
        class_2960 id = class_2960.method_60655("the_tower", name);
        class_5321<class_2248> blockKey = class_5321.method_29179(class_7924.field_41254, id);
        return class_2378.method_39197(class_7923.field_41175, blockKey, block);
    }

    public static void registerBlockItem(String name, class_2248 block) {
        class_5321<class_1792> itemKey = class_5321.method_29179(class_7924.field_41197, The_Tower.id(name));
        class_1747 blockItem = new class_1747(block, new class_1792.class_1793().method_63686(itemKey));
        item_init.register(name, blockItem);
    }

    public static void load() {
    block_init.registerBlockItem("gluh_vine",GLUH_VINE);
    } //to load into game


}
