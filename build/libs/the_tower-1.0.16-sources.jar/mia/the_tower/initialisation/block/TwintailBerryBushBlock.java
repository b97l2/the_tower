package mia.the_tower.initialisation.block;

import mia.the_tower.initialisation.entity.ModEntities;
import mia.the_tower.initialisation.item_init;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3830;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5712;

public class TwintailBerryBushBlock extends class_3830 {

    public TwintailBerryBushBlock(class_2251 settings) {
        super(settings);
    }

    @Override //new drop
    protected class_1799 method_9574(class_4538 world, class_2338 pos, class_2680 state, boolean includeData) {
        return new class_1799(item_init.TWINTAIL_BERRY);
    }

    @Override //removed damage
    protected void method_9548(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity) {
        if (entity instanceof class_1309 && entity.method_5864() != ModEntities.VOID_MOTH && entity.method_5864() != class_1299.field_20346) { //change bee to dragon once made
            entity.method_5844(state, new class_243(0.8F, 0.75, 0.8F));
        }
    }

    @Override //new drop
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        int i = (Integer)state.method_11654(field_17000);
        boolean bl = i == 3;
        if (i > 1) {
            int j = 1 + world.field_9229.method_43048(2);
            method_9577(world, pos, new class_1799(item_init.TWINTAIL_BERRY, j + (bl ? 1 : 0)));
            world.method_8396(null, pos, class_3417.field_17617, class_3419.field_15245, 1.0F, 0.8F + world.field_9229.method_43057() * 0.4F);
            class_2680 blockState = state.method_11657(field_17000, 1);
            world.method_8652(pos, blockState, class_2248.field_31028);
            world.method_43276(class_5712.field_28733, pos, class_5712.class_7397.method_43286(player, blockState));
            return class_1269.field_5812;
        } else {
            return super.method_55766(state, world, pos, player, hit);
        }
    }

}
