package mia.the_tower.initialisation.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3726;
import org.jetbrains.annotations.Nullable;

public class SpiritsBlock extends class_2383 {

    public static final MapCodec<SpiritsBlock> CODEC = method_54094(SpiritsBlock::new);

    public SpiritsBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    protected MapCodec<? extends class_2383> method_53969() {
        return field_46280;
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(field_11177, ctx.method_8042().method_10153());
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11177);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 view, class_2338 pos, class_3726 context) {

        switch ((class_2350)state.method_11654(field_11177)) {
            case field_11043:
                return class_259.method_1081(0.375F, 0F, 0.375F, 0.625F, 0.8125F, 0.625F);
            case field_11035:
                return class_259.method_1081(0.375F, 0F, 0.375F, 0.625F, 0.8125F, 0.625F);
            case field_11034:
                return class_259.method_1081(0.375F, 0F, 0.375F, 0.625F, 0.8125F, 0.625F);
            case field_11039:
                return class_259.method_1081(0.375F, 0F, 0.375F, 0.625F, 0.8125F, 0.625F);
            default:
                return class_259.method_1081(0.375F, 0F, 0.375F, 0.625F, 0.8125F, 0.625F);
        }
    }
}
