package mia.the_tower.initialisation.block;

import mia.the_tower.initialisation.particle.CustomParticles;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_5819;

public class BarrierBlock extends class_2248 {

    public BarrierBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    public void method_9615(class_2680 state, class_1937 world, class_2338 pos, class_2680 oldState, boolean notify) {
        if (!world.field_9236) {
            world.method_64310(pos, this, 10);
        }
    }

    @Override
    public void method_9588(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        boolean playerAbove = !world.method_8390(
                net.minecraft.class_1657.class,
                new class_238(pos.method_10084()),
                player -> player.method_24515().method_10074().equals(pos)
        ).isEmpty(); //checks if there is a player ontop of it

        if (!playerAbove) { //if not, then the block breaks
            world.method_22352(pos, false);
        } else {
            world.method_64310(pos, this, 10);
        }
    }

    private static final int   PARTICLES_PER_SPAWN   = 2;     // how many each time it triggers
    private static final double AREA_HALF_SIZE       = 1;   // 5x5 area => +/- 2.5 from center

    @Override
    @Environment(EnvType.CLIENT)
    public void method_9496(class_2680 state, class_1937 world, class_2338 pos, class_5819 rand) {

        for (int i = 0; i < PARTICLES_PER_SPAWN; i++) {
            double x = pos.method_10263() + 0.5 + (rand.method_43058() * (AREA_HALF_SIZE * 2.0) - AREA_HALF_SIZE);
            double z = pos.method_10260() + 0.5 + (rand.method_43058() * (AREA_HALF_SIZE * 2.0) - AREA_HALF_SIZE);
            double y = pos.method_10264() + 0.5 + (rand.method_43058() * (AREA_HALF_SIZE * 2.0) - AREA_HALF_SIZE);

            double vx = 0.0;
            double vy = 0.0;
            double vz = 0.0;

            world.method_8406(CustomParticles.GLUH_PARTICLE, x, y, z, 0.0, 0.00, 0.0);

        }
    }
}