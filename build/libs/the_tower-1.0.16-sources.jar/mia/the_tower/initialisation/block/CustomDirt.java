package mia.the_tower.initialisation.block;

import mia.the_tower.initialisation.block_init;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2320;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2756;
import net.minecraft.class_3218;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import java.util.List;

public class CustomDirt extends class_2248 implements class_2256 {
    public CustomDirt(class_2251 settings) {
        super(settings);
    }

    @Override
    public boolean method_9651(class_4538 world, class_2338 pos, class_2680 state) {
        // You can customize this logic, but here's a common check:
        return world.method_8320(pos.method_10084()).method_26215();
    }

    @Override
    public boolean method_9650(class_1937 world, class_5819 random, class_2338 pos, class_2680 state) {
        return true;
    }

    public static class_2248 pickRandomPlant(class_5819 random) {
        List<class_2248> plantPool = List.of(
                block_init.BLUE_FOXGLOVE,
                block_init.SAPPHIRE_ROSE,
                block_init.CERULEAN_PETALS,
                block_init.CERULEAN_SHORTGRASS,
                block_init.BLUE_HOSTAS,
                block_init.BLUE_BELL,
                block_init.CERULEAN_WILDGRASS
        );
        return plantPool.get(random.method_43048(plantPool.size()));
    }

    @Override
    public void method_9652(class_3218 world, class_5819 random, class_2338 pos, class_2680 state) {
// Try placing up to 32 random plants around the dirt block
        for (int i = 0; i < 32; ++i) {
            class_2338 targetPos = pos.method_10069(
                    random.method_43048(7) - 3, // x offset -3 to +3
                    1,
                    random.method_43048(7) - 3  // z offset -3 to +3
            );

            if (!world.method_8320(targetPos.method_10074()).method_27852(this)) continue;
            if (!world.method_8320(targetPos).method_26215()) continue;

            class_2248 chosen = CustomDirt.pickRandomPlant(random); // your own method to pick a plant

            // If it's a tall plant
            if (chosen instanceof class_2320) {
                if (!world.method_8320(targetPos.method_10084()).method_26215()) continue;

                class_2680 lower = chosen.method_9564().method_11657(class_2320.field_10929, class_2756.field_12607);
                class_2680 upper = chosen.method_9564().method_11657(class_2320.field_10929, class_2756.field_12609);

                world.method_8652(targetPos, lower, class_2248.field_31036);
                world.method_8652(targetPos.method_10084(), upper, class_2248.field_31036);
            }
            // If it's a custom 3-block plant
            else if (chosen instanceof ExtraTallFlower) {
                if (!world.method_8320(targetPos.method_10084()).method_26215() || !world.method_8320(targetPos.method_10086(2)).method_26215()) continue;

                world.method_8501(targetPos, chosen.method_9564().method_11657(ExtraTallFlower.THIRD, TripleBlockPart.LOWER));
                world.method_8501(targetPos.method_10084(), chosen.method_9564().method_11657(ExtraTallFlower.THIRD, TripleBlockPart.MIDDLE));
                world.method_8501(targetPos.method_10086(2), chosen.method_9564().method_11657(ExtraTallFlower.THIRD, TripleBlockPart.UPPER));
            }
            // Normal plant
            else {
                world.method_8652(targetPos, chosen.method_9564(), class_2248.field_31036);
            }
        }
    }
}