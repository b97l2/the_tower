package mia.the_tower.initialisation.block;

import mia.the_tower.initialisation.sounds.CustomSounds;
import net.minecraft.block.*;
import net.minecraft.class_1937;
import net.minecraft.class_2202;
import net.minecraft.class_2211;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2737;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_5819;
import net.minecraft.class_7924;

import static mia.the_tower.initialisation.block_init.registerBlock;

public class stake_init {

    // This is where we create new crop blocks
    public static final class_2248 STAKE = registerBlock("stake",
            new StakeBlock(class_4970.class_2251.method_9630(class_2246.field_10211)
                    .method_22488()
                    .method_9640()
                    .method_9626(CustomSounds.SCREAMING_BLOCK)
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "stake")))
            ));
    public static final class_2248 STAKE_BUD = registerBlock("stake_bud",
            new stake_init.CustomBambooShootBlock(class_4970.class_2251.method_9630(class_2246.field_10108)
                    .method_22488()
                    .method_9634()
                    .method_9618()
                    .method_9640()
                    //.sounds(BlockSoundGroup.CROP) put in custom sound
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "stake_bud")))
            )
    );


    public static class CustomBambooShootBlock extends class_2202 {
        public CustomBambooShootBlock(class_4970.class_2251 settings) {
            super(settings);
        }

        @Override
        protected void method_9514(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
            if (random.method_43048(9) == 0 && world.method_22347(pos.method_10084()) && world.method_22335(pos.method_10084(), 0) >= 1) {
                this.method_9351(world, pos);
            }
        }

        @Override
        protected void method_9351(class_1937 world, class_2338 pos) {
            world.method_8652(pos, stake_init.STAKE.method_9564()
                    .method_11657(class_2211.field_9917, class_2737.field_12469)
                    .method_11657(class_2211.field_9916, 0)
                    .method_11657(class_2211.field_9914, 0), class_2248.field_31036);
            world.method_8652(pos.method_10084(), stake_init.STAKE.method_9564().method_11657(StakeBlock.LEAVES, class_2737.field_12466), class_2248.field_31036);
        }
    }

    public static void load() {
    } //to load into game








}
