package mia.the_tower.initialisation.block;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_4970;
import net.minecraft.class_5699;
import net.minecraft.class_5819;
import net.minecraft.class_5945;

public class NonDecayingLeavesBlock extends class_2248 {
    public static final MapCodec<NonDecayingLeavesBlock> CODEC = RecordCodecBuilder.mapCodec(
            instance -> instance.group(
                            class_5699.field_33442.fieldOf("chance").forGetter(block -> block.chance),
                            class_2398.field_25125.fieldOf("particle").forGetter(block -> block.particle),
                            method_54096()
                    )
                    .apply(instance, NonDecayingLeavesBlock::new)
    );
    private final class_2394 particle;
    private final int chance;

    @Override
    public MapCodec<NonDecayingLeavesBlock> method_53969() {
        return field_46280;
    }

    public NonDecayingLeavesBlock(int chance, class_2394 particle, class_4970.class_2251 settings) {
        super(settings);
        this.chance = chance;
        this.particle = particle;
    }

    @Override
    public void method_9496(class_2680 state, class_1937 world, class_2338 pos, class_5819 random) {
        super.method_9496(state, world, pos, random);
        if (random.method_43048(this.chance) == 0) {
            class_2338 blockPos = pos.method_10074();
            class_2680 blockState = world.method_8320(blockPos);
            if (!method_9501(blockState.method_26220(world, blockPos), class_2350.field_11036)) {
                class_5945.method_49099(world, pos, random, this.particle);
            }
        }
    }
}
