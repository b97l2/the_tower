package mia.the_tower.initialisation.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2383;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import org.jetbrains.annotations.Nullable;

public class CustomHorisontalFacingBlock extends class_2383 {

    public static final MapCodec<CustomHorisontalFacingBlock> CODEC = method_54094(CustomHorisontalFacingBlock::new);

    public CustomHorisontalFacingBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    protected MapCodec<? extends class_2383> method_53969() {
        return field_46280;
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(field_11177, ctx.method_8042().method_10153());
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11177);
    }

}
