package mia.the_tower.initialisation.block;

import net.minecraft.block.*;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2465;
import net.minecraft.class_2498;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3726;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

import static mia.the_tower.initialisation.block_init.registerBlock;
import static mia.the_tower.initialisation.block_init.registerBlockItem;

public class column_init extends class_2465{

    public column_init(class_2251 settings) {
        super(settings);
    }

    public static class_2248 STONE_COLUMN = registerBlock("stone_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_9626(class_2498.field_11544)
                    .method_9629(1.5F, 8.0F)
                    .method_29292()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "stone_column")))));

    public static class_2248 COBBLESTONE_COLUMN = registerBlock("cobblestone_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_9626(class_2498.field_11544)
                    .method_9629(1.5F, 8.0F)
                    .method_29292()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "cobblestone_column")))));

    public static class_2248 SMOOTH_STONE_COLUMN = registerBlock("smooth_stone_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_9626(class_2498.field_11544)
                    .method_9629(1.5F, 8.0F)
                    .method_29292()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "smooth_stone_column")))));

    public static class_2248 STONE_BRICK_COLUMN = registerBlock("stone_brick_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_9626(class_2498.field_11544)
                    .method_9629(1.5F, 8.0F)
                    .method_29292()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "stone_brick_column")))));

    public static class_2248 BLACKSTONE_COLUMN = registerBlock("blackstone_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_9626(class_2498.field_11544)
                    .method_9629(1.5F, 8.0F)
                    .method_29292()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "blackstone_column")))));

    public static class_2248 POLISHED_BLACKSTONE_COLUMN = registerBlock("polished_blackstone_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_9626(class_2498.field_11544)
                    .method_9629(1.5F, 8.0F)
                    .method_29292()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "polished_blackstone_column")))));

    public static class_2248 POLISHED_BLACKSTONE_BRICK_COLUMN = registerBlock("polished_blackstone_brick_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_9626(class_2498.field_11544)
                    .method_9629(1.5F, 8.0F)
                    .method_29292()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "polished_blackstone_brick_column")))));

    public static class_2248 COBBLED_DEEPSLATE_COLUMN = registerBlock("cobbled_deepslate_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_9626(class_2498.field_11544)
                    .method_9629(1.5F, 8.0F)
                    .method_29292()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "cobbled_deepslate_column")))));

    public static class_2248 POLISHED_DEEPSLATE_COLUMN = registerBlock("polished_deepslate_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_9626(class_2498.field_11544)
                    .method_9629(1.5F, 8.0F)
                    .method_29292()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "polished_deepslate_column")))));

    public static class_2248 DEEPSLATE_BRICK_COLUMN = registerBlock("deepslate_brick_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_9626(class_2498.field_11544)
                    .method_9629(1.5F, 8.0F)
                    .method_29292()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "deepslate_brick_column")))));

    public static class_2248 DEEPSLATE_TILE_COLUMN = registerBlock("deepslate_tile_column",
            new column_init(class_4970.class_2251.method_9637()
                    .method_9626(class_2498.field_11544)
                    .method_9629(1.5F, 8.0F)
                    .method_29292()
                    .method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655("the_tower", "deepslate_tile_column")))));


    @Override
    public class_265 method_9530(class_2680 state, class_1922 view, class_2338 pos, class_3726 context) {
        class_2350.class_2351 axis = state.method_11654(field_11459);
        switch (axis) {
            case field_11048:
                return class_259.method_1081(0.0F, 0.25F, 0.25F, 1.0F, 0.75F, 0.75F);
            case field_11052:
                return class_259.method_1081(0.25F, 0.0F, 0.25F, 0.75F, 1.0F, 0.75F);
            case field_11051:
            default:
                return class_259.method_1081(0.25F, 0.25F, 0.0F, 0.75F, 0.75F, 1.0F);
        }

    }

    public static void load() {
        registerBlockItem("stone_column",STONE_COLUMN);
        registerBlockItem("cobblestone_column",COBBLESTONE_COLUMN);
        registerBlockItem("smooth_stone_column",SMOOTH_STONE_COLUMN);
        registerBlockItem("stone_brick_column",STONE_BRICK_COLUMN);
        registerBlockItem("blackstone_column",BLACKSTONE_COLUMN);
        registerBlockItem("polished_blackstone_column",POLISHED_BLACKSTONE_COLUMN);
        registerBlockItem("polished_blackstone_brick_column",POLISHED_BLACKSTONE_BRICK_COLUMN);
        registerBlockItem("cobbled_deepslate_column",COBBLED_DEEPSLATE_COLUMN);
        registerBlockItem("polished_deepslate_column",POLISHED_DEEPSLATE_COLUMN);
        registerBlockItem("deepslate_brick_column",DEEPSLATE_BRICK_COLUMN);
        registerBlockItem("deepslate_tile_column",DEEPSLATE_TILE_COLUMN);
    } //to load into game

}
