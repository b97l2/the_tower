package mia.the_tower.initialisation.block;

import net.minecraft.class_10225;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_2756;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.class_5819;

public class MarkerBlock extends class_2248 {
    public static final class_2754<class_2756> HALF = class_2741.field_12533;
    public static final class_2754<class_2350> FACING = class_2754.method_11850("facing", class_2350.class);

    public MarkerBlock(class_2251 settings) {
        super(settings);
        this.method_9590(this.field_10647.method_11664()
                .method_11657(FACING, class_2350.field_11036)
                .method_11657(HALF, class_2756.field_12607));
    }

    @Override
    public class_2680 method_9605(class_1750 ctx) {
        class_2350 direction = ctx.method_8038(); // This is the face the player clicked
        class_2338 pos = ctx.method_8037();
        class_1937 world = ctx.method_8045();

        class_2338 topPos = pos.method_10093(direction);
        if (!world.method_8320(topPos).method_26166(ctx)) {
            return null;
        }

        return this.method_9564()
                .method_11657(FACING, direction)
                .method_11657(HALF, class_2756.field_12607);
    }

    @Override
    public void method_9567(class_1937 world, class_2338 pos, class_2680 state, class_1309 placer, class_1799 itemStack) {
        super.method_9567(world, pos, state, placer, itemStack);
        class_2350 direction = state.method_11654(FACING);
        class_2338 upperPos = pos.method_10093(direction);

        class_2680 upperState = this.method_9564()
                .method_11657(FACING, direction)
                .method_11657(HALF, class_2756.field_12609);

        world.method_8652(upperPos, upperState, class_2248.field_31036);
    }

    @Override
    public class_2680 method_9576(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
        class_2756 half = state.method_11654(HALF);
        class_2350 direction = state.method_11654(FACING);
        class_2338 otherPos = (half == class_2756.field_12607) ? pos.method_10093(direction) : pos.method_10093(direction.method_10153());
        class_2680 otherState = world.method_8320(otherPos);

        if (otherState.method_27852(this) && otherState.method_11654(HALF) != half) {
            world.method_22352(otherPos, false);
        }
        return super.method_9576(world, pos, state, player);
    }

    @Override
    public class_2680 method_9559(
            class_2680 state,
            class_4538 world,
            class_10225 tickView,
            class_2338 pos,
            class_2350 direction,
            class_2338 neighborPos,
            class_2680 neighborState,
            class_5819 random
    ) {
        class_2756 half = state.method_11654(HALF);
        class_2350 facing = state.method_11654(FACING);
        class_2350 expected = (half == class_2756.field_12607) ? facing : facing.method_10153();

        if (direction == expected) {
            if (!neighborState.method_27852(this) || neighborState.method_11654(HALF) == half) {
                return class_2246.field_10124.method_9564();
            }
        }

        return state;
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, HALF);
    }

    @Override
    public boolean method_9526(class_2680 state) {
        return true;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return class_259.method_1073();
    }

}
