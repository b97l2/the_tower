package mia.the_tower.initialisation.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.class_10225;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2261;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2754;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import net.minecraft.class_6088;
import org.jetbrains.annotations.Nullable;

public class ExtraTallFlower extends class_2261 {
    public static final class_2754<TripleBlockPart> THIRD = class_2754.method_11850("third", TripleBlockPart.class);

    public static final MapCodec<ExtraTallFlower> CODEC = method_54094(ExtraTallFlower::new);

    @Override
    public MapCodec<? extends ExtraTallFlower> method_53969() {
        return field_46280;
    }

    public ExtraTallFlower(class_2251 settings) {
        super(settings);
        this.method_9590(this.field_10647.method_11664().method_11657(THIRD, TripleBlockPart.LOWER));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(THIRD);
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        class_2338 pos = ctx.method_8037();
        class_1937 world = ctx.method_8045();

        if (pos.method_10264() + 2 > world.method_31600()) return null;

        if (world.method_8320(pos.method_10084()).method_26166(ctx) &&
                world.method_8320(pos.method_10086(2)).method_26166(ctx)) {
            return super.method_9605(ctx).method_11657(THIRD, TripleBlockPart.LOWER);
        }

        return null;
    }

    @Override
    public void method_9567(class_1937 world, class_2338 pos, class_2680 state, class_1309 placer, class_1799 itemStack) {
        world.method_8652(pos.method_10084(), this.method_9564().method_11657(THIRD, TripleBlockPart.MIDDLE), class_2248.field_31036);
        world.method_8652(pos.method_10086(2), this.method_9564().method_11657(THIRD, TripleBlockPart.UPPER), class_2248.field_31036);
    }

    @Override
    public class_2680 method_9576(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
        if (!world.field_9236) {
            if (player.method_7337()) {
                // Prevent drops and cleanly remove the whole stack like vanilla
                onBreakInCreative(world, pos, state, player);
            } else {
                // Your existing survival behavior (break the other parts with drops)
                TripleBlockPart third = state.method_11654(THIRD);
                if (third == TripleBlockPart.UPPER) {
                    world.method_22352(pos.method_10074(), true);
                    world.method_22352(pos.method_10087(2), true);
                } else if (third == TripleBlockPart.MIDDLE) {
                    world.method_22352(pos.method_10074(), true);
                    world.method_22352(pos.method_10084(),   true);
                } else {
                    world.method_22352(pos.method_10084(),   true);
                    world.method_22352(pos.method_10086(2),  true);
                }
            }
        }
        return super.method_9576(world, pos, state, player);
    }


    private static void onBreakInCreative(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
        TripleBlockPart part = state.method_11654(THIRD);

        // Resolve the full stack origin (lower/middle/upper -> lower)
        class_2338 lower = switch (part) {
            case LOWER -> pos;
            case MIDDLE -> pos.method_10074();
            case UPPER -> pos.method_10087(2);
        };
        class_2338 middle = lower.method_10084();
        class_2338 upper  = lower.method_10086(2);

        // Clear each section without drops and with a break animation
        clearNoDrop(world, lower,  player);
        clearNoDrop(world, middle, player);
        clearNoDrop(world, upper,  player);
    }

    private static void clearNoDrop(class_1937 world, class_2338 p, class_1657 player) {
        class_2680 s = world.method_8320(p);
        if (s.method_26204() instanceof ExtraTallFlower) {
            world.method_8652(p, class_2246.field_10124.method_9564(), class_2248.field_31036 | class_2248.field_31032);
            world.method_8444(player, class_6088.field_31144, p, class_2248.method_9507(s));
        }
    }


    @Override
    protected boolean method_9558(class_2680 state, class_4538 world, class_2338 pos) {
        TripleBlockPart third = state.method_11654(THIRD);
        switch (third) {
            case LOWER:
                return super.method_9558(state, world, pos);
            case MIDDLE:
                return world.method_8320(pos.method_10074()).method_27852(this) &&
                        world.method_8320(pos.method_10074()).method_11654(THIRD) == TripleBlockPart.LOWER;
            case UPPER:
                return world.method_8320(pos.method_10074()).method_27852(this) &&
                        world.method_8320(pos.method_10074()).method_11654(THIRD) == TripleBlockPart.MIDDLE;
            default:
                return false;
        }
    }

    @Override //this is for when the block is placed via features, it places the top two parts itself
    public void method_9615(class_2680 state, class_1937 world, class_2338 pos, class_2680 oldState, boolean notify) {
        super.method_9615(state, world, pos, oldState, notify);
        if (world.field_9236) return;

        // Only bootstrap from the LOWER part
        if (!state.method_27852(this) || state.method_11654(THIRD) != TripleBlockPart.LOWER) return;

        // Y-bounds & simple replaceability checks (air is enough for vegetation patches)
        if (pos.method_10264() + 2 > world.method_31600()) return;
        class_2338 mid = pos.method_10084();
        class_2338 top = pos.method_10086(2);
        if (!world.method_8320(mid).method_26215() || !world.method_8320(top).method_26215()) return;

        world.method_8652(mid, this.method_9564().method_11657(THIRD, TripleBlockPart.MIDDLE), class_2248.field_31036);
        world.method_8652(top, this.method_9564().method_11657(THIRD, TripleBlockPart.UPPER),  class_2248.field_31036);
    }

    @Override
    protected class_2680 method_9559(class_2680 state, class_4538 world, class_10225 tickView,
                                                   class_2338 pos, class_2350 dir, class_2338 neighborPos,
                                                   class_2680 neighborState, class_5819 random) {
        TripleBlockPart third = state.method_11654(THIRD);
        boolean valid = switch (third) {
            case LOWER -> world.method_8320(pos.method_10084()).method_27852(this) &&
                    world.method_8320(pos.method_10084()).method_11654(THIRD) == TripleBlockPart.MIDDLE;
            case MIDDLE -> world.method_8320(pos.method_10074()).method_27852(this) &&
                    world.method_8320(pos.method_10074()).method_11654(THIRD) == TripleBlockPart.LOWER &&
                    world.method_8320(pos.method_10084()).method_27852(this) &&
                    world.method_8320(pos.method_10084()).method_11654(THIRD) == TripleBlockPart.UPPER;
            case UPPER -> world.method_8320(pos.method_10074()).method_27852(this) &&
                    world.method_8320(pos.method_10074()).method_11654(THIRD) == TripleBlockPart.MIDDLE;
        };

        return valid ? state : class_2246.field_10124.method_9564();
    }
}