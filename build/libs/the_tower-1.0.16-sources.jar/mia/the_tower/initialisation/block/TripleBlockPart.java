package mia.the_tower.initialisation.block;

import net.minecraft.class_3542;

public enum TripleBlockPart implements class_3542 {
    LOWER("lower"),
    MIDDLE("middle"),
    UPPER("upper");

    private final String name;

    TripleBlockPart(String name) {
        this.name = name;
    }

    @Override
    public String method_15434() {
        return this.name;
    }
}