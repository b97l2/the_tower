package mia.the_tower.initialisation.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.class_10;
import net.minecraft.class_10225;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1829;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2737;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_2758;
import net.minecraft.class_3218;
import net.minecraft.class_3481;
import net.minecraft.class_3610;
import net.minecraft.class_3726;
import net.minecraft.class_4538;
import net.minecraft.class_4970;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

public class StakeBlock extends class_2248 implements class_2256 {
    public static final MapCodec<StakeBlock> CODEC = method_54094(StakeBlock::new);
    protected static final float field_30997 = 3.0F;
    protected static final float field_30998 = 5.0F;
    protected static final float field_30999 = 1.5F;
    protected static final class_265 SMALL_LEAVES_SHAPE = class_2248.method_9541(5.0, 0.0, 5.0, 11.0, 16.0, 11.0);
    protected static final class_265 LARGE_LEAVES_SHAPE = class_2248.method_9541(3.0, 0.0, 3.0, 13.0, 16.0, 13.0);
    protected static final class_265 NO_LEAVES_SHAPE = class_2248.method_9541(6.5, 0.0, 6.5, 9.5, 16.0, 9.5);
    public static final class_2758 AGE = class_2741.field_12521;
    public static final class_2754<class_2737> LEAVES = class_2741.field_12516;
    public static final class_2758 STAGE = class_2741.field_12549;
    public static final int field_31000 = 27;
    public static final int field_31001 = 0;
    public static final int field_31002 = 1;
    public static final int field_31003 = 0;
    public static final int field_31004 = 1;

    @Override
    public MapCodec<StakeBlock> method_53969() {
        return field_46280;
    }

    public StakeBlock(class_4970.class_2251 settings) {
        super(settings);
        this.method_9590(this.field_10647.method_11664().method_11657(AGE, 0).method_11657(LEAVES, class_2737.field_12469).method_11657(STAGE, 0));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(AGE, LEAVES, STAGE);
    }

    @Override
    protected boolean method_9579(class_2680 state) {
        return true;
    }

    @Override
    protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        class_265 voxelShape = state.method_11654(LEAVES) == class_2737.field_12468 ? LARGE_LEAVES_SHAPE : SMALL_LEAVES_SHAPE;
        class_243 vec3d = state.method_26226(pos);
        return voxelShape.method_1096(vec3d.field_1352, vec3d.field_1351, vec3d.field_1350);
    }

    @Override
    protected boolean method_9516(class_2680 state, class_10 type) {
        return false;
    }

    @Override
    protected class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        class_243 vec3d = state.method_26226(pos);
        return NO_LEAVES_SHAPE.method_1096(vec3d.field_1352, vec3d.field_1351, vec3d.field_1350);
    }

    @Override
    protected boolean method_37403(class_2680 state, class_1922 world, class_2338 pos) {
        return false;
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        class_3610 fluidState = ctx.method_8045().method_8316(ctx.method_8037());
        if (!fluidState.method_15769()) {
            return null;
        } else {
            class_2680 blockState = ctx.method_8045().method_8320(ctx.method_8037().method_10074());
            if (blockState.method_26164(class_3481.field_15497)) {
                if (blockState.method_27852(stake_init.STAKE_BUD)) {
                    return this.method_9564().method_11657(AGE, 0);
                } else if (blockState.method_27852(stake_init.STAKE)) {
                    int i = blockState.method_11654(AGE) > 0 ? 1 : 0;
                    return this.method_9564().method_11657(AGE, i);
                } else {
                    class_2680 blockState2 = ctx.method_8045().method_8320(ctx.method_8037().method_10084());
                    return blockState2.method_27852(stake_init.STAKE) ? this.method_9564().method_11657(AGE, (Integer)blockState2.method_11654(AGE)) : stake_init.STAKE_BUD.method_9564();
                }
            } else {
                return null;
            }
        }
    }

    @Override
    protected void method_9588(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        if (!state.method_26184(world, pos)) {
            world.method_22352(pos, true);
        }
    }

    @Override
    protected boolean method_9542(class_2680 state) {
        return (Integer)state.method_11654(STAGE) == 0;
    }

    @Override
    protected void method_9514(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        if ((Integer)state.method_11654(STAGE) == 0) {
            if (random.method_43048(20) == 0 && world.method_22347(pos.method_10084()) && world.method_22335(pos.method_10084(), 0) >= 1) {
                int i = this.countBambooBelow(world, pos) + 1;
                if (i < 27) {
                    this.updateLeaves(state, world, pos, random, i);
                }
            }
        }
    }

    @Override
    protected boolean method_9558(class_2680 state, class_4538 world, class_2338 pos) {
        return world.method_8320(pos.method_10074()).method_26164(class_3481.field_15497)
                || world.method_8320(pos.method_10074()).method_27852(stake_init.STAKE)
                || world.method_8320(pos.method_10074()).method_27852(stake_init.STAKE_BUD);
    }

    @Override
    protected class_2680 method_9559(
            class_2680 state,
            class_4538 world,
            class_10225 tickView,
            class_2338 pos,
            class_2350 direction,
            class_2338 neighborPos,
            class_2680 neighborState,
            class_5819 random
    ) {
        if (!state.method_26184(world, pos)) {
            tickView.method_64310(pos, this, 1);
        }

        return direction == class_2350.field_11036 && neighborState.method_27852(stake_init.STAKE) && neighborState.method_11654(AGE) > state.method_11654(AGE)
                ? state.method_28493(AGE)
                : super.method_9559(state, world, tickView, pos, direction, neighborPos, neighborState, random);
    }

    @Override
    public boolean method_9651(class_4538 world, class_2338 pos, class_2680 state) {
        int i = this.countBambooAbove(world, pos);
        int j = this.countBambooBelow(world, pos);
        return i + j + 1 < 27 && (Integer)world.method_8320(pos.method_10086(i)).method_11654(STAGE) != 1;
    }

    @Override
    public boolean method_9650(class_1937 world, class_5819 random, class_2338 pos, class_2680 state) {
        return true;
    }

    @Override
    public void method_9652(class_3218 world, class_5819 random, class_2338 pos, class_2680 state) {
        int i = this.countBambooAbove(world, pos);
        int j = this.countBambooBelow(world, pos);
        int k = i + j + 1;
        int l = 1 + random.method_43048(2);

        for (int m = 0; m < l; m++) {
            class_2338 blockPos = pos.method_10086(i);
            class_2680 blockState = world.method_8320(blockPos);
            if (k >= 27 || (Integer)blockState.method_11654(STAGE) == 1 || !world.method_22347(blockPos.method_10084())) {
                return;
            }

            this.updateLeaves(blockState, world, blockPos, random, k);
            i++;
            k++;
        }
    }

    @Override
    protected float method_9594(class_2680 state, class_1657 player, class_1922 world, class_2338 pos) {
        return player.method_6047().method_7909() instanceof class_1829 ? 1.0F : super.method_9594(state, player, world, pos);
    }

    protected void updateLeaves(class_2680 state, class_1937 world, class_2338 pos, class_5819 random, int height) {
        class_2680 blockState = world.method_8320(pos.method_10074());
        class_2338 blockPos = pos.method_10087(2);
        class_2680 blockState2 = world.method_8320(blockPos);
        class_2737 bambooLeaves = class_2737.field_12469;
        if (height >= 1) {
            if (!blockState.method_27852(stake_init.STAKE) || blockState.method_11654(LEAVES) == class_2737.field_12469) {
                bambooLeaves = class_2737.field_12466;
            } else if (blockState.method_27852(stake_init.STAKE) && blockState.method_11654(LEAVES) != class_2737.field_12469) {
                bambooLeaves = class_2737.field_12468;
                if (blockState2.method_27852(stake_init.STAKE)) {
                    world.method_8652(pos.method_10074(), blockState.method_11657(LEAVES, class_2737.field_12466), class_2248.field_31036);
                    world.method_8652(blockPos, blockState2.method_11657(LEAVES, class_2737.field_12469), class_2248.field_31036);
                }
            }
        }

        int i = state.method_11654(AGE) != 1 && !blockState2.method_27852(stake_init.STAKE) ? 0 : 1;
        int j = (height < 22 || !(random.method_43057() < 0.25F)) && height != 26 ? 0 : 1;
        world.method_8652(pos.method_10084(), this.method_9564().method_11657(AGE, i).method_11657(LEAVES, bambooLeaves).method_11657(STAGE, j), class_2248.field_31036);
    }

    protected int countBambooAbove(class_1922 world, class_2338 pos) {
        int i = 0;

        while (i < 27 && world.method_8320(pos.method_10086(i + 1)).method_27852(stake_init.STAKE)) {
            i++;
        }

        return i;
    }

    protected int countBambooBelow(class_1922 world, class_2338 pos) {
        int i = 0;

        while (i < 27 && world.method_8320(pos.method_10087(i + 1)).method_27852(stake_init.STAKE)) {
            i++;
        }

        return i;
    }
}
