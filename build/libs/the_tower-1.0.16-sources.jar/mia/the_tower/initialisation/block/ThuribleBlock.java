package mia.the_tower.initialisation.block;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_3749;
import net.minecraft.class_4970;
import net.minecraft.class_5819;

public class ThuribleBlock extends class_3749 {

    public static final MapCodec<ThuribleBlock> CODEC = RecordCodecBuilder.mapCodec(
            instance -> instance.group(
                            class_2398.field_25125.fieldOf("particle").forGetter(block -> block.particle),
                            method_54096()
                    )
                    .apply(instance, ThuribleBlock::new)
    );

    private static final int   PARTICLES_PER_SPAWN   = 2;     // how many each time it triggers
    private static final double AREA_HALF_SIZE       = 2.5;   // 5x5 area => +/- 2.5 from center
    private final class_2394 particle;

    public ThuribleBlock(class_2394 particle, class_4970.class_2251 settings) {
        super(settings);
        this.particle = particle;
    }

    @Override
    @Environment(EnvType.CLIENT)
    public void method_9496(class_2680 state, class_1937 world, class_2338 pos, class_5819 rand) {
        // ~20% chance per client tick
        final double baseY = pos.method_10264() + (state.method_11654(field_16545) ? 0.30 : 0.70);

        for (int i = 0; i < PARTICLES_PER_SPAWN; i++) {
            double x = pos.method_10263() + 0.5 + (rand.method_43058() * (AREA_HALF_SIZE * 2.0) - AREA_HALF_SIZE);
            double z = pos.method_10260() + 0.5 + (rand.method_43058() * (AREA_HALF_SIZE * 2.0) - AREA_HALF_SIZE);
            double y = baseY + (rand.method_43058() * 0.15 - 0.05); // small vertical jitter

            double vx = 0.0;
            double vy = 0.0; //0.01 + rand.nextDouble() * 0.01;
            double vz = 0.0;

            world.method_8406(particle, x, y, z, 0.0, 0.00, 0.0);

            // Example: only if not waterlogged
            // if (!state.get(WATERLOGGED)) { ... }
        }
    }

}
