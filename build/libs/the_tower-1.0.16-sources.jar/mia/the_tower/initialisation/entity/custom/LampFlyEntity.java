package mia.the_tower.initialisation.entity.custom;

import mia.the_tower.initialisation.entity.goal.DreamyArcFlightGoal;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1331;
import net.minecraft.class_1407;
import net.minecraft.class_1408;
import net.minecraft.class_1421;
import net.minecraft.class_1432;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3730;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_5425;
import net.minecraft.class_7094;
import net.minecraft.entity.*;

public class LampFlyEntity extends class_1421 implements class_1432{
    public final class_7094 idleAnimationState = new class_7094();
    private int idleAnimationTimeout = 0;
    public final class_7094 flyAnimationState = new class_7094();

    public LampFlyEntity(class_1299<? extends class_1421> entityType, class_1937 world) {
        super(entityType, world);
        this.field_6207 = new class_1331(this, 12, true);
        this.method_5875(true);
    }


    @Override
    protected class_1408 method_5965(class_1937 world) {
        class_1407 nav = new class_1407(this, world);
        nav.method_6354(false);
        nav.method_6332(false);
        return nav;
    }

    @Override
    public boolean method_5810() {
        return false;
    }

    @Override
    public boolean method_6581() {
        return !this.method_24828();
    }

    @Override
    public boolean method_5747(float fallDistance, float damageMultiplier, class_1282 source) {
        return false;
    }

    @Override
    protected void method_5959() {
        //this.goalSelector.add(0, new PerchGoal(this, 20));
        this.field_6201.method_6277(0, new DreamyArcFlightGoal(this,
                /*baseSpeed*/ 0.65,  // movement speed passed to moveControl
                /*minRadius*/ 5.0,    // horizontal orbit radius range
                /*maxRadius*/ 10.0,
                /*vertAmp*/   1.8,    // vertical sine amplitude
                /*omega*/     0.035,  // angular speed (radians/tick) — smaller = slower arcs
                /*anchorDriftSec*/ 12 // seconds between slow anchor drifts
        ));
    }



    public static boolean canSpawn(class_1299<LampFlyEntity> type,
                                   class_5425 world,
                                   class_3730 reason,
                                   class_2338 pos,
                                   net.minecraft.class_5819 random) {
        if (!world.method_22347(pos) || !world.method_22347(pos.method_10084())) return false;
        //if (world.getLightLevel(pos) > 3) return false;
        return true;
    }

    @Override
    public boolean method_5974(double distanceSquared) {
        return true; // typical ambient behavior
    }

    public static class_5132.class_5133 createAttributes() {
        return class_1308.method_26828()
                .method_26868(class_5134.field_23716, 1)
                .method_26868(class_5134.field_23719, 0.4)
                .method_26868(class_5134.field_23720, 0.5)
                .method_26868(class_5134.field_23717, 40)
                .method_26868(class_5134.field_52450, 30)
                ;
    }

    private void setupAnimationStates() {
        if (this.idleAnimationTimeout <= 0) {
            this.idleAnimationTimeout = 20*2;
            this.idleAnimationState.method_41322(this.field_6012);
        } else {
            --this.idleAnimationTimeout;
        }

        if (method_6581()) {
            if (!this.flyAnimationState.method_41327()) {
                this.flyAnimationState.method_41322(this.field_6012);
            }
        } else {
            this.flyAnimationState.method_41325();
        }

    }

    @Override
    public void method_5773() {
        super.method_5773();

        if (this.method_37908().method_8608()) {
            this.setupAnimationStates();
        }
        if (!this.method_24828()) {
            var v = this.method_18798();
            this.method_18800(v.field_1352 * 0.96, v.field_1351 * 0.90, v.field_1350 * 0.96);
        }
    }

}
