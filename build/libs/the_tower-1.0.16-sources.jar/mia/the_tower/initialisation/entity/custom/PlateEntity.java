package mia.the_tower.initialisation.entity.custom;

import mia.the_tower.initialisation.entity.ModEntities;
import net.minecraft.class_1299;
import net.minecraft.class_1533;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;

public class PlateEntity extends class_1533 {
    public PlateEntity(class_1299<? extends class_1533> type, class_1937 world) {
        super(type, world);
    }
    public PlateEntity(class_1937 world, class_2338 pos, class_2350 side) {
        super(ModEntities.PLATE, world, pos, side); // your registry constant
    }

    // Optional: change physical size in pixels if you want a different footprint
    // @Override public int getWidthPixels() { return 16; }
    // @Override public int getHeightPixels() { return 16; }
}