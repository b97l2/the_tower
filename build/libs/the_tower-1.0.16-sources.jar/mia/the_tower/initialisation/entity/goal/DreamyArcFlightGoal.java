// DreamyArcFlightGoal.java
package mia.the_tower.initialisation.entity.goal;

import java.util.EnumSet;
import net.minecraft.class_1308;
import net.minecraft.class_1352;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public class DreamyArcFlightGoal extends class_1352 {
    private final class_1308 mob;
    private final double speed;      // moveControl speed
    private final double minR, maxR; // horizontal orbit radius bounds
    private final double vertAmp;    // vertical amplitude
    private final double omega;      // angular velocity (radians/tick)

    private class_243 anchor;            // center of the local arc
    private double radius;           // current orbit radius
    private double t;                // phase parameter for the curve
    private double phaseXZ;          // slight XZ phase skew for ellipse
    private double phaseY;           // vertical phase offset
    private int   reanchorTicks;     // countdown to drift/refresh anchor
    private final int reanchorPeriod;

    public DreamyArcFlightGoal(class_1308 mob,
                               double speed,
                               double minRadius, double maxRadius,
                               double vertAmp,
                               double omega,
                               int anchorDriftSec) {
        this.mob = mob;
        this.speed = speed;
        this.minR = minRadius;
        this.maxR = maxRadius;
        this.vertAmp = vertAmp;
        this.omega = omega;
        this.reanchorPeriod = Math.max(40, anchorDriftSec * 20);
        this.method_6265(EnumSet.of(class_4134.field_18405, class_4134.field_18406));
    }

    @Override
    public boolean method_6264() {
        return true;
    }

    @Override
    public boolean method_6266() {
        return true; // ambient, continuous idle flight
    }

    @Override
    public void method_6269() {
        var r = mob.method_59922();
        this.anchor = mob.method_19538();
        this.radius = class_3532.method_16436(r.method_43057(), minR, maxR);
        this.t = r.method_43058() * (Math.PI * 2);
        this.phaseXZ = r.method_43058() * (Math.PI * 2);
        this.phaseY = r.method_43058() * (Math.PI * 2);
        this.reanchorTicks = reanchorPeriod;
    }

    @Override
    public void method_6268() {
        var world = mob.method_37908();
        var r = mob.method_59922();

        // Occasionally drift the anchor a little to avoid tight circles feeling mechanical.
        if (--reanchorTicks <= 0) {
            reanchorTicks = reanchorPeriod + r.method_43048(60) - 30;
            // Drift anchor softly in a random horizontal direction and slight vertical change.
            double drift = 2.0 + r.method_43058() * 2.0;
            double angle = r.method_43058() * Math.PI * 2.0;
            anchor = anchor.method_1031(Math.cos(angle) * drift,
                                r.method_43058() * 0.6 - 0.3, // small up/down drift
                                Math.sin(angle) * drift);

            // Occasionally retune radius within bounds.
            if (r.method_43057() < 0.3f) {
                radius = class_3532.method_16436(r.method_43057(), minR, maxR);
            }
        }

        // Advance along an ellipse; skew the Y frequency for a lazy helix feel.
        t += omega;
        double ex = Math.cos(t);
        double ez = Math.sin(t + phaseXZ) * 0.75; // 0.75 → ellipse instead of perfect circle
        double ey = Math.sin(t * 0.5 + phaseY);   // slower vertical oscillation

        // Target point on the curve
        double tx = anchor.field_1352 + radius * ex;
        double ty = clampToFlyableY(anchor.field_1351 + vertAmp * ey, world.method_31607() + 2, world.method_31600() - 2);
        double tz = anchor.field_1350 + radius * ez;

        // Nudge the anchor upward if we are colliding with terrain above.
        if (mob.field_5976 || mob.field_5992) {
            anchor = anchor.method_1031(0, 0.6, 0);
        }

        // Steer toward the target with FlightMoveControl
        mob.method_5962().method_6239(tx, ty, tz, speed);

        // Look slightly ahead of the motion for smoother visuals
//        Vec3d vel = mob.getVelocity();
//        Vec3d look = new Vec3d(tx - mob.getX(), ty - mob.getEyeY(), tz - mob.getZ());
//        if (look.lengthSquared() > 1.0e-3) {
//            mob.getLookControl().lookAt(mob.getX() + vel.x * 4.0 + look.x * 0.5,
//                                        mob.getEyeY() + vel.y * 2.0 + look.y * 0.2,
//                                        mob.getZ() + vel.z * 4.0 + look.z * 0.5,
//                                        10.0f, 20.0f);
//        }

        // Small, random micro-perturbations to break perfect periodicity.
        if (r.method_43048(120) == 0) phaseXZ += (r.method_43058() - 0.5) * 0.25;
        if (r.method_43048(160) == 0) phaseY  += (r.method_43058() - 0.5) * 0.25;
    }

    private static double clampToFlyableY(double y, int minY, int maxY) {
        return Math.max(minY, Math.min(maxY, y));
    }
}
