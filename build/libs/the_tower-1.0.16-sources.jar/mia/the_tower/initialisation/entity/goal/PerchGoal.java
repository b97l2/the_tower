package mia.the_tower.initialisation.entity.goal;

import mia.the_tower.initialisation.entity.custom.VoidMothEntity;
import net.minecraft.class_1352;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import java.util.EnumSet;

//something is wrong here, need to investigate
//moths keep killing themselves
public class PerchGoal extends class_1352 {
    private final VoidMothEntity mob;
    private class_2338 targetPos;
    private class_2350 targetFace;
    private int minPerchTicks;
    private int perchTicks;

    public PerchGoal(VoidMothEntity mob, int minPerchSeconds) {
        this.mob = mob;
        this.method_6265(EnumSet.of(class_4134.field_18405, class_4134.field_18406));
        this.minPerchTicks = minPerchSeconds * 20;
    }

    @Override
    public boolean method_6264() {
        if (mob.isPerched()) return false;
        if (mob.method_59922().method_43057() > 0.02f) return false; // 2% chance each tick ~ idle decision

        // Find a nearby face (ceiling preferred, else walls)
        class_2338 base = mob.method_24515();
        for (int tries = 0; tries < 16; tries++) {
            class_2338 p = base.method_10069(
                    mob.method_59922().method_39332(-6, 6),
                    mob.method_59922().method_39332(-2, 4),
                    mob.method_59922().method_39332(-6, 6)
            );

            // Try ceiling first
            if (isFaceSolid(p, class_2350.field_11033)) { // block at p has a solid bottom -> we can hang from its underside
                this.targetPos = p;
                this.targetFace = class_2350.field_11036;  // attach to the ceiling (we “face” UP)
                return true;
            }

            // Try walls
            for (class_2350 dir : class_2350.class_2353.field_11062) {
                if (isFaceSolid(p, dir.method_10153())) {
                    this.targetPos = p;
                    this.targetFace = dir; // attach to that wall
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean method_6266() {
        if (mob.isPerched()) {
            // Remain perched while support is valid and time not elapsed and not disturbed
            if (!hasSupport(mob.method_24515(), mob.getPerchFace())) return false;
            if (perchTicks < minPerchTicks) return true;

            // Optional disturbances:
            if (mob.method_5968() != null) return false;
            if (mob.method_37908().method_8530()) {
                // if you want “night moths” — unperch by day; or invert if you want the opposite
                return false;
            }
            // Keep perching longer with a chance
            return mob.method_59922().method_43057() < 0.95f;
        } else {
            // If we haven’t reached target yet, continue while path exists
            return targetPos != null && !mob.method_5942().method_6357();
        }
    }

    @Override
    public void method_6269() {
        perchTicks = 0;
        if (targetPos != null && !mob.isPerched()) {
            // Fly to an approach point slightly off the face
            class_2382 n = targetFace.method_62675();
            class_2338 approach = targetPos.method_10093(targetFace.method_10153()); // just in front of the surface
            mob.method_5942().method_6337(approach.method_10263() + 0.5, approach.method_10264() + 0.5, approach.method_10260() + 0.5, 1.0);
        }
    }

    @Override
    public void method_6268() {
        if (!mob.isPerched()) {
            // Close enough to snap and perch
            if (targetPos != null && mob.method_5707(class_243.method_24953(targetPos)) < 1.0) {
                mob.perchAt(targetPos, targetFace);
            }
        } else {
            perchTicks++;
            mob.method_5988().method_20248(
                    mob.method_23317() + 0.1, mob.method_23318(), mob.method_23321() + 0.1); // subtle look change; optional
        }
    }

    @Override
    public void method_6270() {
        targetPos = null;
        targetFace = null;
        if (mob.isPerched()) {
            mob.unperch();
        }
    }

    // --- helpers ---

    private boolean isFaceSolid(class_2338 pos, class_2350 face) {
        // For ceiling: face = DOWN (we check the block's bottom face); for wall: opposite of our attach direction.
        class_2680 s = mob.method_37908().method_8320(pos);
        // Yarn name can be one of these; pick what your mappings have:
        // return s.isSideSolid(mob.getWorld(), pos, face, SideShapeType.FULL);
        // or:
        return s.method_26216(); // conservative fallback
    }

    private boolean hasSupport(class_2338 entityPos, class_2350 attachFace) {
        class_2338 anchor = switch (attachFace) {
            case field_11036 -> entityPos.method_10084();            // ceiling is above
            case field_11033 -> entityPos.method_10074();
            default -> entityPos.method_10093(attachFace); // wall is to the side we attached to
        };
        return isFaceSolid(anchor, attachFace.method_10153());
    }
}
