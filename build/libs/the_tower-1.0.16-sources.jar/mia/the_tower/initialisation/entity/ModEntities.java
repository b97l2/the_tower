package mia.the_tower.initialisation.entity;

import mia.the_tower.initialisation.entity.custom.LampFlyEntity;
import mia.the_tower.initialisation.entity.custom.PlateEntity;
import mia.the_tower.initialisation.entity.custom.VoidMothEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1317;
import net.minecraft.class_2378;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9169;

public class ModEntities {
    //to make an entity, you give it two lines here
    //you make its own entity class of course under /custom
    //and then you need to make four classes, Animations, Model, Renderer, and RenderState, which handle the appearance and rendering in the client portion
    //then you put a line in The_Tower
    //lastly, you put in a needed line in The_TowerClient and put in the texture

    //for the egg you of course need to make a line in item_init and put it in creative inventory

    //one here
    private static final class_5321<class_1299<?>> VOID_MOTH_KEY =
            class_5321.method_29179(class_7924.field_41266, class_2960.method_60655("the_tower", "void_moth"));

    private static final class_5321<class_1299<?>> LAMP_FLY_KEY =
            class_5321.method_29179(class_7924.field_41266, class_2960.method_60655("the_tower", "lamp_fly"));

    private static final class_5321<class_1299<?>> PLATE_KEY =
            class_5321.method_29179(class_7924.field_41266, class_2960.method_60655("the_tower", "plate"));



    //one here
    public static final class_1299<VoidMothEntity> VOID_MOTH = class_2378.method_10230(class_7923.field_41177,
            class_2960.method_60655("the_tower", "void_moth"),
            class_1299.class_1300.method_5903(VoidMothEntity::new, class_1311.field_6294)
                    .method_17687(1f, 0.4f).method_5905(VOID_MOTH_KEY));

    public static final class_1299<LampFlyEntity> LAMP_FLY = class_2378.method_10230(class_7923.field_41177,
            class_2960.method_60655("the_tower", "lamp_fly"),
            class_1299.class_1300.method_5903(LampFlyEntity::new, class_1311.field_6303)
                    .method_17687(0.2f, 0.2f).method_5905(LAMP_FLY_KEY));

    public static final class_1299<PlateEntity> PLATE = class_2378.method_10230(class_7923.field_41177,
            class_2960.method_60655("the_tower", "plate"),
            class_1299.class_1300.<PlateEntity>method_5903(PlateEntity::new, class_1311.field_17715)
                    .method_63006()
                    .method_17687(0.5F, 0.5F)
                    .method_55687(0.0F)
                    .method_27299(10)
                    .method_27300(Integer.MAX_VALUE)
                    .method_17687(1f, 0.4f)
                    .method_5905(PLATE_KEY));

    public static void load() {
        //spawn restrictions, not strictly needed
        FabricDefaultAttributeRegistry.register(LAMP_FLY, LampFlyEntity.createAttributes());
        // **spawn restriction**: which placement pass + heightmap + predicate
        class_1317.method_20637(
                LAMP_FLY,
                class_9169.field_48742,           // flying/air checks yourself
                class_2902.class_2903.field_13203,            // where spawner queries height
                LampFlyEntity::canSpawn                               // your predicate
        );

    }

    }
