package mia.the_tower.initialisation.blockentity;

import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2382;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2621;
import net.minecraft.class_2680;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5561;
import net.minecraft.class_7225;


public class StorageTemplateBlockEntity extends class_2621 {
    private class_2371<class_1799> inventory = class_2371.method_10213(9*6, class_1799.field_8037);
    private final class_5561 stateManager = new class_5561() {
        @Override
        protected void method_31681(class_1937 world, class_2338 pos, class_2680 state) {
            StorageTemplateBlockEntity.this.playSound(state, class_3417.field_17604);
            StorageTemplateBlockEntity.this.setOpen(state, true);
        }

        @Override
        protected void method_31683(class_1937 world, class_2338 pos, class_2680 state) {
            StorageTemplateBlockEntity.this.playSound(state, class_3417.field_17603);
            StorageTemplateBlockEntity.this.setOpen(state, false);
        }

        @Override
        protected void method_31682(class_1937 world, class_2338 pos, class_2680 state, int oldViewerCount, int newViewerCount) {
        }

        @Override
        protected boolean method_31679(class_1657 player) {
            if (player.field_7512 instanceof class_1707) {
                class_1263 inventory = ((class_1707)player.field_7512).method_7629();
                return inventory == StorageTemplateBlockEntity.this;
            } else {
                return false;
            }
        }
    };

    public StorageTemplateBlockEntity(class_2338 pos, class_2680 state) {
        super(blockentity_init.GRAVESTONE, pos, state);
    }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        if (!this.method_54872(nbt)) {
            class_1262.method_5426(nbt, this.inventory, registries);
        }
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11014(nbt, registries);
        this.inventory = class_2371.method_10213(this.method_5439(), class_1799.field_8037);
        if (!this.method_54871(nbt)) {
            class_1262.method_5429(nbt, this.inventory, registries);
        }
    }

    @Override
    public int method_5439() {
        return 9*6;
    }

    @Override
    protected class_2371<class_1799> method_11282() {
        return this.inventory;
    }

    @Override
    protected void method_11281(class_2371<class_1799> inventory) {
        this.inventory = inventory;
    }

    @Override
    protected class_2561 method_17823() {
        return class_2561.method_43471("container.gravestone");
    }

    @Override
    protected class_1703 method_5465(int syncId, class_1661 playerInventory) {
        return class_1707.method_19247(syncId, playerInventory, this);
    }

    @Override
    public void method_5435(class_1657 player) {
        if (!this.field_11865 && !player.method_7325()) {
            this.stateManager.method_31684(player, this.method_10997(), this.method_11016(), this.method_11010());
        }
    }

    @Override
    public void method_5432(class_1657 player) {
        if (!this.field_11865 && !player.method_7325()) {
            this.stateManager.method_31685(player, this.method_10997(), this.method_11016(), this.method_11010());
        }
    }

    public void tick() {
        if (!this.field_11865) {
            this.stateManager.method_31686(this.method_10997(), this.method_11016(), this.method_11010());
        }
    }

    void setOpen(class_2680 state, boolean open) {
        this.field_11863.method_8652(this.method_11016(), state.method_11657(StorageTemplateBlock.OPEN, open), class_2248.field_31036);
    }

    void playSound(class_2680 state, class_3414 soundEvent) {
        class_2382 vec3i = ((class_2350)state.method_11654(StorageTemplateBlock.FACING)).method_62675();
        double d = this.field_11867.method_10263() + 0.5 + vec3i.method_10263() / 2.0;
        double e = this.field_11867.method_10264() + 0.5 + vec3i.method_10264() / 2.0;
        double f = this.field_11867.method_10260() + 0.5 + vec3i.method_10260() / 2.0;
        this.field_11863.method_43128(null, d, e, f, soundEvent, class_3419.field_15245, 0.5F, this.field_11863.field_9229.method_43057() * 0.1F + 0.9F);
    }


}

