package mia.the_tower.initialisation.blockentity;


import com.mojang.serialization.MapCodec;
import net.minecraft.class_1264;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2754;
import net.minecraft.class_3218;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;


public class StorageTemplateBlock extends class_2237 {
    public static final MapCodec<StorageTemplateBlock> CODEC = method_54094(StorageTemplateBlock::new);
    public static final class_2754<class_2350> FACING = class_2741.field_12525;
    public static final class_2746 OPEN = class_2741.field_12537;

    @Override
    public MapCodec<StorageTemplateBlock> method_53969() {
        return field_46280;
    }

    public StorageTemplateBlock(class_2251 settings) {
        super(settings);
        this.method_9590(this.field_10647.method_11664().method_11657(FACING, class_2350.field_11043).method_11657(OPEN, false));
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if (world instanceof class_3218 serverWorld && world.method_8321(pos) instanceof StorageTemplateBlockEntity storageTemplateBlockEntity) {
            player.method_17355(storageTemplateBlockEntity);
            //player.incrementStat(Stats.OPEN_BARREL);
        }

        return class_1269.field_5812;
    }

    @Override
    protected void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
        class_1264.method_54291(state, newState, world, pos);
        super.method_9536(state, world, pos, newState, moved);
    }

    @Override
    protected void method_9588(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        class_2586 blockEntity = world.method_8321(pos);
        if (blockEntity instanceof StorageTemplateBlockEntity) {
            ((StorageTemplateBlockEntity)blockEntity).tick();
        }
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new StorageTemplateBlockEntity(pos, state);
    }

    @Override
    protected boolean method_9498(class_2680 state) {
        return true;
    }

    @Override
    protected int method_9572(class_2680 state, class_1937 world, class_2338 pos) {
        return class_1703.method_7608(world.method_8321(pos));
    }

    @Override
    protected class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    protected class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, OPEN);
    }

    @Override
    public class_2680 method_9605(class_1750 ctx) {
        // If placing on a vertical face, face the player; otherwise use the clicked horizontal face.
        class_2350 dir = ctx.method_8038().method_10166().method_10179()
                ? ctx.method_8038()
                : ctx.method_8042().method_10153();
        return this.method_9564().method_11657(FACING, dir);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 view, class_2338 pos, class_3726 context) {

        switch ((class_2350)state.method_11654(FACING)) {
            case field_11043:
                return class_259.method_1081(0F, 0F, 0.75, 1F, 1F, 0.875F);
            case field_11035:
                return class_259.method_1081(0F, 0, 0.125F, 1F, 1, 0.25F);
            case field_11034:
                return class_259.method_1081(0.125F, 0F, 0F, 0.25F, 1F, 1F);
            case field_11039:
                return class_259.method_1081(0.75, 0F, 0F, 0.875F, 1F, 1F);
            default:
                return class_259.method_1081(0F, 0F, 0.75, 1F, 1F, 0.875F);
        }
    }

}


