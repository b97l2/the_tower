package mia.the_tower.initialisation.blockentity;

import mia.the_tower.initialisation.blockentity.util.ColouredInventory;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1767;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3708;
import net.minecraft.class_3908;
import net.minecraft.class_5561;
import net.minecraft.class_7225;

public class ColouredCofferBlockEntity extends class_2586 implements class_3908, class_1263 {
    private final class_5561 stateManager = new class_5561() {
        @Override
        protected void method_31681(class_1937 world, class_2338 pos, class_2680 state) {
            ColouredCofferBlockEntity.this.playSound(state, class_3417.field_17604);
            ColouredCofferBlockEntity.this.setOpen(state, true);
        }

        @Override
        protected void method_31683(class_1937 world, class_2338 pos, class_2680 state) {
            ColouredCofferBlockEntity.this.playSound(state, class_3417.field_17603); //change these to custom sound
            ColouredCofferBlockEntity.this.setOpen(state, false);
        }

        @Override
        protected void method_31682(class_1937 world, class_2338 pos, class_2680 state, int oldViewerCount, int newViewerCount) {
        }

        @Override
        protected boolean method_31679(class_1657 player) {
            if (player.field_7512 instanceof class_1707) {
                class_1263 inventory = ((class_1707)player.field_7512).method_7629();
                return inventory == ColouredCofferBlockEntity.this;
            } else {
                return false;
            }
        }
    };

    void playSound(class_2680 state, class_3414 soundEvent) {
        class_2382 vec3i = ((class_2350)state.method_11654(class_3708.field_16320)).method_62675();
        double d = this.field_11867.method_10263() + 0.5 + vec3i.method_10263() / 2.0;
        double e = this.field_11867.method_10264() + 0.5 + vec3i.method_10264() / 2.0;
        double f = this.field_11867.method_10260() + 0.5 + vec3i.method_10260() / 2.0;
        this.field_11863.method_43128(null, d, e, f, soundEvent, class_3419.field_15245, 0.5F, this.field_11863.field_9229.method_43057() * 0.1F + 0.9F);
    }

    void setOpen(class_2680 state, boolean open) {
        this.field_11863.method_8652(this.method_11016(), state.method_11657(ColouredCofferBlock.OPEN, open), class_2248.field_31036);
    }

    private boolean counted = false;
    private class_1767 color = class_1767.field_7952;

    public ColouredCofferBlockEntity(class_2338 pos, class_2680 state) {
        super(java.util.Objects.requireNonNull(blockentity_init.COLORED_COFFER, "COLORED_COFFER not registered"), pos, state);
        //super(blockentity_init.COLORED_COFFER, pos, state);
        if (state.method_26204() instanceof ColouredCofferBlock cofferBlock) {
            this.color = cofferBlock.getColor();
        }
    }

    public static void serverTick(net.minecraft.class_1937 world, class_2338 pos, class_2680 state, ColouredCofferBlockEntity be) {
        if (world.field_9236) return;
        if (!be.counted) {
            be.ensureCounted((class_3218) world);
        }
    }

    private void ensureCounted(class_3218 sw) {
        ColouredInventory inv = ColouredInventory.get(sw, color);
        inv.onContainerAdded();
        counted = true;
        method_5431();
    }

    public class_1767 getColor() {
        return color;
    }

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        nbt.method_10556("counted", counted);
        nbt.method_10569("color", color.method_7789()); // informational; block type already fixes color
    }

    @Override
    public void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11014(nbt, registries);
        this.counted = nbt.method_10577("counted");
        // color remains from constructor (block decides); the stored int is optional
    }

    //for the screen handler bellow


    /* ---------- NamedScreenHandlerFactory ---------- */
    @Override
    public class_2561 method_5476() {
        return class_2561.method_43469("container.coloured_coffer", class_2561.method_43471("color.minecraft." + color.method_7792()));
    }

    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInv, class_1657 player) {
        if (!(this.method_10997() instanceof class_3218 sw)) return null;
        class_1263 backing = ColouredInventory.get(sw, color); // full shared inventory for this color
        return new mia.the_tower.initialisation.screen.CofferScreenHandler(syncId, playerInv, backing,
                net.minecraft.class_3914.method_17392(sw, this.method_11016()),
                this.method_11010().method_26204());
    }

    /* ---------- Inventory (delegate to the shared inventory) ---------- */
    private static final class_1263 CLIENT_PLACEHOLDER = new class_1277(0); // zero-size, safe no-op

    private class_1263 backing() {
        if (!(this.method_10997() instanceof class_3218 sw)) {
            // Hoppers only run server-side; UI also creates handlers only server-side.
            // If ever called client-side, do nothing sensible.
            return CLIENT_PLACEHOLDER;
        }
        return ColouredInventory.get((class_3218) this.method_10997(), color);
    }

    @Override public int method_5439() { return backing().method_5439(); }
    @Override public boolean method_5442() { return backing().method_5442(); }
    @Override public net.minecraft.class_1799 method_5438(int slot) { return backing().method_5438(slot); }
    @Override public net.minecraft.class_1799 method_5434(int slot, int amount) { return backing().method_5434(slot, amount); }
    @Override public net.minecraft.class_1799 method_5441(int slot) { return backing().method_5441(slot); }
    @Override public void method_5447(int slot, net.minecraft.class_1799 stack) { backing().method_5447(slot, stack); }
    @Override public void method_5431() { backing().method_5431(); super.method_5431(); }
    @Override public boolean method_5443(class_1657 player) { return backing().method_5443(player); }
    @Override public void method_5448() { backing().method_5448(); }

}