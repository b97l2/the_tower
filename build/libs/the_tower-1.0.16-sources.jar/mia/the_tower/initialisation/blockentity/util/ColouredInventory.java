package mia.the_tower.initialisation.blockentity.util;

import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_18;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_26;
import net.minecraft.class_3218;
import net.minecraft.class_7225;
import net.minecraft.server.MinecraftServer;
import java.util.*;

public class ColouredInventory implements class_1263{
    private final class_3218 world;
    private final class_1767 color;
    private final State.Entry entry;

    private ColouredInventory(class_3218 world, class_1767 color, State.Entry entry) {
        this.world = world;
        this.color = color;
        this.entry = entry;
    }

    public static ColouredInventory get(class_3218 world, class_1767 color) {
        State state = State.get(world.method_8503());
        State.Entry entry = state.getOrCreate(color);
        return new ColouredInventory(world, color, entry);
    }

    public void onContainerAdded() {
        entry.containers = Math.max(0, entry.containers) + 1;

        int oldSize = entry.items.size();
        int newSize = entry.containers * 27;

        if (newSize > oldSize) {
            class_2371<class_1799> resized = class_2371.method_10213(newSize, class_1799.field_8037);
            for (int i = 0; i < oldSize; i++) {
                resized.set(i, entry.items.get(i));
            }
            entry.items = resized; // replace; do NOT add()
        }
        State.get(world.method_8503()).method_80();
        enforceSizeInvariant();
    }

    public List<class_1799> onContainerRemoved() {
        List<class_1799> overflow = new ArrayList<>();
        if (entry.containers <= 0) return overflow;

        int oldSize = entry.items.size();
        entry.containers -= 1;
        int newSize = Math.max(0, entry.containers * 27);

        // collect overflow from truncated tail
        for (int i = newSize; i < oldSize; i++) {
            class_1799 s = entry.items.get(i);
            if (!s.method_7960()) overflow.add(s);
        }

        // rebuild to new size; do NOT remove()
        if (newSize != oldSize) {
            class_2371<class_1799> resized = class_2371.method_10213(newSize, class_1799.field_8037);
            for (int i = 0; i < Math.min(newSize, oldSize); i++) {
                resized.set(i, entry.items.get(i));
            }
            entry.items = resized;
        }

        State.get(world.method_8503()).method_80();
        enforceSizeInvariant();
        return overflow;
    }

    // --- Inventory impl ---

    @Override
    public int method_5439() {
        return entry.items.size();
    }

    @Override
    public boolean method_5442() {
        for (class_1799 s : entry.items) if (!s.method_7960()) return false;
        return true;
    }

    @Override
    public class_1799 method_5438(int slot) {
        return (slot >= 0 && slot < entry.items.size()) ? entry.items.get(slot) : class_1799.field_8037;
    }

    @Override
    public class_1799 method_5434(int slot, int amount) {
        class_1799 stack = class_1262.method_5430(entry.items, slot, amount);
        method_5431();
        return stack;
    }

    @Override
    public class_1799 method_5441(int slot) {
        class_1799 stack = class_1262.method_5428(entry.items, slot);
        method_5431();
        return stack;
    }

    @Override
    public void method_5447(int slot, class_1799 stack) {
        if (slot < 0 || slot >= entry.items.size()) {
            // Out of bounds: refuse rather than silently changing capacity.
            return;
        }
        entry.items.set(slot, stack);
        if (!stack.method_7960() && stack.method_7947() > stack.method_7914()) {
            stack.method_7939(stack.method_7914());
        }
        method_5431();
    }

    @Override
    public void method_5431() {
        State.get(world.method_8503()).method_80();
    }

    @Override
    public boolean method_5443(net.minecraft.class_1657 player) {
        return true;
    }

    @Override
    public void method_5448() {
        Collections.fill(entry.items, class_1799.field_8037);
        method_5431();
    }

    //this is to make sure the inventory size is consistent
    private void enforceSizeInvariant() {
        int expected = Math.max(0, entry.containers * 27);
        if (entry.items.size() != expected) {
            class_2371<class_1799> fixed = class_2371.method_10213(expected, class_1799.field_8037);
            for (int i = 0; i < Math.min(expected, entry.items.size()); i++) fixed.set(i, entry.items.get(i));
            entry.items = fixed;
        }
    }

    // --- Persistent, per-color global state ---

    public static final class State extends class_18 {
        private static final String KEY = "color_coffer_state";

        private final EnumMap<class_1767, Entry> byColor = new EnumMap<>(class_1767.class);

        // NOTE: Type constructor here expects the registry-aware reader. Writer can be null;
        // the manager will use State#writeNbt(nbt, lookup).
        public static final class_18.class_8645<State> TYPE = new class_18.class_8645<>(
                State::new,
                State::fromNbt,
                null
        );

        private State() {}

        //possibly buggy, unexpectedely removes pages from inventory
//        public static State fromNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
//            State s = new State();
//            for (DyeColor c : DyeColor.values()) {
//                String name = c.getName();
//                if (!nbt.contains(name, NbtElement.COMPOUND_TYPE)) continue;
//                NbtCompound cTag = nbt.getCompound(name);
//
//                Entry e = new Entry();
//                e.containers = cTag.getInt("containers");
//
//                int expectedSize = Math.max(0, e.containers * 27);
//
//                // Load whatever was saved under the standard "Items" list
//                NbtList itemsList = cTag.getList("Items", NbtElement.COMPOUND_TYPE);
//                DefaultedList<ItemStack> temp = DefaultedList.ofSize(itemsList.size(), ItemStack.EMPTY);
//                Inventories.readNbt(cTag, temp, lookup);
//
//                // Reconcile to expected size (containers * 27)
//                e.items = DefaultedList.ofSize(expectedSize, ItemStack.EMPTY);
//                for (int i = 0; i < Math.min(e.items.size(), temp.size()); i++) {
//                    e.items.set(i, temp.get(i));
//                }
//
//                s.byColor.put(c, e);
//            }
//            return s;
//        }

        public static State fromNbt(class_2487 nbt, class_7225.class_7874 lookup) {
            State s = new State();
            for (class_1767 c : class_1767.values()) {
                String name = c.method_7792();
                if (!nbt.method_10573(name, class_2520.field_33260)) continue;
                class_2487 cTag = nbt.method_10562(name);

                Entry e = new Entry();
                e.containers = cTag.method_10550("containers");

                int expectedSize = Math.max(0, e.containers * 27);

                // Allocate to full capacity so readNbt can place by "Slot" index.
                class_2371<class_1799> temp = class_2371.method_10213(expectedSize, class_1799.field_8037);
                class_1262.method_5429(cTag, temp, lookup);

                // No extra reconcile/copy step needed; temp already matches capacity.
                e.items = temp;

                s.byColor.put(c, e);
            }
            return s;
        }


        @Override
        public class_2487 method_75(class_2487 nbt, class_7225.class_7874 lookup) {
            for (Map.Entry<class_1767, Entry> pair : byColor.entrySet()) {
                class_1767 c = pair.getKey();
                Entry e = pair.getValue();

                class_2487 cTag = new class_2487();
                cTag.method_10569("containers", Math.max(0, e.containers));

                // Write under standard "Items" using the registry-aware helper
                class_1262.method_5426(cTag, e.items, lookup);

                nbt.method_10566(c.method_7792(), cTag);
            }
            return nbt;
        }

        public Entry getOrCreate(class_1767 color) {
            return byColor.computeIfAbsent(color, c -> new Entry());
        }

        public static State get(MinecraftServer server) {
            class_3218 overworld = server.method_30002();
            class_26 mgr = overworld.method_17983();
            return mgr.method_17924(TYPE, KEY);
        }

        static final class Entry {
            int containers = 0;
            class_2371<class_1799> items = class_2371.method_10213(0, class_1799.field_8037);
        }
    }

}
