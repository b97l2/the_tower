package mia.the_tower.initialisation.blockentity.util;

import mia.the_tower.initialisation.util.CustomTags;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.jetbrains.annotations.Nullable;

public final class CofferKeys {
    public static @Nullable class_2960 keyOf(class_1799 stack) {
        if (stack.method_7960()) return null;
//restricting it to items with tag coffer_keys
        if (!stack.method_31573(CustomTags.Items.COFFER_KEYS)) return null;
        return class_7923.field_41178.method_10221(stack.method_7909());
    }
}
