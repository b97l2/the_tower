package mia.the_tower.initialisation.util;

import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class CustomTags {
//this is for making a custom tag. Include the tag here and then add it to the proper tags file under data/the_tower/tags
        public static class Blocks {
            public static final class_6862<class_2248> CERULEAN_COAST_REPLACEABLE = createTag("cerulean_coast_replaceable");
            public static final class_6862<class_2248> SHADOWLANDS_REPLACEABLE = createTag("shadowlands_replaceable");

    private static class_6862<class_2248> createTag(String name) {
                return class_6862.method_40092(class_7924.field_41254, class_2960.method_60655("the_tower", name));
            }
        }

        public static class Items {
            public static final class_6862<class_1792> COFFER_KEYS = createTag("coffer_keys");

            private static class_6862<class_1792> createTag(String name) {
                return class_6862.method_40092(class_7924.field_41197, class_2960.method_60655("the_tower", name));
            }
        }

        public static void load(){}
    }

