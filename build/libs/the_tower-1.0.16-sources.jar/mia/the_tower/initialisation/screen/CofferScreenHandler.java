package mia.the_tower.initialisation.screen;

import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_3913;
import net.minecraft.class_3914;
import net.minecraft.class_3919;

public class CofferScreenHandler  extends class_1703 {
    public static final int COLS = 9;
    public static final int ROWS_VISIBLE = 3;              // 27 visible slots
    public static final int WINDOW_SLOTS = COLS * ROWS_VISIBLE;

    private final class_3914 context;
    private final class_2248 sourceBlock;

    // Server only (null client-side)
    private final class_1263 backing;
    private final WindowedInventory window;

    // Properties synced to client: [0] totalRows, [1] baseRow
    private final class_3913 props = new class_3919(2);

    private int page = 0; //for pagination

    /* ---------- client constructor (registered factory) ---------- */
    public CofferScreenHandler(int syncId, class_1661 playerInv) {
        super(screen_init.COFFER, syncId);
        this.context    = class_3914.field_17304;
        this.sourceBlock= null;
        this.backing    = null;
        this.window     = new WindowedInventory(new class_1277(WINDOW_SLOTS), 0, WINDOW_SLOTS);

        this.method_17360(props); // values will come from server
        layoutSlots(playerInv);
    }

    /* ---------- server constructor (from BE factory) ---------- */
    public CofferScreenHandler(int syncId, class_1661 playerInv, class_1263 backing,
                               class_3914 ctx, class_2248 srcBlock) {
        super(screen_init.COFFER, syncId);
        this.context    = ctx;
        this.sourceBlock= srcBlock;
        this.backing    = backing;
        this.window     = new WindowedInventory(backing, 0, WINDOW_SLOTS);

        props.method_17391(0, totalPages());
        props.method_17391(1, page);
        this.method_17360(props);

        layoutSlots(playerInv);
        backing.method_5435(playerInv.field_7546);
        applyPage(); // sets window base and re-syncs page props
    }

    private int totalPages() {
        if (backing == null) return 1; // client uses props
        int size = backing.method_5439();
        int pageSize = WINDOW_SLOTS;
        int pages = (size + pageSize - 1) / pageSize;
        return Math.max(pages, 1);
    }

    private void applyPage() {
        int maxPage = totalPages() - 1;
        if (page < 0) page = 0;
        if (page > maxPage) page = maxPage;

        window.setBaseIndex(page * WINDOW_SLOTS);

        // keep client in sync
        props.method_17391(0, totalPages());
        props.method_17391(1, page);

        this.method_7623();
    }

    /* ---------- layout ---------- */
    private void layoutSlots(class_1661 playerInv) {
        // Window: 9x3 at (8,18)
        int left = 8, top = 18;
        for (int r = 0; r < ROWS_VISIBLE; r++) {
            for (int c = 0; c < COLS; c++) {
                int windowIndex = c + r * COLS;
                this.method_7621(new CofferSlot(this, window, windowIndex,
                        left + c * 18, top + r * 18));
            }
        }
        // Player inv at (8,84) and hotbar at (8,142) like vanilla 9x3 chest
        addPlayerInventory(playerInv, 8, 84);
    }

    private void addPlayerInventory(class_1661 inv, int left, int top) {
        // 3 rows
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 9; c++) {
                this.method_7621(new class_1735(inv, c + (r + 1) * 9, left + c * 18, top + r * 18));
            }
        }
        // hotbar
        for (int c = 0; c < 9; c++) {
            this.method_7621(new class_1735(inv, c, left + c * 18, top + 58));
        }
    }

    /* ---------- windowing + scrolling ---------- */

    @Override
    public boolean method_7604(class_1657 player, int id) {
        // id: 0 = prev, 1 = next
        if (id == 0) page--;
        else if (id == 1) page++;
        else return false;

        applyPage();
        return true;
    }

    public int getPage() {
        return (backing != null) ? page : Math.max(0, props.method_17390(1));
    }

    public int getTotalPagesSynced() {
        return (backing != null) ? totalPages() : Math.max(1, props.method_17390(0));
    }


    /* ---------- required overrides ---------- */
    @Override
    public boolean method_7597(class_1657 player) {
        if (sourceBlock == null) return true;
        return method_17695(context, player, sourceBlock);
    }

    @Override
    public class_1799 method_7601(class_1657 player, int index) {
        class_1799 original = class_1799.field_8037;
        class_1735 slot = this.field_7761.get(index);
        if (slot != null && slot.method_7681()) {
            class_1799 stack = slot.method_7677();
            original = stack.method_7972();

            int cofferStart = 0;
            int cofferEnd   = WINDOW_SLOTS; // [0,27)
            int invStart    = WINDOW_SLOTS;
            int invEnd      = invStart + 27;
            int hotStart    = invEnd;
            int hotEnd      = hotStart + 9;

            if (index < cofferEnd) {
                // coffer window -> player inventory + hotbar (unchanged)
                if (!this.method_7616(stack, invStart, hotEnd, true)) return class_1799.field_8037;
            } else {
                // player -> coffer: merge into the ENTIRE backing (not just the window)
                if (!insertIntoBackingAllRows(stack)) return class_1799.field_8037;
            }

            if (stack.method_7960()) slot.method_53512(class_1799.field_8037);
            else slot.method_7668();

            // keep the window/props fresh
            applyPage(); //this the right place??
        }
        return original;
    }

    private boolean insertIntoBackingAllRows(class_1799 stack) {
        if (backing == null || stack.method_7960()) return false;

        boolean movedAny = false;

        // Pass 1: merge into existing compatible stacks across ALL rows
        for (int i = 0, n = backing.method_5439(); i < n && !stack.method_7960(); i++) {
            class_1799 cur = backing.method_5438(i);
            if (!cur.method_7960() && net.minecraft.class_1799.method_31577(cur, stack)) {
                int max = Math.min(cur.method_7914(), stack.method_7914());
                int canMove = Math.min(stack.method_7947(), max - cur.method_7947());
                if (canMove > 0) {
                    cur.method_7933(canMove);
                    stack.method_7934(canMove);
                    movedAny = true;
                }
            }
        }

        // Pass 2: place into empty slots across ALL rows
        for (int i = 0, n = backing.method_5439(); i < n && !stack.method_7960(); i++) {
            class_1799 cur = backing.method_5438(i);
            if (cur.method_7960()) {
                // place up to stack.getMaxCount()
                int toMove = Math.min(stack.method_7947(), stack.method_7914());
                class_1799 place = stack.method_7972();
                place.method_7939(toMove);
                backing.method_5447(i, place);
                stack.method_7934(toMove);
                movedAny = true;
            }
        }

        if (movedAny) {
            backing.method_5431();
            this.method_7623();
        }
        return movedAny;
    }

    /* ---------- inner: 27-slot window proxy ---------- */
    private static final class WindowedInventory implements class_1263 {
        private final class_1263 backing;
        private int baseIndex;    // changes on scroll
        private final int size;   // fixed 27

        WindowedInventory(class_1263 backing, int baseIndex, int size) {
            this.backing = backing;
            this.baseIndex = Math.max(0, baseIndex);
            this.size = size;
        }

        void setBaseIndex(int base) { this.baseIndex = Math.max(0, base); }
        private int map(int i) { return baseIndex + i; }

        @Override public int method_5439() { return size; }
        @Override public boolean method_5442() {
            for (int i = 0; i < size; i++) if (!method_5438(i).method_7960()) return false;
            return true;
        }
        @Override public class_1799 method_5438(int slot) {
            int idx = map(slot);
            return (idx >= 0 && idx < backing.method_5439()) ? backing.method_5438(idx) : class_1799.field_8037;
        }
        @Override public class_1799 method_5434(int slot, int amount) {
            int idx = map(slot);
            return (idx >= 0 && idx < backing.method_5439()) ? backing.method_5434(idx, amount) : class_1799.field_8037;
        }
        @Override public class_1799 method_5441(int slot) {
            int idx = map(slot);
            return (idx >= 0 && idx < backing.method_5439()) ? backing.method_5441(idx) : class_1799.field_8037;
        }
        @Override public void method_5447(int slot, class_1799 stack) {
            int idx = map(slot);
            if (idx >= 0 && idx < backing.method_5439()) backing.method_5447(idx, stack);
        }
        @Override public void method_5431() { backing.method_5431(); }
        @Override public boolean method_5443(class_1657 player) { return backing.method_5443(player); }
        @Override public void method_5448() {
            for (int i = 0; i < size; i++) method_5447(i, class_1799.field_8037);
        }
    }

    /* ---------- inner: slot that disables when mapped index is out of range ---------- */
    private static final class CofferSlot extends class_1735 {
        private final CofferScreenHandler handler;

        CofferSlot(CofferScreenHandler handler, class_1263 window, int index, int x, int y) {
            super(window, index, x, y);
            this.handler = handler;
        }

        private boolean mapsToValidIndex() {
            int mappedIndex = handler.getPage() * WINDOW_SLOTS + this.method_34266();

            // server uses live size; client uses page count * window size
            int maxItems = (handler.backing != null)
                    ? handler.backing.method_5439()
                    : handler.getTotalPagesSynced() * WINDOW_SLOTS;

            return mappedIndex < maxItems;
        }

        @Override public boolean method_7682() { return mapsToValidIndex(); }

        @Override public boolean method_7680(class_1799 stack) {
            return mapsToValidIndex() && super.method_7680(stack);
        }
    }
}
