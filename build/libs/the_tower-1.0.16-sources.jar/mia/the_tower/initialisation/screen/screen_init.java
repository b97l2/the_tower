package mia.the_tower.initialisation.screen;

import mia.the_tower.The_Tower;
import net.minecraft.class_2378;
import net.minecraft.class_3917;
import net.minecraft.class_7923;

public class screen_init {

    public static class_3917<CofferScreenHandler> COFFER;

    private screen_init() {}

    public static void load() {
        // Factory is the CLIENT constructor: (syncId, playerInv) -> new CofferScreenHandler(syncId, playerInv)
        COFFER = class_2378.method_10230(
                class_7923.field_41187,
                The_Tower.id("coffer"),
                new class_3917<>(CofferScreenHandler::new, net.minecraft.class_7701.field_40182)
        );
    }

}
