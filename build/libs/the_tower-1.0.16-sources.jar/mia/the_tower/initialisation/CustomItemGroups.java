package mia.the_tower.initialisation;

import mia.the_tower.The_Tower;
import mia.the_tower.initialisation.block.column_init;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class CustomItemGroups {
    public static final class_1761 FLESH_ITEM_GROUP = class_2378.method_10230(class_7923.field_44687,
            class_2960.method_60655("the_tower", "flesh_items"),
            FabricItemGroup.builder().method_47320(() -> new class_1799(block_init.CUBE_OF_FLESH))
                    .method_47321(class_2561.method_43471("itemgroup.the_tower.flesh_items"))
                    .method_47317((displayContext, entries) -> {
                        entries.method_45421(block_init.CUBE_OF_FLESH);
                        entries.method_45421(block_init.CUBE_OF_PERCEIVING);
                        entries.method_45421(block_init.FILTH);
                        entries.method_45421(block_init.PULLED_TEETH);
                        entries.method_45421(block_init.SKIN);
                        entries.method_45421(block_init.STITCHED_FLESH);
                        entries.method_45421(block_init.ITORE);
                        entries.method_45421(block_init.GRAVESTONE);

                        //items
                        entries.method_45421(item_init.KLAEN);
                        entries.method_45421(item_init.FINGER);
                        entries.method_45421(item_init.BLOODY_NAIL);
                        entries.method_45421(item_init.PEARL_OF_BLOOD);
                        entries.method_45421(item_init.SANGUINE_FLASK);
                        entries.method_45421(item_init.SANGUINE_SYRINGE);
                        entries.method_45421(item_init.CONTRACT);
                        entries.method_45421(item_init.TOOTH);
                        entries.method_45421(item_init.MY_RAGE);


                        //fluids
                        entries.method_45421(item_init.CHALICE_OF_BLOOD);
                        entries.method_45421(item_init.CUP_OF_GUNK);
                        entries.method_45421(item_init.BUCKET_OF_BILE);
                    }).method_47324());

    public static final class_1761 CERULEAN_ITEM_GROUP = class_2378.method_10230(class_7923.field_44687,
            class_2960.method_60655("the_tower", "cerulean_items"),
            FabricItemGroup.builder().method_47320(() -> new class_1799(item_init.GLUH))
                    .method_47321(class_2561.method_43471("itemgroup.the_tower.cerulean_items"))
                    .method_47317((displayContext, entries) -> {
                        //blocks
                        entries.method_45421(block_init.CUBE_OF_GLUH);
                        entries.method_45421(block_init.HEAVENS_EARTH);
                        entries.method_45421(block_init.HEAVENS_LIGHT);
                        entries.method_45421(block_init.POTENT_HEAVENS_LIGHT);
                        entries.method_45421(block_init.DARKNESS);
                        entries.method_45421(block_init.OXIDISED_DARKNESS);
                        entries.method_45421(block_init.BLAJ_ORE);
                        entries.method_45421(block_init.BLAJ_LESSER_ORE);
                        entries.method_45421(block_init.INFESTED_ROCK);
                        entries.method_45421(block_init.DRAGONS_EYE_ORE);
                        entries.method_45421(block_init.SILVER_ORE);
                        entries.method_45421(block_init.SILVER_VEIN);
                        entries.method_45421(block_init.SILVER_BLOCK);
                        entries.method_45421(block_init.SILVER_WALL);
                        entries.method_45421(block_init.SILVER_COLUMN);
                        entries.method_45421(block_init.SILVER_SLAB);
                        entries.method_45421(block_init.SILVER_STAIRS);
                        entries.method_45421(block_init.RAW_SILVER_BLOCK);
                        entries.method_45421(block_init.PETRIFIED_STONE);
                        entries.method_45421(block_init.CRACKED_PETRIFIED_STONE);
                        entries.method_45421(block_init.EMBOSSED_PETRIFIED_STONE);
                        entries.method_45421(block_init.CRACKED_EMBOSSED_PETRIFIED_STONE);
                        entries.method_45421(block_init.TILED_PETRIFIED_STONE);
                        entries.method_45421(block_init.CRACKED_TILED_PETRIFIED_STONE);
                        entries.method_45421(block_init.ADORNED_PETRIFIED_STONE);
                        entries.method_45421(block_init.GROTESQUE);
                        entries.method_45421(block_init.OLD_SOIL);
                        entries.method_45421(block_init.OLD_MEADOW);
                        entries.method_45421(block_init.SALT);
                        entries.method_45421(block_init.AFHD);
                        entries.method_45421(block_init.SLATE);

                        //plants
                        entries.method_45421(block_init.GLUH_VINE_STAGE0);
                        entries.method_45421(block_init.GLUH_VINE_STAGE1);
                        entries.method_45421(block_init.GLUH_VINE_STAGE2);
                        entries.method_45421(block_init.GLUH_VINE_STAGE3);
                        entries.method_45421(block_init.GLUH_VINE_STAGE4);
                        entries.method_45421(block_init.GLUH_VINE_STAGE5);
                        entries.method_45421(block_init.GLUH_VINE_STAGE6);
                        entries.method_45421(block_init.GLUH_VINE_STAGE7);
                        entries.method_45421(block_init.CERULEAN_PETALS);
                        entries.method_45421(block_init.BLUE_FOXGLOVE);
                        entries.method_45421(block_init.CERULEAN_SHORTGRASS);
                        entries.method_45421(block_init.CERULEAN_WILDGRASS);
                        entries.method_45421(block_init.SAPPHIRE_ROSE);
                        entries.method_45421(block_init.BLUE_BELL);
                        entries.method_45421(block_init.STARLIGHT_LICHEN);
                        entries.method_45421(block_init.GABRIELS_TRUMPETS_BUSH);
                        entries.method_45421(block_init.BLUE_HOSTAS);

                        //usable items
                        entries.method_45421(item_init.GLUH);
                        entries.method_45421(item_init.TWINTAIL_BERRY);
                        entries.method_45421(item_init.YUMP);
                        entries.method_45421(item_init.BLAJ);
                        entries.method_45421(item_init.HORNWORM);
                        entries.method_45421(item_init.DRAGONS_EYE);
                        entries.method_45421(item_init.MY_FUEL);
                        entries.method_45421(item_init.PILE_OF_SALT);
                        entries.method_45421(item_init.PILLAR_OF_SALT);
                        entries.method_45421(item_init.GABRIELS_TRUMPET);
                        entries.method_45421(item_init.PALE_AXE);
                        entries.method_45421(item_init.SHEPHERDS_STAFF);
                        entries.method_45421(item_init.CIRCLET_OF_GLUT);
                        entries.method_45421(item_init.DIVINING_ROD);
                        entries.method_45421(item_init.VOID_MOTH_SPAWN_EGG);
                        entries.method_45421(item_init.KEY);
                        entries.method_45421(item_init.WHITE_KEY);
                        entries.method_45421(item_init.ORANGE_KEY);
                        entries.method_45421(item_init.MAGENTA_KEY);
                        entries.method_45421(item_init.LIGHT_BLUE_KEY);
                        entries.method_45421(item_init.YELLOW_KEY);
                        entries.method_45421(item_init.LIME_KEY);
                        entries.method_45421(item_init.PINK_KEY);
                        entries.method_45421(item_init.GREY_KEY);
                        entries.method_45421(item_init.LIGHT_GREY_KEY);
                        entries.method_45421(item_init.CYAN_KEY);
                        entries.method_45421(item_init.PURPLE_KEY);
                        entries.method_45421(item_init.BLUE_KEY);
                        entries.method_45421(item_init.BROWN_KEY);
                        entries.method_45421(item_init.GREEN_KEY);
                        entries.method_45421(item_init.RED_KEY);
                        entries.method_45421(item_init.BLACK_KEY);

                        //non-usable items
                        entries.method_45421(item_init.SUPERIOR_BLAJ_ORE_ITEM);
                        entries.method_45421(item_init.LESSER_BLAJ_ORE_ITEM);
                        entries.method_45421(item_init.ITORE_ORE);
                        entries.method_45421(item_init.RAW_SILVER);
                        entries.method_45421(item_init.RAW_SILVER_NUGGET);
                        entries.method_45421(item_init.SILVER_INGOT);
                        entries.method_45421(item_init.SILVER_WIRE);
                        entries.method_45421(item_init.RUFESCENT_PEARL);

                        //craftable items
                        entries.method_45421(block_init.DRAGONS_LEAP);
                        entries.method_45421(block_init.ROD_OF_LUMINESCENCE);
                        entries.method_45421(block_init.SIMPLE_COFFER);
                        entries.method_45421(block_init.SILVER_LANTERN);
                        entries.method_45421(block_init.SILVER_THURIBLE);
                    }).method_47324());

    public static final class_1761 FUSION_ITEM_GROUP = class_2378.method_10230(class_7923.field_44687,
            class_2960.method_60655("the_tower", "fusion_items"),
            FabricItemGroup.builder().method_47320(() -> new class_1799(item_init.STAVE))
                    .method_47321(class_2561.method_43471("itemgroup.the_tower.fusion_items"))
                    .method_47317((displayContext, entries) -> {
                        entries.method_45421(item_init.STAVE);
                        entries.method_45421(item_init.GLOOP);
                        entries.method_45421(item_init.CHOCOLATE_BAR);
                        entries.method_45421(item_init.TOAST);
                        entries.method_45421(item_init.TOFFEE_APPLE);

                        entries.method_45421(block_init.CAN_OF_RETARDATION);
                        entries.method_45421(block_init.SHADOW);
                        entries.method_45421(block_init.JESTERS_HAT);
                        entries.method_45421(block_init.LOAF);
                        entries.method_45421(block_init.TANKARD);
                        entries.method_45421(block_init.SPIRITS);
                        entries.method_45421(block_init.SAUERKRAUT);

                        //golden
                        entries.method_45421(block_init.GOLDEN_THURIBLE);
                        entries.method_45421(block_init.GOLD_SLAB);
                        entries.method_45421(block_init.GOLD_STAIRS);
                        entries.method_45421(block_init.GOLD_COLUMN);
                        entries.method_45421(block_init.GOLD_WALL);
                        entries.method_45421(block_init.GOLD_BARS);
                        entries.method_45421(block_init.GOLD_TRAPDOOR);
                        entries.method_45421(block_init.GOLD_LADDER);
                        entries.method_45421(block_init.GOLD_BUTTON);
                        entries.method_45421(item_init.GOLDEN_SEED);
                        entries.method_45421(item_init.GINKGO_LEAF);
                        entries.method_45421(block_init.GINKGO_LOG);
                        entries.method_45421(block_init.GINKGO_LEAVES);
                        entries.method_45421(item_init.GINKGO_FRUIT);

                        //stone
                        entries.method_45421(column_init.STONE_COLUMN);
                        entries.method_45421(column_init.COBBLESTONE_COLUMN);
                        entries.method_45421(column_init.STONE_BRICK_COLUMN);
                        entries.method_45421(column_init.SMOOTH_STONE_COLUMN);
                        entries.method_45421(column_init.COBBLED_DEEPSLATE_COLUMN);
                        entries.method_45421(column_init.POLISHED_DEEPSLATE_COLUMN);
                        entries.method_45421(column_init.DEEPSLATE_BRICK_COLUMN);
                        entries.method_45421(column_init.DEEPSLATE_TILE_COLUMN);
                        entries.method_45421(column_init.BLACKSTONE_COLUMN);
                        entries.method_45421(column_init.POLISHED_BLACKSTONE_BRICK_COLUMN);
                        entries.method_45421(column_init.POLISHED_BLACKSTONE_COLUMN);

                        //emerald
                        entries.method_45421(block_init.EMERALD_COLUMN);
                        entries.method_45421(block_init.EMERALD_SLAB);
                        entries.method_45421(block_init.EMERALD_STAIRS);
                        entries.method_45421(block_init.EMERALD_WALL);

                        //porcelain
                        entries.method_45421(item_init.CHUNK_OF_KAOLIN);
                        entries.method_45421(block_init.KAOLIN);


                    }).method_47324());


    public static void load() {
        The_Tower.LOGGER.info("Registering Item Groups for " + "the_tower");
    }
}