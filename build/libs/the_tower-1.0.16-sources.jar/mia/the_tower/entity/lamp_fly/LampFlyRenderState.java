package mia.the_tower.entity.lamp_fly;
import net.minecraft.class_10042;
import net.minecraft.class_7094;

public class LampFlyRenderState extends class_10042{
    public final class_7094 idleAnimationState = new class_7094();
    public final class_7094 flyAnimationState = new class_7094();
    public boolean airborne;
    //public VoidMothVariant variant; //for when I introduce a variant
}
