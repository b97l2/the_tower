package mia.the_tower.entity.lamp_fly;

import mia.the_tower.initialisation.entity.custom.LampFlyEntity;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_927;

public class LampFlyRenderer extends class_927<LampFlyEntity, LampFlyRenderState, LampFlyModel>{
    //displays the mob

    //for variants
    /*
    private static final Map<VoidMothVariant, Identifier> LOCATION_BY_VARIANT =
            Util.make(Maps.newEnumMap(VoidMothVariant.class), map -> {
                map.put(VoidMothVariant.DEFAULT,
                        Identifier.of("the_tower", "textures/entity/void_moth/mantis.png"));
                map.put(VoidMothVariant.ORCHID,
                        Identifier.of("the_tower", "textures/entity/mantis/mantis_orchid.png"));
            });

     */

    public LampFlyRenderer(class_5617.class_5618 context) {
        super(context, new LampFlyModel(context.method_32167(LampFlyModel.LAMP_FLY)), 0.1f); //the last one is the shadow radius I believe
        this.method_4046(new EmissiveLayer<>(this, class_2960.method_60655("the_tower","textures/entity/lamp_fly/lamp_fly.png")));

    }

    @Override
    public class_2960 getTexture(LampFlyRenderState state) {
        return class_2960.method_60655("the_tower", "textures/entity/lamp_fly/lamp_fly.png");
        //return LOCATION_BY_VARIANT.get(state.variant); //this is for variants
    }

    @Override
    public void render(LampFlyRenderState state, class_4587 matrixStack,
                       class_4597 vertexConsumerProvider, int i) {
        if(state.field_53457) {
            matrixStack.method_22905(0.3f, 0.3f, 0.3f);
        } else {
            matrixStack.method_22905(1f, 1f, 1f);
        }

        super.method_4054(state, matrixStack, vertexConsumerProvider, i);
    }

    @Override
    public LampFlyRenderState method_55269() {
        return new LampFlyRenderState();
    }

    @Override
    public void updateRenderState(LampFlyEntity livingEntity, LampFlyRenderState livingEntityRenderState, float f) {
        super.method_62355(livingEntity, livingEntityRenderState, f);
        livingEntityRenderState.idleAnimationState.method_61401(livingEntity.idleAnimationState);
        livingEntityRenderState.flyAnimationState.method_61401(livingEntity.flyAnimationState);
        livingEntityRenderState.airborne = livingEntity.method_6581();

        //livingEntityRenderState.variant = livingEntity.getVariant();

    }

}
