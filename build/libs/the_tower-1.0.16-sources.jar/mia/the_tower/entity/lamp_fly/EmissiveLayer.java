package mia.the_tower.entity.lamp_fly;

import mia.the_tower.initialisation.entity.custom.LampFlyEntity;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_765;

public class EmissiveLayer<S extends LampFlyRenderState, M extends LampFlyModel>
        extends class_3887<S, M> {

    private final class_1921 layer;

    public EmissiveLayer(class_3883<S, M> ctx, class_2960 tex) {
        super(ctx);
        this.layer = class_1921.method_23026(tex); // full-bright render layer
    }

    @Override
    public void render(class_4587 matrices, class_4597 vcp, int light,
                       S entity, float limbAngle, float limbDist) {
        var vc = vcp.getBuffer(layer);
        this.method_17165().method_60879(
            matrices, vc,
            class_765.field_32767, // full-bright
            class_4608.field_21444
        );
    }
}
