package mia.the_tower.entity.lamp_fly;

import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_583;
import net.minecraft.class_630;
import net.minecraft.client.model.*;

public class LampFlyModel extends class_583<LampFlyRenderState> {


    public static final class_5601 LAMP_FLY = new class_5601(class_2960.method_60655("the_tower", "lamp_fly"), "main");

    private final class_630 full;

    public LampFlyModel(class_630 full) {
        super(full);
        this.full = field_54014.method_32086("full");
    }


        public static class_5607 getTexturedModelData() {
            class_5609 modelData = new class_5609();
            class_5610 modelPartData = modelData.method_32111();
            class_5610 full = modelPartData.method_32117("full", class_5606.method_32108().method_32101(0, 0).method_32098(-1.0F, -1.0F, -1.0F, 2.0F, 2.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32090(0.0F, 18.0F, 0.0F));

            class_5610 legs = full.method_32117("legs", class_5606.method_32108(), class_5603.method_32090(0.0F, 1.0F, 0.0F));

            class_5610 cube_r1 = legs.method_32117("cube_r1", class_5606.method_32108().method_32101(4, 4).method_32098(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 0.0F, new class_5605(0.0F))
                    .method_32101(2, 6).method_32098(-1.0F, 0.0F, 0.0F, 1.0F, 1.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, -0.7F, 0.48F, 0.0F, 0.0F));

            class_5610 cube_r2 = legs.method_32117("cube_r2", class_5606.method_32108().method_32101(4, 5).method_32098(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 0.0F, new class_5605(0.0F))
                    .method_32101(4, 6).method_32098(-1.0F, 0.0F, 0.0F, 1.0F, 1.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.0F, 0.48F, 0.0F, 0.0F));

            class_5610 cube_r3 = legs.method_32117("cube_r3", class_5606.method_32108().method_32101(0, 6).method_32098(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 0.0F, new class_5605(0.0F))
                    .method_32101(6, 4).method_32098(-1.0F, 0.0F, 0.0F, 1.0F, 1.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 0.0F, 0.8F, 0.48F, 0.0F, 0.0F));

            class_5610 antenaeleft = full.method_32117("antenaeleft", class_5606.method_32108(), class_5603.method_32090(0.0F, 0.0F, 0.0F));

            class_5610 cube_r4 = antenaeleft.method_32117("cube_r4", class_5606.method_32108().method_32101(2, 4).method_32098(-1.0F, -2.0F, 0.0F, 1.0F, 2.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, -1.0F, -0.9F, 0.0F, 0.0F, -0.3491F));

            class_5610 antenaeright = full.method_32117("antenaeright", class_5606.method_32108(), class_5603.method_32090(0.0F, 0.0F, 0.0F));

            class_5610 cube_r5 = antenaeright.method_32117("cube_r5", class_5606.method_32108().method_32101(0, 4).method_32098(0.0F, -2.0F, 0.0F, 1.0F, 2.0F, 0.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, -1.0F, -0.9F, 0.0F, 0.0F, 0.3491F));
            return class_5607.method_32110(modelData, 8, 8);
        }

    private void setHeadAngles(float headYaw, float headPitch) {
        headYaw = class_3532.method_15363(headYaw, -7.0F, 7.0F);
        headPitch = class_3532.method_15363(headPitch, -7.0F, 7.0F);

        this.full.field_3675 = headYaw * 0.017453292F;
        this.full.field_3654 = headPitch * 0.017453292F;
    }

    @Override
    public void setAngles(LampFlyRenderState state) {
        super.method_2819(state);
        this.setHeadAngles(state.field_53447, state.field_53448);

        this.setHeadAngles(state.field_53447, state.field_53448);

        if (state.airborne) {
            // Airborne: flap
            this.method_62099(state.flyAnimationState, LampFlyAnimations.FLY, state.field_53328, 1.0f);
        }
        this.method_62099(state.idleAnimationState, LampFlyAnimations.FLY, state.field_53328, 1f);
    }
    }

