package mia.the_tower.entity.lamp_fly;

import net.minecraft.class_7179;
import net.minecraft.class_7184;
import net.minecraft.class_7186;
import net.minecraft.class_7187;
import net.minecraft.client.render.entity.animation.*;

public class LampFlyAnimations {
    public static final class_7184 FLY = class_7184.class_7185.method_41818(2.0F).method_41817()
            .method_41820("full", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.2083F, class_7187.method_41829(20.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.4167F, class_7187.method_41829(27.32F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.5833F, class_7187.method_41829(15.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.7083F, class_7187.method_41829(7.5F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.9167F, class_7187.method_41829(-10.36F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(1.125F, class_7187.method_41829(-23.08F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(1.4583F, class_7187.method_41829(-15.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(1.7917F, class_7187.method_41829(-5.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(2.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
            ))
            .method_41820("full", new class_7179(class_7179.class_7183.field_37886,
                    new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(0.875F, class_7187.method_41823(0.0F, -1.6F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(1.4583F, class_7187.method_41823(0.0F, -0.6F, 0.0F), class_7179.class_7181.field_37885),
                    new class_7186(2.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37885)
            ))
            .method_41820("antenaeleft", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(-15.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(0.375F, class_7187.method_41829(7.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(0.7083F, class_7187.method_41829(2.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.25F, class_7187.method_41829(-17.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.625F, class_7187.method_41829(-30.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(2.0F, class_7187.method_41829(-15.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            ))
            .method_41820("antenaeright", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(-15.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(0.375F, class_7187.method_41829(7.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(0.7083F, class_7187.method_41829(2.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.25F, class_7187.method_41829(-22.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.625F, class_7187.method_41829(-30.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(2.0F, class_7187.method_41829(-15.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            ))
            .method_41820("frontlegs", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(0.375F, class_7187.method_41829(15.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(0.7083F, class_7187.method_41829(20.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.0F, class_7187.method_41829(-5.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.5417F, class_7187.method_41829(-17.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(2.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            ))
            .method_41820("middlelegs", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(0.375F, class_7187.method_41829(7.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(0.7083F, class_7187.method_41829(25.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.0F, class_7187.method_41829(12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.5417F, class_7187.method_41829(-12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            ))
            .method_41820("backlegs", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(0.375F, class_7187.method_41829(5.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(0.7083F, class_7187.method_41829(17.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.0F, class_7187.method_41829(12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.5417F, class_7187.method_41829(-2.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            ))
            .method_41821();

}
