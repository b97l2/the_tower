package mia.the_tower.entity.plate;


import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10017;
import net.minecraft.class_10090;
import net.minecraft.class_10444;
import net.minecraft.class_2350;
import net.minecraft.class_9209;
import org.jetbrains.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class PlateRenderState extends class_10017 {
    public class_2350 facing;
    public final class_10444 itemRenderState;
    public int rotation;
    public boolean glow;
    @Nullable
    public class_9209 mapId;
    public final class_10090 mapRenderState;

    public PlateRenderState() {
        this.facing = class_2350.field_11043;
        this.itemRenderState = new class_10444();
        this.mapRenderState = new class_10090();
    }
}
