package mia.the_tower.entity.void_moth;
import net.minecraft.class_10042;
import net.minecraft.class_2350;
import net.minecraft.class_7094;

public class VoidMothRenderState extends class_10042{
    public final class_7094 idleAnimationState = new class_7094();
    public final class_7094 flyAnimationState = new class_7094();
    public boolean airborne;
    public boolean perched;
    public class_2350 perchFace = class_2350.field_11036;
    //public VoidMothVariant variant; //for when I introduce a variant
}
